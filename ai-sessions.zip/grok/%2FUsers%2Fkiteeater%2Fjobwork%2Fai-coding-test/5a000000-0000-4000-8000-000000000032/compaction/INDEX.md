# Compaction Segment Index

| Segment | File | Turns | Approx bytes | Keywords |
|---|---|---|---|---|
| 000 | segment_000.md | 168 | 531433 | "implementation", "immediately", "writing", "memory", "before", "compiling", "Internal", "packages" |
