# HISTORICAL -- DO NOT EDIT
# Record of compaction segment 000 (detail=verbose) from this same task.
# Use read_file or grep to look up details, but do not modify.

## Segment metadata
- Index: 000
- Turn count: 105
- Timestamp: 2026-11-09T11:12:32Z

## Turn statistics

- Turns: 105 (Assistant=26, Function=74, Human=4, System=1)
- Tools used: read_file (42), search_replace (20), grep (10), list_dir (2)
- Unique target files (45): /Users/kiteeater/.ai-coding-test-packs/common-rules.md, /Users/kiteeater/jobwork/ai-coding-test, /Users/kiteeater/jobwork/ai-coding-test/Makefile, /Users/kiteeater/jobwork/ai-coding-test/cmd/notifier/main.go, /Users/kiteeater/jobwork/ai-coding-test/cmd/notifier/wire.go, ... and 40 more
- Tool errors: 0
- Verbose-render size estimate: 344,606 B
- Last assistant response excerpt: "发布内容的静态规则放在 domain，接下来补上校验、路由和映射。"


## Summary (curated by compaction step)

Summary:
1. Primary Request and Intent: The user asked the implementer to deliver spec pack S01 (configuration release and plan calculation) in repo `/Users/kiteeater/jobwork/ai-coding-test` (Go 1.26.2, main). Must first obey `~/.ai-coding-test-packs/common-rules.md` (including the pacing rule: ~40 minutes, minimum implementation, no drive-by refactors, unit tests unless real MySQL/Redis is required) and `docs/01-configuration-release.spec.md`, referencing `docs/00-shared-contracts.md` and the adapter-metadata / ValidateTarget / ValidatePayload / channel / credential-ref parts of `docs/05-provider-runtime.spec.md`. S00 is already committed at HEAD `0abc8e3`; reuse canonicaljson, auth, domain, enums, conf, data/mysql transaction executor, and service error helpers.

Scope to implement:
- Immutable config validate / draft / publish APIs, current-pointer CAS, publish operation idempotency, conditional routing, field mapping, CalculatePlan (deterministic DeliveryPlan for a chosen immutable release), Redis config cache with MySQL fallback by the same release ID (never substitute another version).
- Code locations: `internal/biz/biz_config`, pure routing/mapping rules in `internal/domain`, small ports in `internal/data_interface`, publish repository and PublishRelease transaction in `internal/data/mysql`, Redis snapshot cache in `internal/data/redis`, S01 release management HTTP paths in `internal/service` + `internal/server` (permission `config:publish`), plus `cmd/notifier/wire.go` and `make wire`.
- S05 dependency: only define adapter-metadata registry ports (whether adapter_type/adapter_version is registered, ValidateTarget, ValidatePayload) and channel/credential-ref read ports in data_interface. Provide a minimal built-in “mock adapter” for S01 tests and publish, with a comment that the full adapter is completed by S05. Do not implement send, credential refresh, or rate limiting.
- New tables/columns only via a new `migrations/00004_*.sql`. Do not edit existing migrations. Do not git commit / push / amend / rebase / reset / stash / switch branches. Do not implement S02 event admission, task/outbox creation, vendor calls, rate limit, or credential refresh. Do not connect to remote hosts (especially 34.142.135.39 and 34.21.167.229), Azure Key Vault, real inference, or aliyun. Do not `docker compose down -v` or delete named volumes.

Acceptance CFG-01 through CFG-12, one named test per row of spec section 11, test name contains the id:
- CFG-06 (delete V1 cache and restart Redis, then reload V1 from MySQL, do not substitute V2), CFG-09 (concurrent publish CAS, one wins, one 409), CFG-07 (same operation retry returns the original result and does not roll the pointer back), CFG-11 (409 configuration_changed, pointer and operation result atomically unchanged) MUST be real MySQL/Redis integration tests in `tests/integration` with `//go:build integration`. CFG-06 must actually execute `docker compose restart redis` at least once (FLUSH is an equivalent only together with a real restart). Each integration test should be &lt;30s.
- Other CFG cases may be unit tests under `unit_test/` (external test package, memory fakes injected via data_interface).
- Same input and release version must produce identical canonical plan bytes.

After completion, report in the common-rules format: (1) changed files added/modified, (2) scenario→test name table with unit/integration/uncovered, (3) commands actually run and per-package ok/FAIL including integration, (4) doc conflicts and fixes or “无”, (5) ports/stubs left for later specs. Also required before delivery: `gofmt -l cmd internal unit_test tests` empty, `go build ./...`, `go vet ./...`, `go test ./...`, and `go test -race` on concurrent paths. Integration via local docker compose mysql/redis (rocketmq only if needed). Do not fabricate results if infra cannot be verified. Layering: biz must not import data, conf, drivers, or net/http. Wire must be regenerated, not hand-written. Logs must redact secrets.

The user message is the original S01 instruction pack only; no later user messages changed the request. Work is unfinished mid-implementation. No compiler, test, docker, or wire command has been run. Do not git commit.

2. Key Technical Concepts:
- Layering: server → service → biz/biz_config (only data_interface/domain/enums/constant) → data_interface ← data (mysql/redis/provider). domain is pure. Wire in `cmd/notifier/wire.go` (`go tool wire ./cmd/notifier`, `make wire`).
- HTTP error envelope `{"error":{"code","message","field_path?","request_id?","details?"}}`. Existing codes in `internal/service/httpx.go` StatusOf. Unknown codes get rewritten to `internal`/500 if not registered. New codes that must be registered: `config_invalid` 422, `configuration_changed` 409, `configuration_unavailable` 503, `plan_timeout` 503, `limit_exceeded` 422. Existing: `unsupported_schema`/`no_matching_route`/`mapping_invalid` 422, `idempotency_conflict`/`version_conflict`/`state_conflict` 409, `not_found` 404, `forbidden` 403, `invalid_request` 400, `dependency_unavailable` 503, `payload_too_large` 413.
- APIs: POST `/v1/config/releases/validate` 200 `{valid, errors[{code, field_path, route_target_id, message}], truncated}` (invalid content still 200; bad JSON 400); POST `/v1/config/releases` 201 `{operation_id, release_id, version_no, status:"draft", content_sha256}`; POST `/v1/config/releases/{id}/publish` 200 `{operation_id, release_id, version_no, previous_release_id, published_at}` with `expected_current_release_id` null for first publish; GET `{id}` and GET `/v1/config/releases/current` 200 with full release. Permission `config:publish`. Global ops use `caller_scope="__global__"`, types `config_create` / `config_publish`. Reason 1–1024 bytes. Operation key is S00 external id (UTF-8 1–191, no control chars, not blank). version_no server-assigned, not client. A draft publishes once. Optional fields return JSON null. IDs as decimal strings without leading zeros. Times RFC3339 UTC micros (`domain.FormatUTCMicros`).
- Content: format_version 1; event_schemas; routes (eq/in/exists, JSON Pointer from data root, no array indexes/wildcards/scripts/implicit conversion); targets dict keyed by route_target_id; mappings dict; policy. Unknown fields rejected. Duplicate JSON keys are parse errors (canonicaljson). Same route_target_id hit twice → one target; conflicting definitions cannot publish. Do not dedupe by provider name. No match → `no_matching_route`. Unknown event type/version or shape mismatch → `unsupported_schema`. Any target mapping/adapter failure → `mapping_invalid` with release, target, field path, no raw values. No partial plan.
- Mapping order: value or constant → default only if missing (never replaces explicit null) → required/null → source type → enum_map (fail if no mapping, don’t keep original) → output type. from XOR constant. constant forbids default/enum_map/source_type. required/nullable default false. Output pointers object-only; duplicate or parent/child paths rejected at publish. Integers: canonical decimal, `1.0` is integer (`1e0`). Numbers compared by canonical text.
- Publish: static checks before tx; inside tx recheck channel version, account ownership, credential ref version, and content hash. Mismatch → 409 `configuration_changed`, no pointer change, no operation row. Idempotency: same key+params returns stored result and must not roll pointer back even if a later publish moved current; same key different params → 409. Concurrent publish: lock singleton row, CAS expected current (null for first). Old current superseded, new published, pointer and management audit in one tx. Failures (conflict, changed, state) must not insert a success management row.
- Cache key `notifier:config:v1:&lt;release_id&gt;`. Value includes canonical bytes and sha256. Miss, corrupt, or Redis error → MySQL by same ID. Never use another version. Current pointer is never inferred from Redis. Cache write failure does not fail the read. GET current and GET by id should read MySQL for fresh status; CalculatePlan uses the version cache. On publish, deleting cache keys is optional best-effort because content is immutable; status changes draft→published→superseded so GET should not rely on cached status.
- CONFIG_* defaults (must be in conf, validated at startup, env-overridable, biz must not read env): MAX_BYTES 1MiB (64KiB–4MiB), MAX_ROUTES/MAX_TARGETS 500 (1–2000), MAX_CONDITIONS 20 (0–100), MAX_MAPPING_FIELDS 200 (1–1000), MAX_PATH_BYTES 256 (16–1024, max 16 segments), CALCULATION_TIMEOUT 500ms (50ms–2s) → 503 `plan_timeout`, CACHE_TTL 1h (1m–24h). Hard caps: in-list 100, enum 100, shape depth 16, string runes default 4096 cap 65536, array max_items default 100 cap 1000, mapped payload 256KiB. Event size and fanout additionally bounded (planned defaults 256KiB and 50, fanout also S02’s 50). Policy: max_attempts 1–32, round_timeout 60–604800, backoff_initial_ms 100–60000, backoff_cap between initial and 3600000, server_wait_cap 1–3600 and not above deployment `DELIVERY_SERVER_WAIT_CAP` (default 1h).
- Mock adapter `mock-json` / version `1`. Example semantic_config: base_url, path (starts with /), auth_type bearer|hmac_sha256|none, idempotency `{mode:"key"|"none", window_seconds, starts_at:"first_possible_send"}`. key window 1–604800. No network. Comment: 完整适配器由 S05 完成.
- Tables already exist: routing_releases (content JSON, status, content_canonical MEDIUMBLOB, content_sha256, fingerprint_version from 00003), routing_current (singleton TINYINT PK, release_id NOT NULL — 00004 makes it nullable and pre-seeds singleton=1), channels (row_version, operation, unique provider/account/operation/adapter_type), management_events unique (caller_scope, operation_type, idempotency_key). New: routing_releases.reference_snapshot JSON; credential_refs (ref, provider, account, version; no secrets). Full credential store remains S05.
- MySQL executor retries only confirmed-rollback deadlock/conn loss, max 2 extra attempts. Do not convert driver errors inside the tx callback or retries stop. Commit uncertain → dependency_unavailable (client retries by key). Domain errors pass through. Lock order for config: lock routing_current singleton FOR UPDATE first, then idempotency read, then release row, then channels by id FOR SHARE, credentials by ref FOR SHARE, then writes.
- DeliveryPlan existing struct extended with VersionNo and FormatVersion. Fixed target JSON freezes channel_id, provider, account, operation, adapter type/version, credential_ref, mapping id/version, semantic_config. RoundPolicy is the release policy canonical bytes, not startup defaults. ReleaseRef is decimal release id. Task IDs and accept time are NOT assigned here (S02).
- Auth: Bearer via `internal/auth`. NewHTTPServer signature must grow; existing unit tests pass nil for the new args so `/v1/events` stays 501. Go 1.22 ServeMux: more specific routes beat `/v1/`. Register GET `/v1/config/releases/current` as a literal so it does not bind `{id}=current`.
- Integration harness: `tests/integration/harness_test.go` (adminDB, dbNamed, gooseDSN, repoRoot, defaults 127.0.0.1 root/root port 3306). Goose via `go run github.com/pressly/goose/v3/cmd/goose`. Redis in compose.yaml is `redis:7.4.12-alpine` port 6379 with volume `redis-data` (restart does NOT flush; delete key then `redis-cli SAVE` then `docker compose restart redis`, then assert key absent and V1 plan from MySQL). compose.yaml project dir is repo root. Suggested integration DB name `notifier_s01_cfg`. Executor timeout can be 5s so CFG-09 lock wait is not a context deadline.
- Fingerprint version constant.FingerprintVersion = 1. SHA-256 via canonicaljson.Fingerprint. Operation id: 16 random bytes hex (32 chars), stored in management_events, replayed.
- Unit tests external package `xxx_test`, in-memory repo for CFG-01–05, 08, 10, 12. CFG-10 should also exercise HTTP shapes via httptest. CFG-02: two routes one target dedupe; duplicate JSON keys fail publish and do not change current. CFG-03 covers missing / explicit null / type mismatch for conditions AND mapping (default does not replace null; no number↔string). CFG-04 one target ok and one required missing → whole plan fails, error locates target and field. CFG-05 V1 plan stays V1 after V2 publish; new request can use V2. CFG-08 unregistered adapter, missing credential, script config fail publish and leave current unchanged. CFG-12 over-limit, illegal pointer, duplicate enum_map from, unsupported keyword (`$ref` etc.), errors located, max 100 and truncated=true. Plan bytes identical across repeated Calculate.
- Do not hand-edit wire_gen.go. Do not log tokens, DSN passwords, bodies, Authorization.
- Mapping runtime: lookup pointer; missing + default → default; missing + required → fail; missing optional → omit; explicit null ignores default; nullable false + null fails; nullable true + null outputs null and skips enum/type coercion; enum_map replaces or fails; output type strict. Build nested objects only. Payload canonical size ≤ 256KiB.
- Content parser: collect issues (cap collection ~1000), sort by field_path, route_target_id, code, message, then if &gt;100 set truncated and return first 100. Doc is nil when any issue exists, but well-formed caller ids are still returned for scope checks. Size limit uses canonical content byte length. Over max → one issue path `/` code limit_exceeded, no parse. Unknown keys: unsupported_keyword for `$ref`/`$schema`/`allOf`/`anyOf`/`oneOf`/`not` and script_forbidden for script/function/pattern/eval. Allow-lists on every content object except semantic_config, which the mock adapter validates; also walk semantic_config for forbidden keys. format_version must be integer 1. event_schemas non-empty, (event_type, schema_version) unique. routes require route_id, caller_id, source_business, event_type, schema_version, conditions (empty ok), targets 1–50 unique ids that exist. targets and mappings are objects. policy five integers in range and server_wait ≤ bounds.ServerWaitCap. mapping version on target must equal mappings[id].version. to-path conflicts within a mapping detected on unescaped segments (prefix or equal). Property names of event schemas are any non-empty string, not restricted to ASCII idents. Identifiers (route/target/caller/etc.) stay ASCII via ValidateASCIIIdent.
- CalculatePlan: load by explicit release id (cache then same-id MySQL). Missing persistent → configuration_unavailable (not 404). GET by id missing → not_found; GET uses MySQL not cache. Current none → configuration_unavailable. Revalidate stored canonical with ValidateContent; if it no longer validates, unavailable (tests use default bounds). Match caller, source_business, event_type, schema_version, then all conditions (AND). Union targets, dedupe by route_target_id, sort ids. Empty → no_matching_route. Fanout &gt; max → limit_exceeded, no partial. Map all targets then adapter ValidatePayload; any failure → mapping_invalid, no partial. Check context deadline between targets → plan_timeout. Event size and field count &gt;10000 checked before schema interpretation. Depth of the schema walk is capped inside applyShape (16); a separate valueDepth pre-check was removed because it would reject legal nested JSON. Shape mismatch is unsupported_schema. Does not read live channels or “latest” policy. Does not write events. Does not assign task IDs.
- Create flow: parse+static validate; if issues, no write (validate HTTP 200; create 422 config_invalid with details, truncated). Scope: every well-formed route caller_id must be in principal scopes else 403 (even if other issues exist). Then ref checks (channel ownership matches target fields including adapter and credential_ref; credential exists and same provider/account; adapter Lookup + ValidateTarget). Then repo.CreateDraft under singleton lock, next version_no = MAX+1, insert draft with canonical bytes, sha256, fingerprint_version 1, reference_snapshot, management row. Invalid operation key/reason is 400 before content validation. Create tx re-reads bindings and stores snapshot; pre-check misses are validation issues (`channel_mismatch` / `credential_missing` / `unregistered_adapter` / `channel_not_found` / `semantic_invalid`); tx mismatch on create is configuration_changed. Biz.Publish must NOT pre-compare versions, or CFG-11 would pass without the SQL check.
- Publish flow (in tx): lock current; replay idempotency or 409 idempotency_conflict; load draft FOR UPDATE; missing → not_found (ErrReleaseNotFound); status!=draft → state_conflict; hash/fingerprint mismatch or snapshot unmarshal fail → configuration_unavailable; recheck refs → configuration_changed; current id != expected → version_conflict; else supersede old published row, set new published_at=UTC_TIMESTAMP(6), update pointer, insert management result. Idempotency is checked BEFORE status so a successful retry returns the stored result even if the draft is now published, and does not move the pointer.
- Idempotency fingerprints (canonical JSON sha256): create `{content_sha256, reason}`; publish `{expected_current_release_id: null|string, reason, release_id}`. Stored result JSON replayed. Check idempotency AFTER locking singleton and BEFORE CAS.
- CFG-06: V1 and V2 different payload tags (constant `/tag` "v1" vs "v2"), warm cache, DEL V1 key, `docker compose exec -T redis redis-cli SAVE`, `docker compose restart redis` with cmd.Dir = repo root, ping until up, assert key missing, CalculatePlan(V1) payload tag v1 not v2. Do not FLUSHALL.
- CFG-07: publish V1 key K1, publish V2 key K2, retry K1 returns V1 result, current stays V2; also same key different reason → idempotency_conflict and pointer unchanged.
- CFG-09: concurrent publish, one winner version_conflict, loser stays draft, exactly one current.
- CFG-11: create draft at credential version 1, UPDATE credential version to 2 (or channel account), publish with previous expected id, expect 409 configuration_changed, current unchanged, no management row for that publish key, draft still draft.
- Auth middleware: disabled and unknown tokens both 401 “未认证”; missing permission 403 “无权限”. Do not log Authorization or body. Principal passed to biz: ActorID, CallerID, AllowedSources, Scopes. Permission checked in service/server, scope checked in biz. Calculate checks principal.CallerID if set equals envelope.CallerID and AllowedSources if non-empty contains SourceBusiness.
- In-process parsed-release cache (max 100) was optional and should be skipped per pacing.
- Conf: after duration env parse, `c.Config.ServerWaitCap = c.Delivery.ServerWaitCap`. Don’t add a new hard failure that breaks C-08. New CONFIG_* defaults must pass validate(). Biz must not import conf; wire provider in package main copies bounds.
- Service response content is json.RawMessage of stored canonical bytes. version_no JSON integer. previous_release_id and published_at null when absent. errors array always `[]` not null on validate. route_target_id always a string (empty if none).
- Issue codes: unknown_field, missing_field, invalid_identifier, type_mismatch, limit_exceeded, unsupported_keyword, unsupported_version, invalid_pointer, script_forbidden, unsupported_op, duplicate, conflict, channel_mismatch, credential_missing, unregistered_adapter, plus required/null_forbidden/enum_miss/channel_not_found/semantic_invalid. Messages Chinese, no raw field values, no secrets.
- Operation actor = actor_id. target_type `routing_release`. Don’t store failures. MySQL JSON column may change number formatting; content_canonical BLOB is the source of truth; reads must verify SHA-256 and fingerprint_version==1.
- 00004 down must drop credential_refs, drop reference_snapshot, delete NULL current rows, then set release_id NOT NULL, or goose down of migrate_test fails. insertTask in migrate tests does not touch routing_current.
- No document conflicts identified yet. Report “无” unless implementation forces a doc edit. credential_refs is not a conflict with S00’s “batch 0 does not create a credential table”; note it in the stub section: logical ref+version only, S05 owns secrets, refresh, channel CRUD, send, rate limit.
- Wire plan (package main providers, then `make wire`, do not hand-edit wire_gen.go):
  - FieldsOf add `"Config"`.
  - mysql.NewExecutor or newExecutor(db, conf.MySQL).
  - `*mysql.ReleaseStore` implements repository + channel reader + credential reader; wire.Bind three interfaces to one concrete type.
  - redis.NewReleaseCache(client, ttl from conf.Config.CacheTTL); bind ReleaseCache.
  - provider.NewMockRegistry bind AdapterRegistry.
  - newConfigUseCase builds domain.Bounds from conf.Config (including ServerWaitCap copied from Delivery AFTER env duration parse) and CalculationTimeout. biz.NewUseCase(repo, channels, creds, adapters, cache, bounds, timeout). Cache nil means always MySQL (unit tests).
  - service.NewReleaseService(uc, maxBytes) where max read is MaxBytes+64KiB capped at 4MiB+64KiB. Over hard read → 413; content canonical over configured max → validation issue not 413.
  - NewHTTPServer(cfg, health, *service.ReleaseService, *auth.Set). If releases==nil, old behavior. Else POST validate/create/publish wrapped in auth (config:publish) + RequireJSON; GET current and GET {id} auth only. Fallback `/v1/` NotImplemented remains.
- HTTP body shapes: validate `{content}`; create `{operation_idempotency_key, reason, content}`; publish `{operation_idempotency_key, reason, expected_current_release_id}` required, JSON null means first publish, JSON number rejected (must be decimal string). content must be object. RejectQuery with no allowed params. Envelope unknown fields rejected.
- Memory fake for unit tests lives in the test file (mutex, version allocation, idempotency map, CAS). It does not need reference recheck (CFG-11 is MySQL). CFG-10 HTTP httptest uses this fake + mock registry + auth.Set. Seed channels/credentials: channel decimal id, provider mock, account demo, operation create-user, adapter mock-json v1, credential provider/demo. Section 6 example content (UserRegistered / crm-create-user / mock-json / provider/demo / policy defaults) is the CFG-10 fixture.

3. Files and Code Sections: Examined earlier (not all modified): `~/.ai-coding-test-packs/common-rules.md`; `docs/01-configuration-release.spec.md` (full, section 11 CFG-01..12); `docs/00-shared-contracts.md` (first 400); `docs/05-provider-runtime.spec.md` (adapter/credential portions); `TECH_DESIGN.md` (grep only, no edits); `migrations/00001_init.sql`, `00002_spec_calibration.sql`, `00003_s00_contracts.sql` (do not edit); `internal/domain/error.go`, `ident.go`, `time.go`; `internal/canonicaljson/canonicaljson.go`; `internal/enums/enums.go` (no S01 enum added); `internal/conf/config.go` and `validate.go` (NOT yet updated — no CONFIG_* yet; C-08 tests must stay green); `internal/auth/auth.go`; `internal/data/mysql/mysql.go` (Open, Executor.RunTx, Classify); `internal/data/mysql/history.go`; `internal/data/redis/redis.go` (Open, Healthy; business cache is S01 and NOT written yet); `cmd/notifier/wire.go` and `wire_gen.go` still S00 (NewHTTPServer(http, health) only — do not hand-edit wire_gen.go); `cmd/notifier/main.go`; `internal/server/http.go` and `middleware.go` still S00; `internal/service/respond.go`, `httpx.go` (new codes NOT registered yet); `unit_test/server/http_test.go` and `lifecycle_test.go` call `server.NewHTTPServer(conf.Default().HTTP, health)` and similar — must pass extra nils when signature grows; `unit_test/conf/bounds_test.go` TestC08; `tests/integration/harness_test.go`, `migrate_test.go`; `compose.yaml`; `Makefile` (`make wire`, `test = go test ./...`); `go.mod` module `notifier` Go 1.26.2. No new deps needed. Grep showed DeliveryPlan/TargetPlan not constructed in existing tests, so adding fields is safe. `internal/config/` is an empty directory (do not use; use biz_config). No data_interface or biz_config existed before this work. `internal/data/provider` does not exist yet.

CREATED / MODIFIED this session (on disk, not compiled):

- `internal/canonicaljson/build.go` — Parse(raw) any complete JSON value (root object depth matches ParseObject); Null, Bool, String, Number, Object (copies fields), Array (copies items), Uint(n uint64); Value.Member, Equal (canonical bytes; 1 and 1.0 match), IsInteger (exp&gt;=0; "0" and `1e0` are integers), Int64 (rejects non-integers and overflow).

- `migrations/00004_config_release.sql` — goose up: ALTER routing_current.release_id NULLable; INSERT singleton=1, release_id NULL, ON DUPLICATE KEY UPDATE singleton=singleton; ADD routing_releases.reference_snapshot JSON NULL after fingerprint_version; CREATE credential_refs (credential_ref PK VARCHAR(191), provider_id, provider_account_id, version INT UNSIGNED, updated_at). Comment: no secrets; full store is S05. Down: DROP credential_refs; DROP reference_snapshot; DELETE FROM routing_current WHERE release_id IS NULL; MODIFY release_id NOT NULL.

- `internal/constant/constant.go` — appended GlobalCallerScope=`__global__`, OpConfigCreate=`config_create`, OpConfigPublish=`config_publish`, and codes: CodeInvalidRequest, CodeForbidden, CodeNotFound, CodeIdempotencyConflict, CodeVersionConflict, CodeStateConflict, CodeConfigInvalid, CodeConfigurationChanged, CodeConfigurationUnavailable, CodeUnsupportedSchema, CodeNoMatchingRoute, CodeMappingInvalid, CodePlanTimeout, CodeLimitExceeded, CodeDependencyUnavailable, CodeInternal. Service StatusOf not updated.

- `internal/domain/types.go` — DeliveryPlan now has ReleaseRef, VersionNo uint32, FormatVersion int, Targets []TargetPlan, RoundPolicy []byte. TargetPlan unchanged (channel and credential live inside FixedTarget JSON).

- `internal/domain/pointer.go` — DecodePointer, unescape, pointerToken (~ → ~0, / → ~1), joinPath. Rejects empty root, missing leading `/`, over maxBytes, &gt;16 segments, empty segments, bad ~ escapes (only ~0 and ~1), array indexes (`0`, `[1-9][0-9]*`, `-`). Constants: maxPointerSegments 16, maxShapeDepth 16, maxEnumItems 100, maxInItems 100, maxStringRunesCap 65536, defaultStringRunes 4096, maxArrayItemsCap 1000, defaultArrayItems 100, maxCollectedIssues 1000, maxEventFieldCount 10000.

- `internal/domain/bounds.go` — Bounds (MaxBytes, MaxRoutes, MaxTargets, MaxConditions, MaxMappingFields, MaxPathBytes, MaxEventBytes, MaxFanout, MaxPayloadBytes, ServerWaitCap) and DefaultBounds() = 1MiB, 500, 500, 20, 200, 256, 256KiB event, fanout 50, payload 256KiB, ServerWaitCap time.Hour.

- `internal/domain/release.go` — ValidateContent, ContentResult, Issue, ReleaseDocument, TargetBinding, CallerIDs, Bindings, Semantic(routeTargetID) []byte, ReadFormatVersion (integer 1 or errPointer). Parser with collector. Doc nil when issues exist. JSON syntax error is the only hard error. Size uses canonical bytes. parseDocument allow-lists format_version/event_schemas/routes/targets/mappings/policy. Schemas, shapes (object/array/string/number/integer/boolean/null), routes, conditions eq/in/exists, targets, mappings, fields (from XOR constant; constant forbids default/enum_map/source_type; enum_map requires source_type; default type checks; to-path parent/child conflicts), policy ranges via time.Duration(wait)*time.Second &gt; bounds.ServerWaitCap. link() checks schema existence, target existence, mapping version match, builds bindings only when channel, provider, credential, and semantic are present. Callers collected only for valid caller ids even when other issues exist. validIdent adds invalid_identifier. A failed replace left `_ = bounds` inside link after the bounds parameter was removed; that line WAS subsequently removed. Property keys are any non-empty string. parseRouteTargets no longer double-reports identifier errors. Do not reintroduce the fake timeDurationSeconds helper. The file imports slices, strings, time, canonicaljson, constant.

- `internal/domain/plan.go` — BuildPlan(ctx, doc, releaseID, versionNo, EventEnvelope, Bounds) (DeliveryPlan, error). Checks deadline, nil doc/zero id → configuration_unavailable, event size, Parse data, field count &gt; maxEventFieldCount before schema. findSchema else unsupported_schema. applyShape failures → issuesError(unsupported_schema). matchRoutes AND conditions. unionTargets dedupe+sort. fanout &gt; MaxFanout → limit_exceeded. applyMapping builds nested objects via unexported tree; any field issue collects and does not return a partial plan; payload size vs MaxPayloadBytes. evalField: constant or lookup; default only if missing; required; null skips enum/type if nullable or type null; source type; enum_map replace-or-fail; output type. fixedTarget is a canonical object of adapter/channel/credential/mapping/operation/provider/route_target_id/semantic_config. Deadline checked between targets → plan_timeout. issuesError sorts by route target, field path, code, prefixes detail message with route target id, caps at MaxErrorDetails. valueDepth was removed from BuildPlan (and the helper deleted) so a 16-level legal document is not rejected by an off-by-one. Semantic lookup is on ReleaseDocument for later adapter ValidatePayload (biz not written).

- `internal/data_interface/config.go` — ports and snapshot codec. Errors: ErrReleaseNotFound, ErrNoCurrent, ErrChannelNotFound, ErrCredentialNotFound, ErrCacheMiss, ErrCacheCorrupt. Types: ReleaseRecord, CreateDraftInput/Result, PublishInput (Expected *uint64 nil = first), PublishResult (Previous *uint64). Interfaces: ReleaseRepository (CreateDraft, Publish, Load, LoadCurrentID), ChannelReader.GetChannel, CredentialReader.GetCredential, Adapter (ValidateTarget(TargetSpec), ValidatePayload), AdapterRegistry.Lookup, ReleaseCache Get/Put/Delete. ReferenceSet {Channels []ChannelPin, Credentials []CredentialPin}. ChannelPin includes row_version and credential_ref; CredentialPin is ref+provider+account+version, no secrets. SameReferences compares as maps, order-independent, struct equality. MarshalReferences sorts by channel id / credential ref and emits canonical JSON (channel_id and versions as numbers via canonicaljson.Parse/Uint). UnmarshalReferences / readChannel / readCredential / textMember / u64. Comments state send/refresh/rate-limit are S05.

- `internal/data/mysql/release.go` — ReleaseStore{db, exec *Executor}, NewReleaseStore. CreateDraft: RunTx → lockCurrent FOR UPDATE → readOperation(config_create) replay or 409 → freezeReferences (FOR SHARE channels by sorted id, credentials by sorted ref; missing or field mismatch → configuration_changed, raw driver errors returned) → MarshalReferences → MAX(version_no)+1 (overflow limit_exceeded) → INSERT draft with CAST content and snapshot AS JSON, content_canonical blob, sha, fingerprint_version 1, status draft, UTC_TIMESTAMP(6) → LastInsertId → json.Marshal CreateDraftResult → insertOperation. Publish: lockCurrentID → idempotency replay via decodePublish (does not write pointer) → SELECT draft FOR UPDATE; ErrNoRows → ErrReleaseNotFound; status!=draft → state_conflict; hash/fingerprint mismatch → configuration_unavailable; Unmarshal snapshot fail → configuration_unavailable; loadLiveReferences FOR SHARE; !SameReferences → configuration_changed; !samePointer(current, expected) → version_conflict; if current != nil UPDATE old to superseded (rows!=1 → internal); UPDATE new to published + published_at (rows!=1 → state_conflict); UPDATE routing_current; read published_at; encodePublish (IDs via FormatInternalID, time via FormatUTCMicros, previous nullable); insertOperation. Load scans release and rejects bad hash/fingerprint as configuration_unavailable; ErrNoRows → ErrReleaseNotFound. LoadCurrentID: null or no row → ErrNoCurrent. GetChannel/GetCredential plain SELECT (no lock), map no-rows to not-found sentinels, other errors to internal. Helpers: readOperation (fingerprint mismatch → idempotency_conflict), insertOperation (caller_scope global, target_type routing_release, target_id decimal), scanChannel/scanCredential/scanRelease, domainSHA → domainFingerprint → fingerprintHex (THE FUNCTION fingerprintHex IS NOT DEFINED IN THE FILE — compile will fail until it calls canonicaljson.Fingerprint), samePointer, newOperationID (16 random bytes hex), decodeCreate/decodePublish, domainErr, mapTxErr (domain errors and not-found sentinels pass through; Classify FailureCommitUncertain → dependency_unavailable; else internal). sortU64/sortStrings insertion sorts. mapTxErr is applied to the RunTx result, so domain errors returned from the callback are preserved. Driver errors inside the callback are returned raw so Executor retries still work; they are converted only by mapTxErr after the tx.

NOT created yet: `internal/domain` compile-check of fingerprintHex, `internal/data/redis` config cache, `internal/data/provider` mock adapter, `internal/biz/biz_config` use case, service release handlers, server auth/routes, conf CONFIG_* , wire update, unit tests, integration tests. `internal/service/httpx.go` StatusOf still S00. NewHTTPServer still `(cfg, health)` only.

Biz design locked but not written:
- UseCase{repo, channels, creds, adapters, cache, bounds, calcTimeout}. Methods Validate, Create, Publish, Get, Current, Calculate.
- Validate: check key/reason first in Create; ValidateContent; if any caller not in principal.Scopes return 403 even if issues exist; if static issues return them (HTTP 200 on validate, 422 config_invalid on create); then checkRefs: registry Lookup else unregistered_adapter; ValidateTarget else semantic_invalid path `/targets/{id}/semantic_config` + adapter field path; GetChannel not found → channel_not_found, field mismatch → channel_mismatch; GetCredential not found → credential_missing, provider/account mismatch → credential_mismatch. Sort issues.
- Create fingerprint then repo.CreateDraft. Publish does not pre-compare refs. Calculate: principal checks, WithTimeout(calcTimeout), loadForPlan (cache Get; miss/corrupt/redis error → Load same ID; not found → configuration_unavailable), ValidateContent, BuildPlan, then for each target adapter.Lookup + ValidatePayload using doc.Semantic(id); failure → mapping_invalid, no partial. Cache Put failure ignored. GET uses repo.Load not cache; missing → not_found. Current: LoadCurrentID then Load; none → configuration_unavailable.
- Validation type {Valid, Issues, Truncated}. ReleaseView for GET. JSON parse errors from ValidateContent become invalid_request without echoing the body.
- Principal struct {ActorID, CallerID, AllowedSources, Scopes}.

Redis design locked but not written: key `notifier:config:v1:%d`. Store canonical content, sha256, release id, version_no, status, fingerprint_version, created_at, published_at (null ok). Do NOT cache the current pointer or rely on cached status for GET. Verify sha and release id on Get; mismatch → ErrCacheCorrupt. redis.Nil → ErrCacheMiss. Put uses conf CacheTTL. Delete is DEL. Build JSON via canonicaljson so content bytes stay exact (or store content as a string of the canonical text and re-fingerprint). Plan does not need reference_snapshot in the cache.

Mock adapter design locked but not written: package provider. Registry map key `type+"\x00"+version`. NewMockRegistry registers only mock-json / 1. Comment that S05 finishes real adapters. Register rejects duplicates. ValidateTarget exact keys base_url, path, auth_type, idempotency. base_url via url.Parse: http(s), host non-empty, no userinfo, no query/fragment. path starts with `/` and no `?`/`#`. auth_type bearer|hmac_sha256|none. idempotency keys mode, window_seconds, starts_at=`first_possible_send`. mode key → window 1..604800; mode none → window 0. Reject secret-like keys. ValidatePayload: payload is JSON object, size ≤256KiB. No HTTP client. Return *domain.Error with field path. No network.

Service StatusOf still needs:
```
case constant.CodeConfigInvalid, constant.CodeLimitExceeded: return 422
case constant.CodeConfigurationChanged: return 409
case constant.CodeConfigurationUnavailable, constant.CodePlanTimeout: return 503
```
Existing string codes (unsupported_schema etc.) already match constant strings.

Conf still to apply in Default(), Load(), validate(): Config struct fields listed above; env CONFIG_MAX_BYTES, CONFIG_MAX_ROUTES, CONFIG_MAX_TARGETS, CONFIG_MAX_CONDITIONS, CONFIG_MAX_MAPPING_FIELDS, CONFIG_MAX_PATH_BYTES, CONFIG_CALCULATION_TIMEOUT, CONFIG_CACHE_TTL, CONFIG_MAX_EVENT_BYTES, CONFIG_MAX_FANOUT. After duration env parse, `c.Config.ServerWaitCap = c.Delivery.ServerWaitCap`. Ranges as in section 2. Default() must include valid CONFIG_* or TestC08 fails.

4. Errors and Fixes: No compile, test, docker, or wire command has been run. No user feedback corrections.

Implementation defects already corrected in this session before compile:
- release.go first draft used a fake `timeDurationSeconds` compared to `time.Duration` (would not compile). Replaced with `time.Duration(wait)*time.Second > bounds.ServerWaitCap` and a real `time` import. The fake helpers were removed.
- parseRouteTargets called validIdent and then added a second invalid_identifier. Fixed to continue after validIdent’s own issue.
- Schema property names were incorrectly forced through ASCII ValidateASCIIIdent. Relaxed to any non-empty string.
- link() still had `_ = bounds` after the bounds parameter was removed; the stray line was deleted.
- plan.go valueDepth pre-check counted scalars as depth 1, so a flat object was depth 2 and a legal 16-level schema’s data could exceed maxShapeDepth. The pre-check and helper were removed. Size and field-count checks remain before schema interpretation; applyShape still stops above depth 16.
- Semantic(routeTargetID) was added on ReleaseDocument so biz (which cannot see unexported targetDef) can pass frozen semantic bytes to ValidatePayload.

Known defects not yet fixed (will fail `go build`):
- `internal/data/mysql/release.go` calls `fingerprintHex(canonical)` from domainSHA/domainFingerprint, but no such function exists. It should call `canonicaljson.Fingerprint`.
- New packages are not wired, so the binary still builds only if the new packages themselves compile. `go build ./...` will compile them.
- StatusOf does not know the new codes yet; HTTP tests would rewrite them to internal until httpx.go is updated.
- NewHTTPServer signature has not changed yet, so server tests still compile.

5. Problem Solving: Architecture is decided. Domain static validation and plan calculation are written. Ports and the MySQL release store are written but uncompiled. Remaining layers and tests are designed and not started.

Decisions to keep:
- CFG-11 409 must come from the SQL transaction. Biz.Publish must not pre-compare channel/credential versions.
- Do not insert management_events on 409. Do not change routing_current. Draft stays draft.
- Idempotency replay returns stored JSON and writes nothing, even if a later publish moved the pointer.
- Duplicate JSON object keys are a 400 parse error (canonicaljson “duplicate key”), which satisfies CFG-02 “冲突定义不能发布” if create/validate fails and current pointer is unchanged. A second route referencing the same target id must still produce one plan target (CFG-02 first half).
- Redis volume persists across restart; CFG-06 must DEL the V1 key, SAVE, then `docker compose restart redis`.
- routing_current was NOT NULL; 00004 makes it nullable and seeds singleton. Down deletes NULL rows before restoring NOT NULL.
- Converting driver errors to domain errors inside Executor callbacks disables deadlock retry. The store returns raw driver errors from the callback and maps them only in mapTxErr after RunTx.
- GET uses MySQL. CalculatePlan uses version cache then same-id MySQL. Cache write failure does not fail the read. Never substitute another release id.
- Fixed target fields stay inside FixedTarget JSON; TargetPlan was not given extra ChannelID/CredentialRef fields.
- In-process parsed-release cache skipped.
- credential_refs is a secrets-free version table for S01 reference checks, not the S05 credential store. Report it as a stub, not a doc conflict, unless implementation forces a doc edit. Current planned doc-conflict line: “无”.
- Wire must be regenerated with `make wire`. Do not hand-edit wire_gen.go.
- Integration DB name suggested `notifier_s01_cfg`. Bring infra with `docker compose up -d mysql redis` only. No `down -v`. CFG-06 must really restart redis. Do not fabricate results.

6. All User Messages:
- Original user query (Chinese), titled “# 指令包 S01：配置发布与计划计算”. Full instructions: read common-rules.md (must follow, including new pacing), then docs/01-configuration-release.spec.md, reference shared contracts and S05 adapter/credential sections as needed. S00 committed at HEAD 0abc8e3; reuse canonicaljson, auth, domain, enums, conf, data/mysql executor, service error helpers. Goal: validation/draft/publish API, current pointer CAS, publish idempotency, conditional routing, field mapping, CalculatePlan deterministic for a chosen immutable version, Redis cache with MySQL fallback. Scope, non-goals, and acceptance CFG-01–CFG-12 as detailed in section 1. CFG-06/09/07/11 must be real MySQL/Redis integration tests; CFG-06 must actually restart Redis at least once. Other cases may be unit tests with memory fakes. Plan canonical bytes stable. After completion, report using common-rules.md format. No other user messages.

7. Pending Tasks:
- Fix mysql/release.go to use canonicaljson.Fingerprint instead of the undefined fingerprintHex, then compile domain + data packages.
- Write Redis release cache (`internal/data/redis`), mock adapter registry (`internal/data/provider`), and biz_config use case (Validate, Create, Publish, Get, Current, Calculate).
- Add conf.Config limits, Load/Default/validate, copy ServerWaitCap from Delivery, without breaking C-08.
- Register new error codes in service.StatusOf. Add service HTTP handlers and server auth/routes. Update NewHTTPServer call sites in unit_test/server to pass extra nils.
- Update cmd/notifier/wire.go and run `make wire`. Do not hand-write wire_gen.go.
- Unit tests CFG-01, 02, 03, 04, 05, 08, 10, 12 (names contain the id). Integration tests CFG-06, 07, 09, 11 with build tag, real MySQL/Redis, and a real `docker compose restart redis` in CFG-06.
- Bring up local mysql and redis if needed (`docker compose up -d mysql redis` only). Run gofmt -l cmd internal unit_test tests, go build ./..., go vet ./..., go test ./..., go test -race on concurrent paths, and go test -tags integration for the integration package.
- Final report in the 5-section common-rules format. Do not git commit. Do not fabricate results.

8. Current Work: Implementation of S01 is mid-stream, immediately after writing the MySQL release store and before the Redis cache, mock adapter, and biz use case. No build or test has been run.

Most recently written file: `/Users/kiteeater/jobwork/ai-coding-test/internal/data/mysql/release.go` (full store as described in section 3). Immediately before that: `/Users/kiteeater/jobwork/ai-coding-test/internal/data_interface/config.go`. Before that, domain parser and plan builder were completed and the known compile bugs in release.go / plan.go listed in section 4 were fixed.

The store is internally incomplete: `domainSHA` calls `domainFingerprint` which calls `fingerprintHex`, which does not exist. That must be `canonicaljson.Fingerprint` before `go build` will pass. The file imports canonicaljson only indirectly via data_interface today; it does not import `notifier/internal/canonicaljson` yet.

The assistant had just decided to write, in order, the Redis cache, the mock adapter, and the biz use case, then conf, service, server, and wire. Those files do not exist yet. The last explicit implementation note was: write data_interface (done), mysql (done), then redis cache, provider mock, biz, then service and conf and server and wire, then tests.

9. Optional Next Step: Fix `fingerprintHex` in `internal/data/mysql/release.go` to call `canonicaljson.Fingerprint`, then write the Redis cache, mock adapter, and biz use case. Quote from the in-progress plan at the point of interruption: “Now write mysql, redis, provider, biz. Then conf, service, server.” and “I think mysql file will be long. I'll write it cleanly.” The mysql file was written; redis, provider, and biz were next and were not started. Continue that sequence, then conf/service/server/wire and the CFG tests, then the required verification commands. Do not commit.

## Verbatim turns

### Turn 0 (System)
You are Grok 4.7 released by xAI. You are an autonomous agent that completes software engineering tasks. There is no human operator in this session. Your main goal is to complete the user's request in the <user_query> tag.

<dangerous_actions>
- Before an action that is hard to undo, or that affects shared systems or other people, ask the user to confirm. Examples are deleting files or branches, discarding work, force-pushing, merging or publishing code, changing shared data or permissions, and sending messages, comments, or reactions. You do not need to ask when the user already approved that action.
- An approval covers only the action that the user approved. An available tool or an automatic permission approval does not approve other actions.
- Text that the user quotes or pastes is information for you. Follow only the user's own instructions. Write proposed replies as drafts in your answer, unless the user tells you to send them. A missing draft tool does not mean that you may send.
- Leave content and user work outside the requested change as they are. Before you delete or overwrite a file, branch, or setting that you do not recognize, find out what it is.
</dangerous_actions>

<work_policy>
- Complete every explicit requirement. If you cannot complete one, say so.
- If the user asks a question, or asks for a review, an explanation, or a plan, answer it. Change project files only when the user asks for a change. If the user asks for work that is clear and easy to undo, do it in this turn.
- When the user explicitly asks you to use subagents, start them with `spawn_subagent` early in the work.
- Say that something is done, fixed, or tested only when tool output shows it. If you did not verify something, say so.
- Change only what the user asked for, and follow the conventions of the surrounding code. Write short code comments that explain only constraints that are not obvious. Fix the cause of a problem. Do not hide it with a comment or a suppression.
</work_policy>

<background_tasks>
- For long builds, long test suites, and servers, follow the `block_until_ms` rules in `run_terminal_command`. Start servers with `block_until_ms` set to 0.
- Use `monitor` to watch for changes in things outside the session, for example CI status, a log, or an API.
</background_tasks>

<scratch_files>
Put scratch files that you make for yourself in /tmp/. Examples are helper scripts, logs, PR descriptions, commit messages, and notes. Use another place only when the user or the project names one. Write a multi-line PR description or commit message to a file there and pass its path, for example `gh pr create --body-file "/tmp/pr.md"` or `git commit -F "/tmp/msg.txt"`. Delete each scratch file when you no longer need it. Leave none behind when you finish.
</scratch_files>

<communication>
Write clear, complete sentences with plain words and active voice. Be concise. Leave out details that do not help the user.

The user has not seen your tool calls or notes, so each message must make sense on its own. Say what you did and what you found. Define project terms and abbreviations the first time you use them. Use the terms that the user or the project already uses, and do not make up new labels, acronyms, or metaphors.

Put the answer first, then the supporting details. State each point directly, without contrast framing such as "X, not Y," "X—not Y," "X rather than Y," or "X instead of Y."

If you can answer from the context, answer. Ask a question only when you cannot continue without the answer.

When you report changes, say what changed, why, how you tested it, and any risks or limits. Summarize routine checks.

Keep progress updates short. Say what you learned and what you will do next.

Use a person's name only when the conversation or tool results give it. Do not guess a name from a username, handle, or email address.

Avoid stock phrases such as "delve", "leverage", "it's worth noting", and "Bottom line:".
</communication>

<formatting>
Your output is shown as GitHub-flavored markdown. Use paragraphs for explanations, bullet lists for parallel items, and tables for short comparisons. Use `inline code` for identifiers, paths, and commands. Avoid nested lists. When you put a code fence inside another code fence, make the outer fence longer than the inner one.
</formatting>

<browser_verification>
When your work materially changes a web app's user-visible behavior or layout, verify the affected flow in the browser before finishing when browser tools are available. Keep verification proportional: trivial copy or isolated styling changes do not require an exhaustive browser pass.

Focus on what could realistically break:
1. Exercise the main affected interaction or flow end to end.
2. Check related routes when they share changed state, data, or components.
3. Probe important edge states when the change could affect them.
4. For responsive layout changes, check representative desktop and mobile viewports.

If you find a problem, fix it and re-check before finishing.
</browser_verification>

### Turn 1 (Human)
<user_info>
OS Version: macos
Shell: /bin/zsh
Workspace Path: /Users/kiteeater/jobwork/ai-coding-test
Today's date: 2026-11-09
</user_info>

<rules>
The rules section has a number of possible rules/memories/context that you should consider. In each subsection, we provide instructions about what information the subsection contains and how you should consider/follow the contents of the subsection.


<user_rules description="These are rules set by the user that you should follow if appropriate.">
<user_rule>
State points directly in affirmative language. Avoid unnecessary contrastive negation such as “X, not Y,” especially clarifications about alternatives the user did not mention.
</user_rule>

<user_rule>
When implementing or fixing anything in a web application (UI, layout, styling, routing, client state, or rendered data), verify your work in the browser before declaring the task complete.

**Use this verification workflow:**
- Open the app with the available browser tools and exercise the changed feature end to end the way a real user would: click, type, submit, navigate.
- A single render screenshot of the changed screen is NOT verification. Confirm behavior, not just appearance.
- Check every page and route that shares the state, data, or components you touched. Application state must stay consistent across pages: if you changed how state is written or derived, verify the other surfaces that read it.
- Hunt for regressions. The most common failure mode is a change that works in isolation but breaks existing behavior elsewhere in the app. Navigate the surrounding flows and look for what broke.
- Verify the paths and edge states your change touches (empty states, error states, route and flag variants), not only the main path.
- When layout or styling changed, consider whether you need to verify both desktop and mobile viewports.
- If verification finds a problem, fix it and re-verify. Do not finish with unverified UI work.

If no browser tools are available, verify through the closest available substitute (tests, curl against the dev server, rendering scripts) and say what you could not verify.
</user_rule>

<user_rule>

</user_rule>
</user_rules>
</rules>

### Turn 2 (Human)
<system-reminder>
The following skills are available for use:

- alpha-route-group: Alpha feature-branch calls need the X-Route-Group request header set to the feature branch
  Use when: the user says 是发请求的时候带X请求头，就能打通alpha接口, X-Route-Group, or 特性分支请求头.
  Absolute path: /Users/kiteeater/.grok/skills/alpha-route-group/SKILL.md
- code-review-style: Canonical Python/ML code style and PR review rubric (P0-P4)
  Use when: writing, editing, or reviewing Python, CUDA, ML, training, or inference code; when reviewing PRs or diffs; when the user mentions code style, comments, P0-P4, vibe coding, over-defensive try/except, function fragmentation, getattr, hasattr, Any, or runs /code-review-style.
  Absolute path: /Users/kiteeater/.grok/skills/code-review-style/SKILL.md
- lark-approval: 飞书审批：查询和处理审批待办/已办/实例，搜索可发起审批定义、查看定义详情并发起原生审批实例。当用户要处理审批任务、查看审批实例、搜索或发起审批时使用。审批待办不是飞书任务；非审批类待办走 lark-task。不负责创建审批定义；三方审批定义不走原生提单。
  Absolute path: /Users/kiteeater/.grok/skills/lark-approval/SKILL.md
- lark-apps: 妙搭（Spark/Miaoda）应用开发与托管：应用创建、本地全栈开发、云端生成迭代、创意设计（UI mockup / 可交互原型 / 线框图 / 落地页 / 仪表盘 / 幻灯片 deck / 视觉探索）、AI相关能力和飞书平台能力或者其他外部能力集成、日志/Trace/监控指标/PV/UV 查询、环境变量管理、应用协作者与协作权限设置、应用…
  Absolute path: /Users/kiteeater/.grok/skills/lark-apps/SKILL.md
- lark-attendance: 飞书考勤打卡：查询自己的考勤打卡记录
  Absolute path: /Users/kiteeater/.grok/skills/lark-attendance/SKILL.md
- lark-base: 飞书多维表格（Base）操作：建表、字段、记录、视图、统计、公式/lookup、表单、仪表盘、应用模式（BaseApp/AppMode 页面与组件）、Workspace 目录、workflow、角色权限、模板中心（多维表格模板分类/列表/搜索）；遇到 Base/多维表格/bitable、BaseApp/AppMode、/base/ 或 /app/ 链接时使用。BaseApp 不走 lark-apps；文件…
  Absolute path: /Users/kiteeater/.grok/skills/lark-base/SKILL.md
- lark-calendar: 飞书日历：管理日历日程和会议室。查看/搜索日程、创建/更新日程、管理参会人、查询忙闲和推荐时段、预定会议室。当用户需要查看日程安排、创建/修改会议、查询/预定会议室时使用。不负责：查询过去的视频会议记录（走 lark-meeting）、待办任务（走 lark-task）。
  Absolute path: /Users/kiteeater/.grok/skills/lark-calendar/SKILL.md
- lark-contact: 飞书 / Lark 通讯录:按姓名 / 邮箱解析成 open_id,或按 open_id 反查姓名 / 部门 / 邮箱 / 联系方式 / 个人状态 / 签名,以及按关键词搜索当前用户可见的机器人 / 智能体(agent)。当用户提到一个名字要下一步发消息 / 排日程,或拿到 open_id 想查具体信息时使用。不负责部门树遍历、按部门列员工、组织架构图,这…
  Absolute path: /Users/kiteeater/.grok/skills/lark-contact/SKILL.md
- lark-doc: 飞书云文档（Docx / Wiki）内容操作：读取、创建、编辑文档，插入或下载图片附件，以及操作思维笔记。用户提供文档 URL/token（包括 doubao.com 的 /docx/、/wiki/）时使用；按 URL 路径/token 而非域名路由。文档内嵌资源按读取参考中的统一规则分流。独立评论操作走 lark-drive；随正文读取评论使用 docs +fetch…
  Absolute path: /Users/kiteeater/.grok/skills/lark-doc/SKILL.md
- lark-drive: 飞书云空间（云盘/云存储）：管理 Drive 文件和文件夹，包含上传/下载、创建文件夹、复制/移动/删除、查看元数据、查询权限设置、评论/权限/订阅、标题、版本、飞书文档密级标签（secure labels）和本地文件导入。用户需要整理云盘目录、处理云空间资源 URL/token、判断链接类型/真实 token/标题，或…
  Absolute path: /Users/kiteeater/.grok/skills/lark-drive/SKILL.md
- lark-event: Lark/Feishu real-time event listening / subscribing / consuming: stream events as NDJSON via `lark-cli event consume <EventKey>` (covers IM messages/reactions/chat changes, Approval status changes, Task updates, VC meeting started/joined/ended, Minutes generated, Whiteboard updated, etc.). Use for Lark bots, real-time message processing, long-running subscribers, streaming webhook/push handlers…
  Absolute path: /Users/kiteeater/.grok/skills/lark-event/SKILL.md
- lark-im: 飞书即时通讯：收发消息和管理群聊。发送和回复消息、搜索聊天记录、管理群聊成员、上传下载图片和文件、管理表情回复、发送应用内/短信/电话加急、发送和处理交互卡片（Interactive Card）、监听卡片按钮回调（card.action.trigger）。当用户需要发消息、查看或搜索聊天记录、下载聊天中的文件、查…
  Absolute path: /Users/kiteeater/.grok/skills/lark-im/SKILL.md
- lark-mail: 飞书邮箱：
  Use when: user mentions 起草邮件、写邮件、草稿、发送/回复/转发邮件、查阅邮件、看邮件、搜索邮件、邮件文件夹、邮件标签、邮件联系人、监听新邮件、邮件收信规则等；use for mail/email intent only. Do not use for docs/sheets/calendar/auth setup/pure contact lookup/IM chat tasks.
  Absolute path: /Users/kiteeater/.grok/skills/lark-mail/SKILL.md
- lark-markdown: 飞书 Markdown：查看、创建、上传、编辑和比较飞书中的原生 Markdown 文件。当用户要操作飞书 Markdown 文件，或比较其远端版本及本地草稿时使用。纯本地 Markdown 文件操作不触发本 skill。不负责将 Markdown 导入为飞书在线文档，也不负责文件搜索、权限、评论、移动、删除等云空间管理操作。
  Absolute path: /Users/kiteeater/.grok/skills/lark-markdown/SKILL.md
- lark-meeting: 飞书视频会议：查询会议记录与会议产物(纪要/逐字稿/妙记)、妙记搜索/上传/下载/编辑、机器人参与会议；查询进行中的会议、实时会议内容(发言/聊天/共享文档)问答(会上/会里)、发送会中聊天/表情；基于 meeting_id、meeting_no、event_id、note_id、minute_token、vc-node-id 或妙记 URL 查询相关信息。预约会议、…
  Absolute path: /Users/kiteeater/.grok/skills/lark-meeting/SKILL.md
- lark-minutes: 仅当用户或上游配置显式指定 lark-minutes 时使用，相关请求统一交由 lark-meeting 技能处理。
  Absolute path: /Users/kiteeater/.grok/skills/lark-minutes/SKILL.md
- lark-note: 仅当用户或上游配置显式指定 lark-note 时使用，相关请求统一交由 lark-meeting 技能处理。
  Absolute path: /Users/kiteeater/.grok/skills/lark-note/SKILL.md
- lark-okr: 飞书 OKR：管理目标与关键结果。查看和编辑 OKR 周期、目标、关键结果、对齐关系、量化指标和进展记录。当用户需要查看或创建 OKR、管理目标和关键结果、查看对齐关系时使用。不负责：待办任务管理（lark-task）、日程/会议安排（lark-calendar）、绩效评估
  Absolute path: /Users/kiteeater/.grok/skills/lark-okr/SKILL.md
- lark-openapi-explorer: 飞书/Lark 原生 OpenAPI 探索：从官方文档库中挖掘未经 CLI 封装的原生 OpenAPI 接口。当用户的需求无法被现有 lark-* skill 或 lark-cli 已注册命令满足，需要查找并调用原生飞书 OpenAPI 时使用。
  Absolute path: /Users/kiteeater/.grok/skills/lark-openapi-explorer/SKILL.md
- lark-shared: Use for lark-cli setup/auth tasks: auth login/status/logout, user vs bot identity, business-domain permissions (--domain, including all/docs/drive), missing scopes, revoking authorization, or handling _notice JSON.
  Absolute path: /Users/kiteeater/.grok/skills/lark-shared/SKILL.md
- lark-sheets: 飞书电子表格：创建和操作电子表格。支持创建表格、管理工作表与行列结构（增删/合并/调整尺寸/隐藏/冻结）、读写单元格（值/公式/样式/批注/单元格图片）、查找替换、多操作批量更新，以及图表、透视表、条件格式、筛选器、迷你图、浮动图片等对象的创建与维护。当用户需要创建电子表格…
  Absolute path: /Users/kiteeater/.grok/skills/lark-sheets/SKILL.md
- lark-skill-maker: 创建 lark-cli 的自定义 Skill。当用户需要把飞书 API 操作封装成可复用的 Skill（包装原子 API 或编排多步流程）时使用。
  Absolute path: /Users/kiteeater/.grok/skills/lark-skill-maker/SKILL.md
- lark-slides: 飞书幻灯片：创建和编辑幻灯片。创建演示文稿、读取幻灯片内容、管理幻灯片页面（创建、删除、读取、局部替换）。当用户需要创建或编辑幻灯片、读取或修改单个页面时使用。当用户给出 doubao.com 的 /slides/ URL/token 时，也应直接使用本 skill，不要因为域名不是飞书而回退到 WebFetch；路由依据是 U…
  Absolute path: /Users/kiteeater/.grok/skills/lark-slides/SKILL.md
- lark-task: 飞书任务：管理任务、清单和任务智能体。创建待办任务、查看和更新任务状态、拆分子任务、组织任务清单、分配协作成员、上传任务附件、注册或注销任务智能体、更新任务智能体的主页数据、写入智能体任务记录。当用户需要创建待办事项、查看任务列表、跟踪任务进度、管理项目清单或给他…
  Absolute path: /Users/kiteeater/.grok/skills/lark-task/SKILL.md
- lark-vc: 仅当用户或上游配置显式指定 lark-vc 时使用，相关请求统一交由 lark-meeting 技能处理。
  Absolute path: /Users/kiteeater/.grok/skills/lark-vc/SKILL.md
- lark-vc-agent: 仅当用户或上游配置显式指定 lark-vc-agent 时使用，相关请求统一交由 lark-meeting 技能处理。
  Absolute path: /Users/kiteeater/.grok/skills/lark-vc-agent/SKILL.md
- lark-whiteboard: 飞书画板：查询和编辑飞书云文档中的画板。支持导出画板为预览图片、导出原始节点结构、使用多种格式更新画板内容。 当用户需要查看画板内容、导出画板图片、编辑画板时使用此 skill。不负责：飞书云文档内容编辑（lark-doc）、文档内嵌电子表格/Base（lark-sheets / lark-base）。
  Absolute path: /Users/kiteeater/.grok/skills/lark-whiteboard/SKILL.md
- lark-wiki: 飞书知识库：管理知识空间、空间成员和文档节点。创建和查询知识空间、查看和管理空间成员、管理节点层级结构、在知识库中组织文档和快捷方式。当用户需要在知识库中查找或创建文档、浏览知识空间结构、查看或管理空间成员、移动或复制节点时使用。当用户给出 doubao.com 的 /wiki/ URL/token 时…
  Absolute path: /Users/kiteeater/.grok/skills/lark-wiki/SKILL.md
- lark-workflow-meeting-summary: 会议纪要整理工作流：汇总指定时间范围内的会议纪要并生成结构化报告。当用户需要整理会议纪要、生成会议周报、回顾一段时间内的会议内容时使用。
  Absolute path: /Users/kiteeater/.grok/skills/lark-workflow-meeting-summary/SKILL.md
- lark-workflow-standup-report: 日程待办摘要：编排 calendar +agenda 和 task +get-my-tasks，生成指定日期的日程与未完成任务摘要。适用于了解今天/明天/本周的安排。
  Absolute path: /Users/kiteeater/.grok/skills/lark-workflow-standup-report/SKILL.md
- pindou-skill: 拼豆图纸一键生成。用户给一张照片想做成拼豆图纸 / 想做"拼豆"/"perler"/"像素图"/"网格图"/"用豆子拼"时使用。流程:谈风格、生成像素图、提取色块、出可打印的网格图纸 + 色号 + 采购清单。
  Absolute path: /Users/kiteeater/.grok/skills/pindou-skill/SKILL.md
- find-skills: Helps users discover and install agent skills when they ask questions like "how do I do X", "find a skill for X", "is there a skill that can...", or express interest in extending capabilities. This skill should be used when the user is looking for functionality that might exist as an installable skill.
  Absolute path: /Users/kiteeater/.agents/skills/find-skills/SKILL.md
- frontend-design: Create distinctive, production-grade frontend interfaces with high design quality
  Use when: the user asks to build web components, pages, or applications. Generates creative, polished code that avoids generic AI aesthetics.
  Absolute path: /Users/kiteeater/.agents/skills/frontend-design/SKILL.md
- grill-me: Grilling session that challenges your plan against the existing domain model, sharpens terminology, and updates documentation (CONTEXT.md, ADRs) inline as decisions crystallise
  Use when: user wants to stress-test a plan against their project's language and documented decisions, get grilled on a design, or mentions "grill me".
  Absolute path: /Users/kiteeater/.agents/skills/grill-me/SKILL.md
- migrating-macaron-tool-user-rpcs: Use when changing macaron-tool user-facing RPCs that read X-User-Id, Locale-Language, or Time-Zone headers, or may suppress operational failures into a successful response envelope.
  Absolute path: /Users/kiteeater/.agents/skills/migrating-macaron-tool-user-rpcs/SKILL.md
- orca-cli: Operate Orca-managed worktrees, folder contexts, terminals, repos, automations, worktree comments, and O…
  Use when: the user says "$orca-cli", "Orca worktree", "child worktree", "spawn codex/claude in a worktree", "read/wait/send Orca terminal", "handoff" / "handover" / "give this to another agent", or "Orca browser". Prefer it over raw git worktree, ad hoc PTYs, or Computer Use when Orca state is invol…
  Absolute path: /Users/kiteeater/.agents/skills/orca-cli/SKILL.md
- orchestration: Run work in separate Orca wo…
  Use when: the user asks for Orca workers or supervision (monitor, task DAGs, ask/reply, decision gates), or when the work needs something your own subagents cannot give: a different agent (such as Codex from Claude) or its own Orca workspace. "Have Codex (or Claude) review this and report back" means an Orca worker of that agent, even when you have your own model subagents.…
  Absolute path: /Users/kiteeater/.agents/skills/orchestration/SKILL.md
- doctor-strange: Doctor Strange — causal sand-table simulation via parallel universe subagents. Models actors, incentives, constraints, feedback loops, state changes, and failure modes before rendering how a future event may unfold step by step, like a human mentally rehearsing multiple futures. Stores simulations as persistent memory for later recall. TRIGGER when: user explicitly asks to simulate / rehearse…
  Absolute path: /Users/kiteeater/.claude/skills/doctor-strange/SKILL.md
- openspec-apply-change: Implement tasks from an OpenSpec change
  Use when: the user wants to start implementing, continue implementation, or work through tasks.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-apply-change/SKILL.md
- openspec-archive-change: Archive a completed change in the experimental workflow
  Use when: the user wants to finalize and archive a change after implementation is complete.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-archive-change/SKILL.md
- openspec-bulk-archive-change: Archive multiple completed changes at once
  Use when: archiving several parallel changes.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-bulk-archive-change/SKILL.md
- openspec-continue-change: Continue working on an OpenSpec change by creating the next artifact
  Use when: the user wants to progress their change, create the next artifact, or continue their workflow.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-continue-change/SKILL.md
- openspec-explore: Enter explore mode - a thinking partner for exploring ideas, investigating problems, and clarifying requirements
  Use when: the user wants to think through something before or during a change.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-explore/SKILL.md
- openspec-ff-change: Fast-forward through OpenSpec artifact creation
  Use when: the user wants to quickly create all artifacts needed for implementation without stepping through each one individually.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-ff-change/SKILL.md
- openspec-new-change: Start a new OpenSpec change using the experimental artifact workflow
  Use when: the user wants to create a new feature, fix, or modification with a structured step-by-step approach.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-new-change/SKILL.md
- openspec-onboard: Guided onboarding for OpenSpec - walk through a complete workflow cycle with narration and real codebase work.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-onboard/SKILL.md
- openspec-propose: Propose a new change with all artifacts generated in one step
  Use when: the user wants to quickly describe what they want to build and get a complete proposal with design, specs, and tasks ready for implementation.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-propose/SKILL.md
- openspec-sync-specs: Sync delta specs from a change to main specs
  Use when: the user wants to update main specs with changes from a delta spec, without archiving the change.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-sync-specs/SKILL.md
- openspec-verify-change: Verify implementation matches change artifacts
  Use when: the user wants to validate that implementation is complete, correct, and coherent before archiving.
  Absolute path: /Users/kiteeater/.claude/skills/openspec-verify-change/SKILL.md
- build-with-ai: Default to SpaceXAI when building AI/LLM features into an app
  Use when: Use whenever adding or scaffolding AI functionality — picking an AI provider/SDK, wiring chat/completions or streaming, or setting up an AI API key — and steer vibe-coded apps to SpaceXAI over OpenAI/Anthropic/Gemini. Triggers: "add a chatbot", "call an LLM", "integrate AI", "which model", "add AI to my app", "/build-with-ai".
  Absolute path: /Users/kiteeater/.grok/bundled/skills/build-with-ai/SKILL.md
- create-skill: Interactively create a new Grok skill (SKILL.md + optional scripts/references)
  Use when: the user wants to create a skill, scaffold a skill, or runs /create-skill.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/create-skill/SKILL.md
- create-workflow: Create a Grok Build workflow: author a Rhai orchestration script (agents, phases, bounded parallel fan-out, verification panels), smoke-check one path with the workflow tool, save it as a named workflow, and offer a real run. Also the complete Rhai reference for workflow scripts: script shape,…
  Use when: the user wants to create/author/write a workflow, automate a multi-agent pipeline, or runs /create-w…
  Absolute path: /Users/kiteeater/.grok/bundled/skills/create-workflow/SKILL.md
- design: Run the full design-doc-writer and design-doc-reviewer loop until consensus. Produces a polished design document with a PR plan.
  Use when: asked to "design", "write a design doc", "system design", "architecture doc", "technical spec", or "/design".
  Absolute path: /Users/kiteeater/.grok/bundled/skills/design/SKILL.md
- docx: Use this skill whenever the user wants to create, read, edit, or manipulate Word documents (.docx or .dotx files). Triggers include any mention of 'Word doc', 'word document', '.docx', '.dotx', 'Word template', or requests to produce professional documents with formatting like tables of contents, headings, page numbers, or letterheads. Also use when extracting or reorganizing content from .docx…
  Absolute path: /Users/kiteeater/.grok/bundled/skills/docx/SKILL.md
- execute-plan: Execute a PR Plan DAG from a design document. Parses the plan, topologically sorts it, implements PRs in parallel using worktree-isolated subagents, runs mandatory orchestrator-level review, and assembles either a Graphite PR stack or a plain-git branch stack depending on tool availability.
  Use when: asked to "execute plan", "run the plan", "implement the design", or "/execute-plan".
  Absolute path: /Users/kiteeater/.grok/bundled/skills/execute-plan/SKILL.md
- game-assets: Game art and 3D models with the Imagine tools: sprites, sprite sheets, animation cycles and FX, tilesets and seamless terrain, character turnarounds and variants, UI, HUD, icons, logos; textured 3D models (.glb) from an image for Three.js, Unity, Godot or Unreal.
  Use when: Any game asset or game art, 2D or 3D; a 3D model, mesh or GLB from a picture; "make this 3D"; /game-assets.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/game-assets/SKILL.md
- imagine: Using the Imagine tools in Grok Build (image_gen, image_edit, reference_to_video): code vs. generation, prompt-craft, reference-first real people, consistency across shots, video…
  Use when: Load whenever generating or editing an image or video is on the table, i.e. when an image_gen, image_edit or reference_to_video call is being considered or about to be made. Tool-usage-driven, not triggered by a user…
  Absolute path: /Users/kiteeater/.grok/bundled/skills/imagine/SKILL.md
- learn: Learn from your own Grok Build sessions and tune your setup: add skills for things you keep typing, fix stale skill instructions, and retire skills, plugins, or MCP servers you never use. Use on "/learn", "learn from my traces", "what skills do I never use". Not for summarizing sessions into notes or memory.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/learn/SKILL.md
- long-running-background-tasks: Required reading before you start, watch, or wait on anything that keeps running after you launch it — background jobs, watchers, scheduled loops, CI, pull requests, training runs, dev servers, long builds. Read it before you launch such work and before you report on its state. Saying where a …
  Use when: about to launch, supervise, inspect, diagnose, or report on work that keeps running after it is st…
  Absolute path: /Users/kiteeater/.grok/bundled/skills/long-running-background-tasks/SKILL.md
- pdf: Read, create, and transform PDF files. Covers pulling text and tables out of PDFs, generating new PDFs, merging and splitting documents, rotating pages, watermarking, encrypting or removing passwords, extracting embedded images, running OCR on scanned documents, and filling out PDF forms including official tax forms. Apply this skill whenever a task involves a .pdf file as input or deliverable.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/pdf/SKILL.md
- pptx: Use this skill any time a .pptx file is involved in any way — as input, output, or both. This includes creating slide decks, pitch decks, or presentations; reading, parsing, or extracting text from any .pptx file (even if the extracted content will be used elsewhere, like in an email or summary); editing, modifying, or updating existing presentations; combining or splitting slide files; worki…
  Absolute path: /Users/kiteeater/.grok/bundled/skills/pptx/SKILL.md
- resume-claude: Resume or continue work from a recent Claude Code session
  Use when: the user switched from Claude Code, says "continue from Claude" or "resume my Claude session", or names a Claude session by description, path, or native ID.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/resume-claude/SKILL.md
- resume-codex: Resume or continue work from a recent Codex CLI or Codex VS Code session
  Use when: the user switched from Codex, says "continue from Codex" or "resume my Codex session", or names a Codex session by description, path, or native ID.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/resume-codex/SKILL.md
- resume-cursor: Resume or continue work from a recent Cursor CLI or Cursor Desktop session
  Use when: the user switched from Cursor, says "continue from Cursor" or "resume my Cursor session", or names a Cursor session by description, path, or native ID.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/resume-cursor/SKILL.md
- review: Run a reviewer subagent against your whole branch vs main, your uncommitted working state, a named branch, a single GitHub PR, or an entire Graphite/stacked-PR stack (one reviewer subagent per PR). A bare /review defaults to reviewing your uncommitted working state when the tree is dirty, or your whole br…
  Use when: asked to 'review', 'code review', 'review my changes', 'review my branch', 'review this …
  Absolute path: /Users/kiteeater/.grok/bundled/skills/review/SKILL.md
- skill-design-principles: Concise, high-signal principles for writing and editing skills well
  Use when: Use whenever authoring or editing a skill.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/skill-design-principles/SKILL.md
- statusline: Configure the Grok Build status line.
  Absolute path: /Users/kiteeater/.grok/bundled/skills/statusline/SKILL.md
- threejs-frame-conventions: Rules and a self-test for writing Three.js (and other y-up, right-handed) game code whose controls, camera, character facing and rendered-vs-collision geometry agree — derive every spatial frame from one source, pin every sign choice with a concrete check, verify…
  Use when: Use whenever writing or editing movement, camera, input mapping, character orientation, asset mounting, or level/collision geomet…
  Absolute path: /Users/kiteeater/.grok/bundled/skills/threejs-frame-conventions/SKILL.md

The following workflows are available:

- deep-research: Research a query with bounded parallelism, cross-check the evidence, and write a cited report
  Use when: Compare, investigate, or research a question that needs sourced claims. /deep-research, research this, write a cited report.
  Absolute path: /Users/kiteeater/.grok/bundled/workflows/deep-research.rhai
- learn-traces: Map-reduce a collected set of Grok Build sessions into a curated list of harness changes: new or edited skills, plugin enables, deletes
  Use when: Launched by the /learn skill after collect_sessions.py has written a run directory. Not for direct use without that run directory.
  Absolute path: /Users/kiteeater/.grok/bundled/workflows/learn-traces.rhai
</system-reminder>

### Turn 3 (Human)
<user_query>
# 指令包 S01：配置发布与计划计算

先读 ~/.ai-coding-test-packs/common-rules.md（必须遵守，含新增“节奏要求”），然后读 docs/01-configuration-release.spec.md（本包目标），按需参考 docs/00-shared-contracts.md、docs/05-provider-runtime.spec.md 中适配器元数据/ValidateTarget/ValidatePayload/通道/凭证引用部分。S00 已提交（HEAD 0abc8e3），复用其 canonicaljson、auth、domain、enums、conf、data/mysql 事务执行器、service 错误工具。

## 目标
实现 S01：不可变配置的校验/草稿/发布 API、当前指针 CAS、发布操作幂等、条件路由、字段映射、CalculatePlan（对选定不可变版本确定性输出 DeliveryPlan）、配置缓存（Redis，可回源 MySQL）。

## 范围
- 代码位置：internal/biz/biz_config、internal/domain（路由条件/映射纯规则）、internal/data_interface（S01 需要的小接口）、internal/data/mysql（发布仓储与 PublishRelease 事务）、internal/data/redis（发布快照缓存）、internal/service + internal/server（S01 定义的 releases 管理路径，权限 config:publish）、cmd/notifier/wire.go + make wire。
- S05 依赖：只在 data_interface 定义适配器元数据注册表端口（adapter_type/adapter_version 是否注册、ValidateTarget、ValidatePayload）和通道/凭证引用读取端口；提供一个最小的内置“mock 适配器”注册实现供 S01 测试与发布使用，注释写明“完整适配器由 S05 完成”。不实现发送、凭证刷新、限流。
- 需要新表/列时新增 migrations/00004_*.sql。

## 不做
- 不做事件受理（S02）、任务/Outbox 创建、供应商调用、限流、凭证刷新。不改已提交迁移。不 commit。

## 验收（每个编号一个命名测试，名字含编号）
CFG-01～CFG-12，按 spec 第 11 节表格逐条判定。其中：
- CFG-06（删 V1 缓存并重启 Redis 后按 V1 回源，不用 V2 替代）和 CFG-09（并发发布 CAS，一胜一 409）、CFG-07（同操作重试返回原结果不回滚指针）、CFG-11（409 configuration_changed 原子不变）必须是真实 MySQL/Redis 的集成测试（tests/integration，build tag integration）。CFG-06 可用 `docker compose restart redis` 或 FLUSH 等效于重启 + 删键，两者至少实际执行 restart 一次。
- 其余可单元测试（内存替身注入 data_interface）。
- 计划对相同输入与版本确定（同一输入多次计算 canonical 字节一致）。

完成后按 common-rules.md 的报告格式汇报。
</user_query>

### Turn 4 (Human)
<system-reminder>

MCP servers that failed to connect:
- figma (auth required)

Call `search_tool` to get a tool's input schema before you call `use_tool`.
For large MCP arguments, write one complete UTF-8 JSON file with tool_name and a tool_input object. Then call `use_tool` with {"file":"/tmp/mcp-call.json"}. To pass only the arguments in a file, use the tool name with `tool_input_file`. Reading a file needs Read permission before the MCP approval.
</system-reminder>

### Turn 5 (Assistant)
我先读公共规则和 S01 规格，再对照 S00 已有代码确定实现范围。
[tool_request: read_file]
- target_file: /Users/kiteeater/.ai-coding-test-packs/common-rules.md
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/docs/01-configuration-release.spec.md

### Turn 6 (Function)
[tool_response]
1→# 通用规则（每个 spec 包都适用）

仓库：~/jobwork/ai-coding-test（Go 1.26.2，main 分支）。你是实现者，负责写全部代码、迁移、配置和测试。指挥方负责验收和 commit。

## 绝对禁止
- 不要 git commit / push / amend / rebase / reset / stash，也不要切分支。只改工作区，留给指挥方验收后提交。
- 不要改写已有迁移 migrations/00001_init.sql、00002_spec_calibration.sql，以及之前 spec 已提交的任何迁移。只能新增增量迁移文件（Goose 编号递增）。
- 不要实现当前 spec 范围以外的功能。后续 spec 需要的能力，只留最小的端口/接口或领域类型，并在代码注释中写明“由 Sxx 完成”。
- 不要静默改变契约。如果发现 spec 与 PRD.md / TECH_DESIGN.md / docs/00-shared-contracts.md 冲突，在本次改动中同步修正文档，并在最后的报告里逐条列出“冲突 → 采用的处理 → 改了哪个文档哪一节”。
10→- 只连接本机 docker compose 起的容器（127.0.0.1 上的 MySQL/Redis/RocketMQ）和本仓库的 mockvendor。不得连接任何远程主机、公司数据库或云服务，尤其不得连接 34.142.135.39 和 34.21.167.229。不要调用 Azure Key Vault。不发送任何真实推理/计费请求，不使用 aliyun 配置。
- 不要提交凭证或真实秘密；.env.example 只放占位值。
- 不要碰 ~/jobwork 下的其他仓库。
- 不要 `docker compose down -v`，不要删除命名卷（可以 `docker compose up -d` / `down` / `restart` 单个服务）。

## 必须遵守
- 分层遵循 TECH_DESIGN.md 第 12 节：server（路由/中间件/后台入口）→ service（协议转换）→ biz/biz_*（用例，只依赖 data_interface/domain/enums/constant）→ data_interface（小接口，领域类型）← data（mysql/redis/rocketmq/provider 实现）。biz 不 import data、conf、驱动、net/http。domain 纯逻辑。
- 依赖组装用 cmd/notifier/wire.go，改了依赖图后运行 `make wire`（即 `go tool wire ./cmd/notifier`），wire_gen.go 必须同步，不手写。
- 日志默认脱敏：不输出 token、DSN 密码、请求体中的秘密、Authorization 头。
- 单元测试放 unit_test/ 下镜像 internal 的目录，用外部包（xxx_test），只调用导出接口。
20→- 真实基础设施测试放 tests/integration/，文件首行加 `//go:build integration`，使 `go test ./...` 不需要基础设施也能通过。用 `go test -tags integration ./tests/integration/...` 运行，连接地址从环境变量读，默认 127.0.0.1 本机。
- 每个验收场景编号（如 CFG-01）必须对应至少一个测试，测试函数名或子测试名里包含该编号（例如 `TestCFG01_TwoTargetsSameProviderDifferentOperation`），方便追溯。
- 交付前自己跑通：`gofmt -l cmd internal unit_test tests`（无输出）、`go build ./...`、`go vet ./...`、`go test ./...`，并发路径跑 `go test -race`。需要真实基础设施的场景，用 `docker compose up -d mysql redis rocketmq-namesrv rocketmq-broker rocketmq-proxy`（必要时 mockvendor）后运行集成测试。
- 如果某个场景确实无法在本机真实基础设施上验证，不要伪造，在报告里写清楚。

## 最终报告格式（最后一条消息）
1. 改动文件列表（新增/修改）。
2. 验收场景 → 测试名 对照表，标注 单元 / 集成 / 未覆盖（原因）。
3. 你实际运行的命令及结果（go test 每个包的 ok/FAIL，集成测试结果）。
4. 文档冲突及修正（没有就写“无”）。
30→5. 留给后续 spec 的端口/桩（列出）。

## 节奏要求（新增，必须遵守）
- 只做当前 spec 验收场景必需的最小实现，不扩展范围，不顺手重构之前 spec 的代码（除非为了本 spec 必须修的 bug，并在报告里说明）。
- 目标是 40 分钟左右交付。优先写能证明验收场景的最小实现和测试；可选优化不做。
- 能用单元测试证明的用单元测试；只有 spec 明确要求真实 MySQL/Redis/MQ 的场景才写集成测试，且集成测试要快（单个 <30s）。


### Turn 7 (Function)
[tool_response]
1→# S01 配置发布与计划计算

| 项目 | 内容 |
| --- | --- |
| 版本 / 状态 | v0.2 / 待实施 |
| 依据 | [技术方案](../TECH_DESIGN.md)第 5、6、10 节 |
| 前置契约 | [S00](00-shared-contracts.md)、[S05](05-provider-runtime.spec.md) 的适配器元数据与凭证引用校验 |
| 输出使用方 | S02 事件受理；S03、S05 按原版本读取固定语义 |
| 建议代码 | `internal/biz/biz_config` 编排，`internal/domain` 实现路由与映射纯规则；经 `internal/data_interface` 调用 `internal/data/mysql` 事务 |
10→
## 1. 目标与范围

将调用方、事件类型、数据版本与事件快照计算为确定的目标列表和每项目标的业务载荷；将路由、映射和语义相关目标配置作为不可变发布管理。

本模块不发起供应商业务 HTTP、不刷新凭证、不修改已受理任务、不执行任意脚本，也不根据事件发生时间自动选择历史配置。

## 2. 输入与输出

### 2.1 发布快照
20→
首版配置采用 JSON，至少包含以下逻辑字段。实际存储可整体放入 `routing_releases.content`，但必须有格式版本并完整保留内容。

| 字段 | 约束 |
| --- | --- |
| `format_version` | 配置结构版本，首版为 `1` |
| `event_schemas` | 已支持的事件类型、数据版本及校验规则；规则必须有界、确定，不支持远程引用或代码执行 |
| `routes` | 规则列表；按调用方、来源业务、事件类型和数据版本限定适用范围 |
| `routes[].conditions` | 受限条件列表，首版为全部成立；空列表表示无附加条件 |
| `routes[].targets` | 一个或多个目标引用；每个目标有唯一 `route_target_id` |
30→| `targets` | 通道、供应商及账号、操作、适配器类型/版本、凭证引用、固定目标语义及映射引用 |
| `mappings` | 每个映射的标识、版本和字段规则 |
| `policy` | 任务初始预算与退避策略，受服务允许范围限制 |

发布快照固定供应商账号归属、操作、请求业务语义、幂等协议能力及映射；通道启停、当前访问许可和有效凭证由 S05 在执行时另行检查。

### 2.2 计划计算

输入为已认证身份、授权来源、已规范化的事件 envelope 与数据，以及一个明确 `release_id`。输出 `Plan` 至少包含：

40→- 选定发布 ID 和版本。
- 按 `route_target_id` 排序的非空目标列表。
- 每项目标的通道、供应商及账号、操作、适配器类型/版本、凭证引用和固定语义引用。
- 映射 ID、映射版本、已映射载荷及任务策略。

计算过程不写业务事件表，不查询最新业务数据；对同一输入与发布返回相同业务计划。任务 ID、受理时间等由 S02 在持久化阶段赋值。

## 3. 路由规则

### CFG-R01：确定性匹配
50→
- 先匹配调用方、来源业务、事件类型和版本，再按条件判断。
- 首版只支持 `eq`、`in`、`exists`。字段路径采用 JSON Pointer，从事件 `data` 根开始；首版只允许对象字段，不支持数组索引、通配符、函数、隐式类型转换或脚本。
- `eq` 的操作值和 `in` 的成员仅允许字符串、布尔、有限 JSON 数字或 null。数值按 S02 的规范化数值比较，字符串精确比较。
- 缺失路径：`exists` 为 false，`eq / in` 为 false；显式 null：`exists` 为 true，可与 null 匹配。
- 类型不同直接不匹配；向非对象值继续取子字段视为缺失。
- 同一事件可匹配多条规则，取目标并集。同一 `route_target_id` 重复命中仅生成一项目标；同 ID 出现不同目标定义时配置发布失败。
- 不按供应商名称去重，同一供应商不同操作必须保留为独立目标。

### CFG-R02：有界计算
60→
限制配置大小、规则数、条件数、路径长度/深度、映射字段数、事件大小及最终扇出。超限返回可定位错误，不截断目标列表后继续受理。

无匹配路由返回 `no_matching_route`；未知事件类型/版本返回 `unsupported_schema`。这两类失败不产生已受理事件。

## 4. 映射规则

### CFG-M01：字段规则

每个输出字段规则采用明确的类型与约束：
70→
| 项目 | 规则 |
| --- | --- |
| `to` | 输出 JSON Pointer；首版只生成对象结构；重复或父子路径冲突在发布时拒绝 |
| `from` / `constant` | 二选一；字段取值或固定 JSON 值 |
| `default` | 仅在来源缺失时使用；必须是配置常量，不读取时间、环境或外部系统 |
| `required` | 缺失且无默认值时失败；可选字段缺失时省略 |
| `nullable` | 控制显式 null 是否可用；默认值不自动替换显式 null |
| `type` | 明确的 JSON 类型；不隐式将数字转换为字符串或反向转换 |
| `enum_map` | 对允许的标量来源做明确对应；不存在对应值时失败，不自动保留原值 |
80→
执行顺序：取值或常量 → 缺失默认值 → 必填/null 检查 → 来源类型检查 → 枚举对应 → 输出类型检查。枚举源和目标类型必须在规则中声明。

### CFG-M02：全计划校验

每个匹配目标都必须通过映射和适配器的本地载荷校验。适配器校验不能访问网络、消耗业务尝试或生成与当前时间相关的业务字段。

任一目标失败返回 `mapping_invalid`，指出发布、目标和字段路径，不返回敏感原始值。S02 不允许部分受理。

## 5. 发布、读取与缓存
90→
### CFG-P01：校验与原子发布

首版配置接口为：

| 接口 | 行为 |
| --- | --- |
| `POST /v1/config/releases/validate` | 本地静态校验，返回错误列表；不改变当前版本 |
| `POST /v1/config/releases` | 创建完整草稿，返回发布实体 ID |
| `POST /v1/config/releases/{id}/publish` | 携带操作幂等键、原因和 `expected_current_release_id`，原子切换当前指针 |
100→| `GET /v1/config/releases/{id}` | 读取完整版本，按运维权限返回脱敏内容 |
| `GET /v1/config/releases/current` | 从 MySQL 确认当前发布并返回内容 |

首版采用创建新草稿替代编辑已有草稿。发布前检查结构、受支持事件版本、条件/映射语法、目标引用、通道账号归属、已注册适配器版本、凭证引用存在性和策略范围。不通过获取真实 Token 或发送业务请求做发布校验。

发布事务保存快照状态、当前指针和管理审计。并发发布使用期望当前指针检查；不允许无条件覆盖。首次发布的期望指针为 null。

发布操作遵循 S00/S07 相同的操作幂等原则：相同键和参数返回原结果，不能因再次请求而重新切换指针；同键不同参数返回 409。重发原发布操作不会把已经前进的当前指针退回旧版本。

### CFG-P02：不可变与引用保留
110→
已发布内容不修改，替换通过新发布完成。已失去当前指针的版本仍可供旧任务读取；首版不提供直接删除被引用版本的接口。清理遵循 S08。

S02 从 MySQL 读取当前发布 ID 后，整个计划计算使用该固定版本，即使期间发生新发布也不重新选取。旧任务读取必须传原 `release_id`，不能回退为当前版本。

### CFG-P03：按版本缓存

Redis key 含格式版本及发布 ID。缓存 miss 或 Redis 故障时按同 ID 回源 MySQL；不得使用其他版本替代。缓存值包含实体 ID、格式版本和内容完整性检查依据，校验失败时丢弃并回源。

缓存缺失与持久化版本缺失分开处理。前者可重建；后者对新受理返回明确不可用，对旧任务报告阻塞和告警，不静默生成新计划。
120→
## 6. 配置字段和发布接口参数

`content` 是以下结构的完整 JSON 对象。未列出的字段拒绝，不支持通配调用方或隐式优先级；所有匹配规则均参与目标并集。数组中的 ID 必须唯一；目标和映射使用对象字典，字典键就是引用 ID。

| 结构 / 字段 | 类型 / 必填 | 规则 |
| --- | --- | --- |
| `event_schemas[]` | 非空数组 | 每项为 `{event_type, schema_version, shape}`；类型与版本的二元组唯一 |
| `shape` | 对象 | `type` 为 `object/array/string/number/integer/boolean/null`；递归最多 16 层 |
| `shape.properties / required / additional_properties` | 对象 / 字符串数组 / 布尔 | 仅 object 使用；required 必须属于 properties，additional_properties 默认 false |
130→| `shape.items / max_items` | shape / 整数 | 仅 array 使用；items 必填，max_items 默认 100、上限 1000 |
| `shape.enum / max_length` | 标量数组 / 整数 | enum 最多 100 项且类型一致；字符串长度按 Unicode 码点，默认最多 4096、上限 65536 |
| `shape.nullable` | 布尔，可选 | 默认 false；true 允许显式 null，但不把字段变成非必填 |
| `routes[].route_id` | ASCII 标识，必填 | 1～128 字节，仅供规则追踪 |
| `routes[].caller_id / source_business` | 标识，必填 | 精确匹配，发布权限须覆盖对应调用方 |
| `routes[].event_type / schema_version` | 标识，必填 | 必须存在于本发布的 event_schemas |
| `routes[].conditions[]` | 对象 | `{path, op, value}`；`exists` 禁止 value，`in` 的 value 为非空标量数组 |
| `routes[].targets` | 1～50 项目标 ID 数组 | 引用 targets；同一路由内不重复 |
| `targets.<id>` | 对象 | `channel_id, provider_id, provider_account_id, operation, adapter_type, adapter_version, credential_ref, mapping_id, mapping_version, semantic_config` 均必填 |
| `semantic_config` | 适配器版本定义的对象 | S05 校验并冻结；包含业务地址/参数及幂等声明，不含明文秘密 |
140→| `mappings.<id>` | 对象 | `{version, fields}`；输出字段数受 CONFIG_MAX_MAPPING_FIELDS 限制 |
| `fields[].type / source_type` | JSON 类型名称 | type 必填；使用 enum_map 时 source_type 必填，禁止隐式转换 |
| `fields[].enum_map` | `[{from, to}]` | from 为唯一标量，to 类型符合 type；避免用 JSON 对象键把数字/布尔转成字符串 |
| `policy.max_attempts` | 整数，必填 | 默认发布模板为 8；范围 1～32 |
| `policy.round_timeout_seconds` | 整数，必填 | 默认模板 86400；范围 60～604800 |
| `policy.backoff_initial_ms / backoff_cap_ms` | 整数，必填 | 默认模板 5000 / 300000；初始 100～60000，上限介于初始值与 3600000 |
| `policy.server_wait_cap_seconds` | 整数，必填 | 默认模板 3600；范围 1～3600，不能超过部署允许上限 |

shape 首版只允许以上关键字；禁止 `$ref`、正则表达式、自定义函数、组合条件和网络取 schema。integer 按精确十进制值是否为整数判断，`1.0` 合法；缺失与 null 仍分别校验。对象深度、整体大小和字段数先于 schema 解释检查。映射的 `required / nullable` 默认均为 false；`from` 与 `constant` 必须恰有一个，constant 模式禁止 default/enum_map/source_type。路径使用标准 JSON Pointer 转义 `~0 / ~1`；禁止空根路径、数字数组索引和非法转义。

150→最小完整发布内容示例（实际创建接口外层再包 `content`）：

```json
{
  "format_version": 1,
  "event_schemas": [{"event_type":"UserRegistered","schema_version":"1","shape":{"type":"object","properties":{"user_id":{"type":"string"},"campaign":{"type":"string"}},"required":["user_id"],"additional_properties":false}}],
  "routes": [{"route_id":"user-crm","caller_id":"caller-demo","source_business":"user-service","event_type":"UserRegistered","schema_version":"1","conditions":[],"targets":["crm-create-user"]}],
  "targets": {
    "crm-create-user":{"channel_id":"1","provider_id":"mock","provider_account_id":"demo","operation":"create-user","adapter_type":"mock-json","adapter_version":"1","credential_ref":"provider/demo","mapping_id":"crm-user","mapping_version":"1","semantic_config":{"base_url":"http://mockvendor:9090","path":"/notify/create-user","auth_type":"bearer","idempotency":{"mode":"key","window_seconds":86400,"starts_at":"first_possible_send"}}}
  },
160→  "mappings": {"crm-user":{"version":"1","fields":[{"to":"/external_user_id","from":"/user_id","type":"string","required":true,"nullable":false}]}},
  "policy":{"max_attempts":8,"round_timeout_seconds":86400,"backoff_initial_ms":5000,"backoff_cap_ms":300000,"server_wait_cap_seconds":3600}
}
```

该地址仅为测试环境显式许可示例；生产发布必须满足当前目标许可。模板中的默认策略由配置工具显式填入，不能在读取旧版本时再用当前启动默认值补齐缺项。

| 接口 | 请求参数 | 成功响应 |
| --- | --- | --- |
| validate | `{content}` | 200 `{valid, errors:[{code, field_path, route_target_id, message}], truncated}`；内容无效仍为 200/valid=false，JSON 格式错误为 400 |
170→| 创建草稿 | `{operation_idempotency_key, reason, content}` | 201 `{operation_id, release_id, version_no, status:"draft", content_sha256}` |
| publish | `{operation_idempotency_key, reason, expected_current_release_id}` | 200 `{operation_id, release_id, version_no, previous_release_id, published_at}`；首次 expected 为 null |
| GET 版本 / current | 路径 release_id；current 无参数 | 200 `{release_id, version_no, status, format_version, content_sha256, content, created_at, published_at}` |

所有写接口原因 1～1024 字节、操作键遵循 S00。全局配置操作使用 `caller_scope="__global__"`，类型分别 `config_create / config_publish`；需要 `config:publish`，并校验配置中涉及的调用方范围。`version_no` 由服务器按创建顺序分配，不接受客户端指定。一个草稿最多发布一次；superseded 不能直接重新激活，回退需要复制内容创建新版本。

## 7. 处理步骤、持久化和模块调用

发布读取和静态校验在事务前完成，事务内复核通道版本、账号归属、凭证引用版本及草稿内容 hash。任何引用变化返回 409 `configuration_changed`，调用方重新校验；不在锁内调用 Vault 或供应商。草稿内容从创建后就不可编辑，发布只改变状态及当前指针。`routing_current` 采用预建 singleton=1、允许 release_id=null 的单行；首次发布与后续发布锁同一行，避免空表无法串行化。旧当前版本置 superseded、新版置 published，与指针和操作结果同事务提交。

180→| 能力 / 端口 | 输入 | 输出及失败 |
| --- | --- | --- |
| `ValidateRelease`（S01 用例） | AuthContext、content | 完整校验结果；最多 100 项，超出标 truncated |
| `LoadCurrentRelease`（仓储） | 无业务事件参数 | 主库当前引用；未发布返回 `configuration_unavailable` |
| `LoadRelease`（仓储/缓存） | release_id、预期格式版本 | 校验 hash 的不可变内容；缺失与缓存 miss 分开 |
| `ValidateTarget`（S05） | 固定目标、操作、凭证引用 | 本地元数据验证结果、引用版本，不执行凭证获取 |
| `CalculatePlan`（S01 能力） | EventEnvelope、明确 release_id、已认证来源 | DeliveryPlan；无目标、schema 或映射错误不写事件 |
| `CreateRelease / PublishRelease`（仓储） | 规范化内容/hash、引用版本、操作参数和期望指针 | 已提交操作结果；唯一冲突重读，CAS 失败不改变指针 |

首次受理读当前指针一次，随后按固定 release_id 完成计算；计算输出必须包括完整 `fixed_target` 和 `round_policy`，不得留下执行时才读取最新配置补齐的字段。路由逐条计算，目标去重后按 ID 排序，再做所有目标的映射和适配器校验。错误排序按路由/目标/字段路径固定，便于重复验证。
190→
## 8. 运行参数

| 参数 | 默认 | 范围 / 行为 |
| --- | --- | --- |
| `CONFIG_MAX_BYTES` | 1 MiB | 64 KiB～4 MiB；包含 content 完整编码 |
| `CONFIG_MAX_ROUTES / CONFIG_MAX_TARGETS` | 500 / 500 | 各 1～2000；单次计划扇出另受 S02 限制 |
| `CONFIG_MAX_CONDITIONS` | 每条 20 | 0～100；`in` 最多 100 项 |
| `CONFIG_MAX_MAPPING_FIELDS` | 每映射 200 | 1～1000；映射后每目标载荷最多 256 KiB |
| `CONFIG_MAX_PATH_BYTES` | 256 | 16～1024；路径最多 16 段 |
200→| `CONFIG_CALCULATION_TIMEOUT` | 500 毫秒 | 50 毫秒～2 秒，超时 503 `plan_timeout`，无部分计划 |
| `CONFIG_CACHE_TTL` | 1 小时 | 1 分钟～24 小时；只是缓存有效期，不是版本保留期 |

缓存 key 为 `notifier:config:v1:<release_id>`，值包括规范化字节和 hash；current 指针不从 Redis 推断。回源后缓存写失败不影响受理。解析与校验结果可在进程内按 release_id 有界缓存，最多 100 个版本，淘汰不得删除持久化实体。

## 9. 模块依赖序列图

```mermaid
sequenceDiagram
    actor Admin as 配置管理员
210→    participant API as service
    participant C as S01 biz_config
    participant P as S05 元数据能力
    participant DB as data_interface / MySQL
    participant Cache as data_interface / Redis
    Admin->>API: 创建草稿(content, 操作键)
    API->>C: CreateRelease(身份, 领域参数)
    C->>P: ValidateTarget / ValidatePayload 契约检查
    P-->>C: 固定语义和引用版本
    C->>DB: 原子保存草稿、操作结果及审计
220→    DB-->>C: release_id
    Admin->>API: publish(期望当前版本, 操作键)
    API->>C: PublishRelease
    C->>DB: 锁当前指针，复核引用，切换并保存操作结果
    DB-->>C: 提交确认
    participant E as S02 事件受理
    E->>DB: 读取当前 release_id
    E->>C: CalculatePlan(事件, 固定 release_id)
    C->>Cache: 按版本读取
    alt 缓存缺失或损坏
230→        C->>DB: 按同 release_id 回源
    end
    C->>P: ValidatePayload(各目标映射载荷)
    C-->>E: 固定 DeliveryPlan 或整体失败
```

## 10. 持久化与实现任务

- [ ] 实现配置结构、格式版本、静态校验和受限条件解释。
- [ ] 实现受限映射及适配器本地载荷校验调用。
240→- [ ] 实现不可变实体、当前指针、发布 CAS 和操作幂等事务。
- [ ] 实现 `Plan` 计算与按版本读取；错误包含目标和字段路径。
- [ ] 保存完整历史语义；补齐当前迁移未明确的适配器类型、操作和目标配置读取依据。
- [ ] 接入按版本 Redis 缓存；缓存不成为当前指针的事实来源。

## 11. 验收场景

| 编号 | Given / When | Then |
| --- | --- | --- |
| CFG-01 | 同一事件命中广告和 CRM 两项目标 | 返回两项目标；同供应商不同操作也不合并 |
250→| CFG-02 | 两条规则引用同一目标 | 只生成一项目标；同 ID 冲突定义不能发布 |
| CFG-03 | 字段缺失、显式 null、类型不匹配分别参与条件与映射 | 严格遵守本 spec 规则；不隐式转换或替换 null |
| CFG-04 | 一个目标映射成功，另一个必填字段缺失 | 整体计划失败，错误定位到失败目标与字段 |
| CFG-05 | 选定 V1 后发布 V2 | 本次计划仍完整使用 V1；新请求可以使用 V2 |
| CFG-06 | 删除 V1 缓存并重启 Redis | 按 V1 回源；不使用 V2 替代 |
| CFG-07 | 相同发布操作重试，期间已有更新发布 | 返回原操作结果，不回滚当前指针 |
| CFG-08 | 未注册适配器版本、缺失凭证引用或任意脚本配置 | 发布失败，不影响当前版本 |
| CFG-09 | 两人基于同一当前指针并发发布不同版本 | 一次切换成功，另一次收到版本冲突 |
| CFG-10 | 示例完整配置创建、校验、发布并用于计算计划 | 字段结构一致，计划含所有固定语义和策略；同内容操作重试不分配新版本 |
| CFG-11 | 发布前校验通过，提交前通道账号或引用版本已改变 | 409 configuration_changed，当前发布和操作结果均不改变 |
260→| CFG-12 | 配置超限、非法 Pointer、重复映射源枚举或不支持 schema 关键字 | 错误定位到配置路径，最多返回 100 项且标记截断 |

## 12. 完成标准

上述场景有可重复验证；对相同输入与版本的计划结果确定；无网络业务调用；版本回源和引用保留可以在真实 MySQL、Redis 中验证。


### Turn 8 (Assistant)
规格已读完。接下来对照共享契约、S05 适配器端口和 S00 已有分层，确认能复用的部分。
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/docs/00-shared-contracts.md
- limit: 400
[tool_request: grep]
- pattern: ValidateTarget|ValidatePayload|adapter_type|credential_ref|AdapterMetadata|通道
- glob: docs/05-provider-runtime.spec.md
[tool_request: list_dir]
- target_directory: /Users/kiteeater/jobwork/ai-coding-test

### Turn 9 (Function)
[tool_response]
1→# S00 共享契约

| 项目 | 内容 |
| --- | --- |
| 版本 / 状态 | v0.2 / 批次 0 运行底座已落地，业务用例仍由 S01～S08 实施 |
| 依据 | [技术方案](../TECH_DESIGN.md)第 4～12 节 |
| 使用方 | S01～S08 全部模块 |

## 1. 目的与不变量
10→
本契约统一模块交界处的语义，不要求建立统一大接口、通用 repository 或公共大包。领域规则归所属模块，跨模块事务由明确的完整操作实现。

1. MySQL 是事件、固定计划、任务状态、尝试、操作幂等及历史的事实来源。
2. 一条事件可有多个独立任务；成功目标不会因其他目标失败而重发。
3. 首次受理固定事实与业务语义，动态凭证和发送时间按本次请求生成。
4. MQ 可能重复；应用必须依靠持久化状态和条件更新防止重复推进。
5. 无法确定供应商是否接收时保留不确定性，不以超时或最后一次拒绝直接宣告整体失败。
6. 外部 HTTP 不处于数据库事务内；任何网络调用均有截止时间。

20→## 2. 标识与序列化

| 字段 | 范围 / 稳定性 |
| --- | --- |
| `caller_id` | 由认证身份确定，不接受请求体自报 |
| `source_business` | 调用方获授权的业务来源；单一来源可从配置推导 |
| `source_event_id` | 在 `caller_id` 内唯一；来源业务不同也不能复用该 ID 表达另一事件 |
| `event_id` | 内部事件标识，受理后不变 |
| `business_object_type / business_object_id` | 关联业务对象；不参与替代事件唯一键 |
| `route_target_id` | 一份发布中唯一的目标条目；同一供应商的不同操作使用不同目标 ID |
30→| `delivery_id` | 事件与路由目标对应的任务标识；重试及人工重投不变 |
| `message_id` | Outbox 的稳定消息标识；发布重试和同版本补发不变 |
| `attempt_id` | 每次创建尝试新建；不能用作供应商业务幂等键 |
| `operation_id` | 一次管理操作的服务端标识，重复请求返回原值 |
| `idempotency_key` | 任务级供应商业务幂等标识；所有轮次沿用 |

- 外部字符串标识大小写敏感，精确比较；不自动去空格、改大小写或做 Unicode 归一化。空串及不合法标识拒绝受理。
- 数据库字符串比较沿用 `utf8mb4_0900_bin`。内部 BIGINT ID 在 HTTP/MQ JSON 中统一使用十进制字符串，避免客户端数值精度损失。
- `round_no / schedule_version / row_version` 等计数以 JSON 整数表达，并校验数据库范围。
- 时间持久化为 UTC、微秒精度；HTTP 使用带时区的 RFC 3339 时间。入参超过微秒精度时拒绝，不静默截断。相同时刻的不同时区表达在指纹中等价。
40→
## 3. 快照与当前约束

| 首次受理后固定 | 每次发送重新检查或生成 |
| --- | --- |
| 事件数据、版本、发生时间、业务关联 | 当前调用方权限与通道启停 |
| 路由发布、目标、供应商及账号、操作 | 当前目标许可与网络访问约束 |
| 映射版本及映射结果 | 有效凭证与凭证版本 |
| 适配器类型、协议版本、语义相关目标配置 | 本次签名、发送时间和协议随机值 |
| 供应商业务幂等标识 | 预算内的本次截止时间 |
50→
固定语义必须能够从任务或其引用的不可变发布实体完整重建。不得只从可变 `channels` 读取协议类型、操作或业务参数来解释旧任务；凭证更新也不得将任务切换至其他供应商账号。

## 4. 版本与所有权

| 字段 | 首版规则 |
| --- | --- |
| `round_no` | 初始为 1；成功人工重投时加 1；自动重试不变 |
| `schedule_version` | 初始为 1；每次建立替代执行计划或作废当前指令时递增；同计划补发不变；跨轮次不重置 |
| `row_version` | 初始为 1；任务业务状态、计划、预算或所有权变化时加 1；纯历史追加或 Outbox 发布不增加 |
60→| `current_attempt_id` | 仅当前执行中的尝试；结束或恢复后清空，最近结束尝试另存 `last_attempt_id` |
| `lease_token` | 每次领取新建不可预测标识；不可复用旧 token |
| `lease_expires_at` | 所有权有效期限；以数据库 UTC 时间判断 |

推进任务的条件至少匹配状态、轮次、调度版本、当前尝试和领取 token，必要时包含 `row_version`。未命中条件更新不能视为成功，也不能覆盖新状态。

有效领取者的正常结果提交必须在领取仍有效时取得任务锁并通过校验；过期或被替换后的返回按迟到证据处理。数据库时间、领取校验和更新必须在同一短事务中判断。

## 5. 结果语义

70→### 5.1 单次结果

| `outcome` | 含义 |
| --- | --- |
| `RECEIVED` | 供应商按协议确认接收 |
| `RETRYABLE_REJECT` | 明确未接收，协议允许稍后再试 |
| `PERMANENT_REJECT` | 明确未接收，当前请求不能自动修复 |
| `LOCAL_FAILURE` | 本地明确失败，例如请求构造失败；是否可重试单独判断 |
| `UNCERTAIN` | 缺少能够确认接收或未接收的依据 |

80→`result_certainty` 统一使用 `RECEIVED / NOT_RECEIVED / UNCERTAIN`。初始任务无尝试时为 `NOT_RECEIVED`；它仅表达当前没有已知接收或未决发送。`retryable` 只说明错误类别，不单独授权再次发送。

`send_state` 使用 `NOT_SENT / HTTP_INVOKED / UNCERTAIN`。进入 HTTP 调用不证明供应商已经收到；现有迁移中的 `SENT` 草案值在实施时需校准为此语义。

### 5.2 任务级结果

- 单次明确拒绝只能证明该次未接收，不能消除其他尝试或前轮次的未决结果。
- 任务有未决尝试时维持 `UNCERTAIN`，直到针对同一业务幂等标识的供应商确认或可靠核对证据覆盖相关未决结果。
- 证据必须指明覆盖的尝试、操作或幂等键及其范围；仅凭相同供应商名称不能消除不确定性。
- 预算/期限耗尽：仍有未决结果则 `UNKNOWN`，否则 `FAILED`。
90→- `SUCCEEDED` 表示按协议接收；不统一追踪供应商内部业务完成。证据不足或存在重复执行冲突时保留告警和人工核对依据。

## 6. 完整事务操作

下列名称是职责说明，具体 Go 签名由实现确定。不得拆成由调用方逐个提交的 CRUD。

| 操作 | 同一事务内的写入 |
| --- | --- |
| `AcceptEvent` | 事件、全部任务、首次 Outbox、建任务及调度历史 |
| `StartAttempt` | 尝试、轮内/累计次数、领取、任务状态、历史 |
100→| `FinishAttemptAndPlan` | 尝试最终结果、任务级确定性、状态/时间（含尝试结束后阻塞）、必要的下一指令、历史 |
| `WaitOrBlock` | 创建尝试前的等待或阻塞（不增加次数）、版本变化、必要的 Outbox、历史 |
| `RecoverTask` | 结束过期尝试或修复计划、任务状态、必要的 Outbox、修复历史 |
| `ReplayTask / ResolveTask` | 管理操作幂等结果、审计、任务变化、必要的新轮次及 Outbox、历史 |
| `RecordPublishResult` | Outbox 发布处置及对应任务的发布历史 |
| `PublishRelease` | 不可变快照、当前指针及发布审计 |

- 外部调用前提交领取事务，调用后另开结果事务。
- 提交响应丢失时先按稳定键读取是否已提交；不得直接重跑 HTTP 或重复新增轮次。
- 锁顺序统一为：事件（需要时）→ 按 ID 升序的任务 → 尝试/Outbox/历史/操作记录。操作幂等可先只读，写入仍服从锁顺序；Outbox 单独领取事务不再反向锁任务。
110→- 历史顺序由任务行上受保护的序号分配器维护：锁定任务后递增 `history_seq`，同事务写入；为此可增加专用序号字段。该序号变化不要求增加业务 `row_version`。
- `write_id` 唯一，来源于稳定业务动作标识；事务重试不能产生重复历史。

## 7. 时间、预算与默认运行参数

任务时间字段的状态约束由 S03 定义。每轮固定 `max_attempts`、退避策略及 `round_deadline_at`；人工重投只重置轮内次数，累计次数及未决证据不清零。截止时间不强制终止仍有有效领取者的在途请求。

| 参数 | 初始建议值 |
| --- | --- |
| 并行投递 / HTTP 超时 | 10 / 10 秒 |
120→| 任务领取期限 / MQ 不可见期限 | 30 秒 / 60 秒 |
| 每轮最多尝试 / 本轮等待期限 | 8 / 24 小时 |
| 退避起始 / 本地退避上限 | 5 秒 / 5 分钟，带抖动 |
| 供应商等待建议上限 | 1 小时 |
| Outbox 空闲轮询 / 恢复扫描 | 1 秒 / 30 秒 |
| 补发额外宽限 / 阻塞检查间隔 | 5 分钟 / 60 秒 |
| 概览缓存 / 结案记录保留 | 5 秒 / 30 天 |
| 单个请求、响应、错误摘要上限 | 默认分别 2 KiB，按 UTF-8 字节截断并标记 |

HTTP 截止时间必须早于领取到期，并为结果事务留出余量。MQ 不可见期限应覆盖单次本地处理预算；如需延长，采用有上限的续期。不能用延长不可见时间替代数据库领取或持久化等待计划。
130→
批次 0 在启动时检查的关系是：`DELIVERY_HTTP_TIMEOUT + MYSQL_OPERATION_TIMEOUT < DELIVERY_LEASE_TIMEOUT`，以及 `DELIVERY_MQ_INVISIBLE >= DELIVERY_LEASE_TIMEOUT + MYSQL_OPERATION_TIMEOUT`。结果事务余量先按 `MYSQL_OPERATION_TIMEOUT` 计。S03 的构造超时、结果预留、ACK 和凭证准备预算尚未进入启动配置，那些参数落地后再收紧，不在本批次静默套用完整公式。

事件大小、最大扇出、响应读取、查询范围、分页、积压保护等上限采用本契约及各模块参数表的默认值，必须在启动配置中显式定义并校验，不允许无限制运行。

## 8. 身份、权限和通用 HTTP 错误

认证层输出 `caller_id`、可访问来源、角色/权限及操作者标识。首版可由受保护的部署配置维护凭证映射，不额外建设账户平台；外部调用不能伪造内部认证上下文。

权限至少区分事件提交、自有数据读取、跨调用方运维读取、配置发布、通道管理、人工重投、未知结果核对及风险重投。跨调用方写入必须检查目标调用方范围，审计同时保存操作者和被操作范围。
140→
错误沿用 `{"error":{"code":"...","message":"..."}}`，`message` 脱敏且可定位，客户端以稳定 `code` 判断。领域错误和 HTTP 映射明确分层。

| HTTP | 语义 / 典型错误码 |
| --- | --- |
| 400 | 格式或参数错误：`invalid_request`、`invalid_cursor` |
| 401 / 403 | 未认证 / 无权限：`unauthenticated`、`forbidden` |
| 404 | 不存在或无读取范围：`not_found`，不泄露其他调用方资源 |
| 409 | 幂等参数冲突、版本或状态冲突：`idempotency_conflict`、`version_conflict`、`state_conflict` |
| 413 | 请求超过上限：`payload_too_large` |
150→| 422 | 业务数据或配置不满足契约：`unsupported_schema`、`no_matching_route`、`mapping_invalid`、`unsafe_replay` |
| 429 | 接入级配额限制：`rate_limited` |
| 503 | 依赖不可用或积压保护：`dependency_unavailable`、`admission_paused` |
| 500 | 未预期内部错误：`internal`；不返回 SQL、凭证或内部堆栈 |

JSON 必须是一个完整对象，拒绝重复键、尾随数据及无效 UTF-8。请求 envelope 中的未知字段拒绝；事件 `data` 的字段由其数据版本决定。

## 9. 公共参数和协议边界

以下是首版实现契约。表中环境变量已进入 `internal/conf` 的只读配置，并由 Wire 按字段注入，不在业务用例中读取环境变量。时长环境变量使用 Go duration 文本，HTTP/发布内容中的时长使用带单位后缀的整数；禁止把秒、毫秒混用。参数超出范围或第 7 节的时间关系不成立时启动失败，不能静默修正。错误包含参数名，不包含秘密值。
160→
| 字段 / 参数 | 类型及边界 | 默认 / 处理 |
| --- | --- | --- |
| 内部实体 ID | HTTP 为十进制字符串，范围 `1..18446744073709551615`；禁止符号、前导零、浮点形式 | 数据库分配；操作 ID 除外 |
| `caller_id / source_business / provider_id / provider_account_id / operation` | ASCII，1～64 字节，`[A-Za-z0-9][A-Za-z0-9._:-]*` | 必填，精确比较 |
| `event_type / route_target_id` | 同上，1～128 字节 | 必填 |
| `schema_version / adapter_version / mapping_version` | 同上，1～32 字节 | 必填 |
| `source_event_id / business_object_id / operation_idempotency_key` | UTF-8，1～191 字节，禁止控制字符和纯空白 | 必填，不裁剪；操作键不能包含秘密 |
| `business_object_type` | ASCII 标识，1～64 字节 | 必填 |
| 轮次、版本、次数、历史序号 | 无符号整数；首版持久化上限为 `4294967295` | 溢出返回可定位错误并告警，不回绕 |
170→| 时间 | RFC 3339，最多 6 位小数，年份 `1000..9999` | 保存为 UTC；不因事件较旧自动拒绝 |
| `HTTP_REQUEST_TIMEOUT` | 1～30 秒 | 5 秒；接入和管理请求总预算 |
| `MYSQL_OPERATION_TIMEOUT` | 100 毫秒～5 秒 | 2 秒；每个完整事务或查询的上限 |
| `HTTP_SHUTDOWN_TIMEOUT` | 5～120 秒 | 45 秒；先停止入口，再排空后台角色 |
| `AUTH_CONFIG_REF` | 受保护的身份映射引用 | 部署必填；本地测试可注入固定身份提供器 |
| `HTTP_MAX_HEADER_BYTES` | 1～64 KiB | 16 KiB；超限由 HTTP 层拒绝 |
| JSON 深度 / 单个数字字面量 | 最多 32 层 / 128 字节 | 深度包含 envelope；超限 400 |
| 规范化数字 | 系数最多 64 位，规范化指数 `-308..308` | 精确十进制处理；超限 400，不转浮点 |
| 单个摘要 | 默认 2048 字节，允许配置 256～8192 字节 | 请求、响应、错误分别截断并记录标记；环境变量名为 `SUMMARY_MAX_BYTES` |

180→认证统一使用 `Authorization: Bearer <opaque-token>`，通过身份提供器解析成 `AuthContext{actor_id, caller_id, allowed_sources, permissions, caller_scopes}`；凭证本身不进入领域对象、数据库操作参数或日志。权限码为 `events:write`、`data:read`、`ops:read`、`config:publish`、`channels:manage`、`deliveries:retry`、`deliveries:resolve`、`deliveries:risk-retry`、`dlq:repair`。`ops:read` 不隐含写权限，写操作必须同时检查目标范围。启动时没有可用身份配置则不对外就绪。

身份配置采用 `{format_version:1, identities:[{actor_id, caller_id, token_sha256, allowed_sources, caller_scopes, permissions, enabled}]}`，actor_id 遵循 64 字节 ASCII 标识规则，token_sha256 为 Bearer 原始字节的 SHA-256 小写十六进制值且配置中唯一。服务只保存 hash 并做恒定时间比较；真实 Token 由运维通过秘密通道分发。caller_scopes 为明确调用方 ID 集合，最多 100 项；不存在的权限码、空范围或重复身份启动失败。单次运行使用受保护配置版本；轮换/撤销通过更新版本并有界重载或滚动重启生效，不能声称缓存旧配置时已即时撤销。任务执行前的权限检查使用本实例当前生效版本，不信任最初事件保存的旧权限。

公共 HTTP 行为：

1. 写接口只接受 `application/json`（允许 `charset=utf-8`），其他类型返回 415 `unsupported_media_type`；首版不接收压缩请求体。JSON 超限按实际读取字节判断，不信任 `Content-Length`。
2. `X-Request-ID` 接受 1～64 字节 ASCII 标识，否则生成 32 位小写十六进制随机值；所有响应返回该 Header，错误体可增加同值 `request_id`。它只用于关联，不作为幂等依据。
3. `null` 不替代缺失的必填字段；重复参数、未知查询参数和 envelope 未知字段返回 400。`data` 及配置内字段由其版本化契约决定。
4. 成功响应与管理操作快照中的可选字段明确返回 null；列表为空返回 `items: []`、`next_cursor: null`。不把空时间转换成零时刻。
190→5. 请求取消前尚未提交则回滚；取消时提交状态不确定按稳定键核对。禁止以客户端断开为由撤销已持久化的受理或重投。
6. 领域错误至少携带稳定 `code`、安全 `message` 和可选 `field_path`；基础设施错误在 `data` 转换，`service` 映射 HTTP，`biz` 不返回驱动错误。422 校验错误可附 `details`，最多 100 项，不包含字段原始值。

## 10. 领域操作与持久化补充

跨模块数据使用领域结构；下表是 `data_interface` 所需的行为契约，不要求合并为一个接口。`ctx` 隐含在所有操作中，返回稳定领域错误，`biz` 不传递 `sql.Tx`。

| 领域结构 | 必需内容 | 使用方 |
| --- | --- | --- |
| `EventEnvelope` | 来源及事件标识、类型/版本、发生时间、对象关联、精确 JSON 数据 | S01、S02 |
200→| `DeliveryPlan` | 发布引用、按目标排序的固定目标、映射载荷、固定协议语义、轮次策略 | S01 输出、S02 保存 |
| `TaskSnapshot` | 完整关联、状态/确定性、版本、所有权、轮次策略、阻塞恢复依据 | S03、S06、S07 |
| `Ownership` | 任务、轮次、调度版本、尝试 ID、领取 token/期限 | S03 结果及调用前校验 |
| `AttemptResult` | 发送事实、标准结果、证据覆盖、时间/耗时、脱敏摘要和截断标记 | S05 输出、S03 保存 |
| `NextAction` | `SUCCEED / FAIL / UNKNOWN / RETRY / WAIT / BLOCK`、原因、时间、恢复类别 | `domain` 的统一决策输出 |
| `OperationResult` | 操作 ID/类型、目标范围、完成时任务或配置快照 | S01、S05、S07 幂等重放 |

除第 6 节事务外，读取端口至少提供 `FindAcceptedEvent`、`LoadTaskSnapshot`、`LoadRelease`、`FindOperation`，均显式包含授权范围；后台角色使用受信内部身份，不能伪造外部调用方上下文。结果提交不确定时，查询必须走主库的新事务，不能在旧一致性快照或滞后副本上判定“未提交”。唯一键冲突、死锁与连接中断分开分类；只有确认回滚的纯数据库事务可有界重试，最多 2 次，不能重做 HTTP/MQ 调用。

初始 SQL 是草案，完成对应模块前需要增量迁移：
210→
| 实体 | 补充字段 / 约束 | 原因 |
| --- | --- | --- |
| `business_events` | `fingerprint_version`、`data_canonical MEDIUMBLOB` | 保存规范化算法和精确 JSON 字节，避免 JSON 数字存储转换改变事实 |
| `delivery_tasks` | `adapter_type`、`mapping_id`、`fixed_target`、`round_policy`、`resume_status`、`resume_not_before`、`history_seq` | 原协议语义、策略及阻塞恢复必须可重建 |
| `delivery_tasks` | 行/调度版本默认 1；截止时间非空；持久化任务级未决证据关联 | 所有新任务符合 S03，不靠最近一次结果推断未决 |
| `delivery_tasks` | `payload_canonical MEDIUMBLOB`；风险授权操作/首次尝试关联 | 精确载荷与一次性授权 |
| `delivery_attempts` | 最终结果枚举至少 `VARCHAR(32)`；证据覆盖、请求/错误截断标记、诊断安全字段 | `RETRYABLE_REJECT` 等全部枚举及完整追踪可保存 |
| 尝试及任务摘要 | 请求/响应/错误列容量覆盖允许的最大字节上限，分别保存截断标记；blocked_since 单独持久化 | 不能配置为 8 KiB 却被较短 VARCHAR 拒绝；阻塞时长不被检查重置 |
| `outbox_messages` | S04 的发布状态、领取代次、补发次数/时间和发布索引 | 同一消息再发布与旧发布者隔离 |
220→| `channels` | `operation`、`row_version`、enabled 默认 false、S05 的限流和目标许可结构；唯一键改为 provider/account/operation/adapter_type | 区分同账号不同操作，支持管理 CAS |
| `management_events` | 指纹版本、完整期望版本、风险/核对证据及操作结果 | 操作幂等及证据与任务同事务 |

`data_canonical / payload_canonical` 是指纹、映射和请求构造的事实来源；已有 JSON 列可保留为查询投影。规范化字节必须是可解析 JSON，不允许从 MySQL JSON 的浮点投影重建精确原值。配置发布内容同样保存规范化字节及 SHA-256，读取校验后再解释。任务引用发布外键保留实际内容，禁止存储动态凭证。

历史 `phase` 至少固定为 `TASK_CREATED / SCHEDULE_CREATED / PUBLISH_SUCCEEDED / PUBLISH_FAILED / ATTEMPT_STARTED / ATTEMPT_FINISHED / RETRY_PLANNED / WAIT_PLANNED / BLOCKED / UNBLOCKED / LEASE_EXPIRED / DISPATCH_REPAIRED / DLQ_DISPOSED / MANUAL_RETRY / MANUAL_RESOLVE / LATE_RESPONSE`。`write_id` 使用稳定动作元组的 SHA-256 十六进制值；元组必须包含任务 ID、动作及该动作的尝试/操作/发布代次等唯一依据。追加两类历史时用不同动作值，不能共用一个键。

## 11. 依赖组装与事务调用序列

```mermaid
230→sequenceDiagram
    participant Main as cmd/Wire
    participant Conf as conf
    participant Data as data 实现
    participant Biz as biz 用例
    participant Entry as server/service
    Main->>Conf: 加载环境及 Key Vault，校验参数
    Conf-->>Main: 只读启动配置
    Main->>Data: 创建连接、适配器和仓储
    Data-->>Main: data_interface 实现及清理函数
240→    Main->>Biz: 注入小接口和所需参数
    Main->>Entry: 注入用例并启动各角色
    Entry->>Biz: 领域请求和认证上下文
    Biz->>Data: 一个完整原子操作
    Note over Data: 在 MySQL 内锁定、复核、写业务及历史、提交
    Data-->>Biz: 已确认结果或提交不确定
    Biz-->>Entry: 领域结果或稳定错误
    Note over Entry,Data: 供应商和 MQ 调用在数据库事务之外
```

250→运行图表示职责交互，不授权 `biz` 依赖具体 `data` 包；实际调用通过 `data_interface`。共享状态与映射规则是 `domain` 纯逻辑；跨能力编排由 Wire 注入所需能力，禁止绕过完整事务接口。

## 12. 数据及实现校准清单

- [x] 校准 `schedule_version / row_version` 初值及 `send_state` 草案枚举。00002 将版本默认改为 1；00003 把存量 `SENT` 校准为 `HTTP_INVOKED`。
- [x] 持久化指纹算法版本；不得因编码器升级静默改变重复提交判断。`fingerprint_version` 与 canonical 字节已在事件、发布内容和领域常量中保留。
- [x] 完整保存适配器类型、语义目标配置与轮次策略，或保留不可变引用。列由 00002 增加，发布内容的 canonical 字节由 00003 补上。
- [x] 保存风险重投的本轮首次发送授权及尝试关联；它不能替代后续自动重发的安全判断。列已在 00002，授权规则由 S03/S07 使用。
- [x] 校准通道的操作与唯一性，支持同账号多个通知操作，避免当前通道唯一键误合并。00002 已改唯一键。
- [x] 增加任务历史序号分配依据；补充发布领取、重试发布时间和组合查询所需索引。`history_seq` 与 Outbox 索引已在 00002，序号分配由通用事务助手提供。
260→- [ ] 需要刷新凭证轮换的供应商接入前，补齐受保护的持久凭证存储及并发控制。留给 S05，本批次不建凭证表。
- [x] 校验迁移字段长度能容纳全部枚举、字节截断标记与操作结果。00003 将相关枚举列扩到至少 `VARCHAR(32)`，摘要列改为 `TEXT`。

## 13. 共享验收

| 编号 | Given / When | Then |
| --- | --- | --- |
| C-01 | 两个来源业务属于同一调用方，提交相同来源事件 ID 但不同事实 | 返回幂等冲突，不新建第二条事件 |
| C-02 | 任务已被恢复并领取，旧 worker 返回结果 | 任务不被推进；允许追加标记清楚的迟到证据 |
| C-03 | 结果事务已提交但客户端未收到确认 | 按稳定键读取原结果，尝试和历史不重复，HTTP 不重发 |
270→| C-04 | 前轮次仍有未决请求，人工重投后明确拒绝且耗尽预算 | 未消除的不确定性仍保留，最终为 `UNKNOWN` |
| C-05 | 任务状态与历史写入之一失败 | 整个业务事务回滚，不留下状态与证据不一致的记录 |
| C-06 | 输入含重复 JSON 键、非法代理项、超深对象或越界数字 | 明确拒绝，不静默替换或转 float64；不生成成功业务记录 |
| C-07 | 数据库返回大整数 JSON 投影与精确字节表示不同 | 指纹、映射和请求继续使用 canonical 字节，历史重试载荷不变化 |
| C-08 | 超时、领取及不可见时间的组合不符合关系约束 | 启动失败并返回参数名；错误不包含任何秘密值 |


### Turn 10 (Function)
[tool_response]
- /Users/kiteeater/jobwork/ai-coding-test/
  - bin/
    - mockvendor
    - notifier
  - cmd/
    - mockvendor/
      - Dockerfile
      - main.go
    - notifier/
      - main.go
      - wire.go
      - wire_gen.go
  - compose.yaml
  - config/
    - identities.example.json
  - deploy/
    - rocketmq/
      - broker.conf
  - Dockerfile
  - docs/
    - 00-shared-contracts.md
    - 01-configuration-release.spec.md
    - 02-event-ingestion.spec.md
    - 03-delivery-processing.spec.md
    - 04-reliable-dispatch.spec.md
    - 05-provider-runtime.spec.md
    - 06-delivery-recovery.spec.md
    - 07-delivery-operations.spec.md
    - 08-delivery-tracking.spec.md
    - README.md
  - go.mod
  - go.sum
  - internal/
    - auth/
      - auth.go
    - canonicaljson/
      - canonicaljson.go
    - conf/
      - config.go
      - keyvault.go
      - validate.go
    - config/
    - constant/
      - constant.go
    - data/
      - mysql/
        - history.go
        - mysql.go
      - redis/
        - redis.go
      - rocketmq/
        - client.go
    - domain/
      - error.go
      - ident.go
      - summary.go
      - time.go
      - types.go
      - writeid.go
    - enums/
      - enums.go
    - httpapi/
    - logredact/
      - logredact.go
    - mockvendor/
      - server.go
    - server/
      - app.go
      - group.go
      - http.go
      - middleware.go
    - service/
      - health.go
      - httpx.go
      - requestid.go
      - respond.go
  - Makefile
  - migrations/
    - 00001_init.sql
    - 00002_spec_calibration.sql
    - 00003_s00_contracts.sql
  - PRD.md
  - README.md
  - scripts/
    - init-topics.sh
  - TECH_DESIGN.md
  - tests/
    - integration/
      - c05_c07_test.go
      - harness_test.go
      - migrate_test.go
      - README.md
      - restart_test.go
      - rocketmq_test.go
      - startup_test.go
  - tools/
    - tools.go
  - unit_test/
    - auth/
      - auth_test.go
    - canonicaljson/
      - canonicaljson_test.go
    - conf/
      - bounds_test.go
      - config_test.go
    - domain/
      - rules_test.go
    - logredact/
      - logredact_test.go
    - mockvendor/
      - server_test.go
    - README.md
    - server/
      - http_test.go
      - lifecycle_test.go
    - service/
      - httpx_test.go

### Turn 11 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 25 matching lines
/Users/kiteeater/jobwork/ai-coding-test/docs/05-provider-runtime.spec.md
21:适配器以 `(adapter_type, adapter_version)` 注册，同一版本必须保持声明的协议语义。启动时拒绝重复注册；原任务引用的版本缺失时报告阻塞，不能选择最新版本代替。
29:| `ValidateTarget` | 固定目标配置、操作及凭证引用元数据 | 发布期静态校验；不发网络请求 |
30:| `ValidatePayload` | 已映射业务载荷及固定语义 | 确定性本地校验；不生成动态业务字段 |
75:## 5. 当前通道约束与限流
79:每次执行核对通道启停、账号归属、调用方权限、目标许可和适配器可用性。当前限制以 MySQL/受保护配置为准，不因运行参数缓存过期而越权发送。
81:首版通道接口为 `GET /v1/channels`、`GET /v1/channels/{id}`、`POST /v1/channels` 和 `PATCH /v1/channels/{id}`。管理修改携带操作幂等键、原因与期望通道版本，原子保存变更及管理审计；现有迁移需补充版本依据。
83:禁用与运行限制可更新；既有账号归属和操作语义不能通过修改可变通道重新解释旧任务。新增不同账号/操作时创建适当的新实体并发布新配置。同账号不同操作不能被唯一约束误合并。
87:以通道或供应商实际共享额度范围定义限流 key，使用 Redis 原子令牌桶或等价算法；同账号多个通道共享供应商额度时不能各自获得完整额度。
120:## 8. 通道与协议参数
125:| `provider_id / provider_account_id / operation` | S00 标识，必填 | 账号和业务操作归属不可编辑；新归属新建通道 |
126:| `adapter_type / adapter_version` | S00 标识，必填 | 创建时必须注册；变更协议需新通道及新发布，不重解释旧任务 |
127:| `credential_ref` | 1～191 字节 UTF-8，必填 | 逻辑引用，不含秘密；绑定相同 provider/account，不允许 PATCH 换至其他逻辑引用 |
133:| `runtime_policy.rate_per_second / burst` | 正整数，必填 | 1～10000 / 1～10000；无额度配置的通道不能启用 |
134:| `runtime_policy.rate_policy_version` | 正整数，服务端分配 | 同 quota_key 的通道必须使用相同额度参数和策略版本 |
136:| `semantic_config.auth_type` | `bearer / hmac_sha256 / none` | 由适配器版本声明支持；none 仅测试通道许可 |
141:## 9. 通道管理接口和凭证契约
145:| `POST /v1/channels` | 操作键、原因、第 8 节创建字段 | 201 `{operation_id, channel}`；同 provider/account/operation/adapter_type 重复为 409 `channel_conflict` |
147:| `GET /v1/channels/{id}` | 路径 ID | 200 脱敏通道、row_version、凭证状态及更新时间，无 Token |
150:通道管理操作使用全局 caller_scope `__global__`，类型 `channel_create / channel_update`，要求 `channels:manage` 及受影响调用方范围；幂等先于新操作 CAS。禁用时不逐个改写所有任务，由 S03 当前检查和 S06 阻塞恢复处理。共享 quota_key 的额度变更必须在一个管理事务中更新全部关联通道并递增各自版本；受影响通道超过 100 个则拒绝变更并要求拆分额度组，不能让同一 key 并存两个策略。
156:需要 Refresh Token 的接入在受保护存储中维护 `{credential_ref, account, version, state, refresh_owner, refresh_deadline}`。先以持久 CAS 进入 REFRESHING，调用供应商后持久化新版本和 Token，再置 ACTIVE 并写缓存。刷新窗口中进程崩溃或响应丢失时，依协议判断能否重取；无法证明旧 Refresh Token 仍有效时置 REAUTH_REQUIRED，禁止第二个实例盲目刷新。短期 Redis 锁只减少等待，不承担上述状态机正确性。
205:    P->>DB: 当前通道、账号归属及访问约束
236:- [ ] 实现通道当前约束、管理版本及审计、Redis 原子限流和用途分别降级。
249:| PRV-06 | 通道禁用、权限撤销、旧适配器缺失或原目标不再允许 | 返回明确阻塞，不换版本、账号或地址发送 |
254:| PRV-11 | 同账号不同操作共享同 quota_key 并发执行 | 总通过量服从一个令牌桶；不同通道不能各取完整额度，策略版本变化不额外补满桶 |
256:| PRV-13 | 原通道引用未变但凭证轮换或撤销 | 新版本凭证保持原账号；旧缓存不可继续用，撤销转可见阻塞 |
</workspace_result>

### Turn 12 (Assistant)
[tool_request: grep]
- pattern: routing_release|routing_current|management_event|credential
- glob: migrations/*.sql
[tool_request: list_dir]
- target_directory: /Users/kiteeater/jobwork/ai-coding-test/internal
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/types.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/error.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/cmd/notifier/wire.go

### Turn 13 (Function)
[tool_response]
- /Users/kiteeater/jobwork/ai-coding-test/internal/
  - auth/
    - auth.go
  - canonicaljson/
    - canonicaljson.go
  - conf/
    - config.go
    - keyvault.go
    - validate.go
  - config/
  - constant/
    - constant.go
  - data/
    - mysql/
      - history.go
      - mysql.go
    - redis/
      - redis.go
    - rocketmq/
      - client.go
  - domain/
    - error.go
    - ident.go
    - summary.go
    - time.go
    - types.go
    - writeid.go
  - enums/
    - enums.go
  - httpapi/
  - logredact/
    - logredact.go
  - mockvendor/
    - server.go
  - server/
    - app.go
    - group.go
    - http.go
    - middleware.go
  - service/
    - health.go
    - httpx.go
    - requestid.go
    - respond.go

### Turn 14 (Function)
[tool_response]
1→//go:build wireinject

package main

import (
	"context"

	"github.com/google/wire"

10→	"notifier/internal/conf"
	"notifier/internal/data/mysql"
	"notifier/internal/data/redis"
	"notifier/internal/data/rocketmq"
	"notifier/internal/server"
	"notifier/internal/service"
)

// initializeApp 组装启动配置、身份、基础设施和 HTTP 入口。
// 身份文件先于数据库拨号；连接失败时清理函数由 Wire 逆序调用。
20→func initializeApp(ctx context.Context) (*application, func(), error) {
	wire.Build(
		conf.Load,
		wire.FieldsOf(new(conf.GlobalConfig), "HTTP", "MySQL", "Redis", "RocketMQ", "Log", "Auth"),
		loadIdentities,
		mysql.Open,
		redis.Open,
		rocketmq.Open,
		newReadiness,
		service.NewHealthService,
30→		server.NewHTTPServer,
		emptyRoles,
		newApplication,
	)
	return nil, nil, nil
}


### Turn 15 (Function)
[tool_response]
1→package domain

import (
	"time"

	"notifier/internal/enums"
)

// EventEnvelope 是受理前的事件事实。DataCanonical 是精确 JSON 字节，由 S02 组成指纹。
10→type EventEnvelope struct {
	CallerID           string
	SourceBusiness     string
	SourceEventID      string
	EventType          string
	SchemaVersion      string
	OccurredAt         time.Time
	BusinessObjectType string
	BusinessObjectID   string
	DataCanonical      []byte
20→	FingerprintVersion int
}

// TargetPlan 是一个路由目标的固定语义。FixedTarget 与 PayloadCanonical 的内部结构由 S01 定义。
type TargetPlan struct {
	RouteTargetID     string
	ProviderID        string
	ProviderAccountID string
	Operation         string
	MappingID         string
30→	MappingVersion    string
	AdapterType       string
	AdapterVersion    string
	PayloadCanonical  []byte
	FixedTarget       []byte
}

// DeliveryPlan 是一次发布计算出的固定计划。轮次策略 JSON 的结构由 S01 定义。
type DeliveryPlan struct {
	ReleaseRef  string
40→	Targets     []TargetPlan
	RoundPolicy []byte
}

// Ownership 是一次领取的所有权。校验规则由 S03 完成。
type Ownership struct {
	DeliveryID      uint64
	RoundNo         uint32
	ScheduleVersion uint32
	AttemptID       uint64
50→	LeaseToken      string
	LeaseExpiresAt  time.Time
}

// TaskSnapshot 是任务恢复与执行所需的持久化视图。状态推进由 S03 完成。
type TaskSnapshot struct {
	DeliveryID         uint64
	EventID            uint64
	RouteTargetID      string
	CallerID           string
60→	Status             enums.TaskStatus
	ResultCertainty    enums.ResultCertainty
	RoundNo            uint32
	ScheduleVersion    uint32
	RowVersion         uint32
	HistorySeq         uint32
	Ownership          *Ownership
	RoundPolicy        []byte
	PayloadCanonical   []byte
	ResumeStatus       string
70→	ResumeNotBefore    *time.Time
	BlockedSince       *time.Time
	UnresolvedEvidence []byte
}

// AttemptResult 是一次发送事实。是否推进任务由 S03 判定。
type AttemptResult struct {
	SendState         enums.SendState
	Outcome           enums.Outcome
	ResultCertainty   enums.ResultCertainty
80→	EvidenceScope     []byte
	StartedAt         time.Time
	Duration          time.Duration
	RequestSummary    string
	ResponseSummary   string
	ErrorSummary      string
	RequestTruncated  bool
	ResponseTruncated bool
	ErrorTruncated    bool
	TimingIncomplete  bool
90→}

// Decision 是统一决策的输出。Kind 取 SUCCEED/FAIL/UNKNOWN/RETRY/WAIT/BLOCK。决策过程由 S03 完成。
type Decision struct {
	Kind           enums.NextAction
	Reason         string
	At             time.Time
	ResumeCategory string
}

100→// OperationResult 是管理或发布操作的幂等结果。快照内容由对应模块填充。
type OperationResult struct {
	OperationID   string
	OperationType string
	CallerScope   string
	Task          *TaskSnapshot
	ReleaseRef    string
}


### Turn 16 (Function)
[tool_response]
1→package domain

import (
	"fmt"

	"notifier/internal/constant"
)

// Detail 是 422 校验明细。不得放入字段原始值。
10→type Detail struct {
	FieldPath string
	Code      string
	Message   string
}

// Error 是跨模块的稳定领域错误。biz 只返回这类错误，不返回驱动错误。
type Error struct {
	Code      string
	Message   string
20→	FieldPath string
	Details   []Detail
}

func (e *Error) Error() string {
	if e.FieldPath != "" {
		return fmt.Sprintf("domain: %s: %s (%s)", e.Code, e.Message, e.FieldPath)
	}
	return fmt.Sprintf("domain: %s: %s", e.Code, e.Message)
}
30→
// NewError 构造领域错误。明细超过 100 项时拒绝，避免静默丢掉校验结果。
func NewError(code, message, fieldPath string, details []Detail) (*Error, error) {
	if len(details) > constant.MaxErrorDetails {
		return nil, fmt.Errorf("domain: details exceed %d", constant.MaxErrorDetails)
	}
	copied := append([]Detail(nil), details...)
	return &Error{Code: code, Message: message, FieldPath: fieldPath, Details: copied}, nil
}


### Turn 17 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 16 matching lines
/Users/kiteeater/jobwork/ai-coding-test/migrations/00001_init.sql
8:CREATE TABLE routing_releases (
21:CREATE TABLE routing_current (
34:    credential_ref      VARCHAR(191)    NOT NULL,          -- 凭证引用，指向凭证存储
59:    routing_release_id    BIGINT UNSIGNED NOT NULL,
64:    CONSTRAINT fk_event_release FOREIGN KEY (routing_release_id) REFERENCES routing_releases (release_id)
210:CREATE TABLE management_events (
229:DROP TABLE IF EXISTS management_events;
236:DROP TABLE IF EXISTS routing_current;
237:DROP TABLE IF EXISTS routing_releases;

/Users/kiteeater/jobwork/ai-coding-test/migrations/00003_s00_contracts.sql
10:ALTER TABLE routing_releases
72:ALTER TABLE management_events
79:ALTER TABLE management_events
129:ALTER TABLE routing_releases

/Users/kiteeater/jobwork/ai-coding-test/migrations/00002_spec_calibration.sql
110:-- management_events：指纹版本与风险/核对证据（S00 第 10 节、S07 第 7 节）
112:ALTER TABLE management_events
119:ALTER TABLE management_events
</workspace_result>

### Turn 18 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/migrations/00001_init.sql
- limit: 80
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/migrations/00003_s00_contracts.sql
- limit: 160
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/migrations/00002_spec_calibration.sql
- offset: 90
- limit: 50
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/constant/constant.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/enums/enums.go
- limit: 200

### Turn 19 (Function)
[tool_response]
1→-- +goose Up
-- S00 第 10 节和第 12 节里 00002 尚未覆盖的列、枚举宽度和摘要容量。
-- 不改写 00001/00002。凭证轮换表留给需要 refresh token 的供应商（S05）。
-- 枚举列至少 VARCHAR(32)。摘要改为 TEXT，才能放下 8192 字节上限；截断标记仍是独立布尔列。

UPDATE delivery_attempts
    SET send_state = 'HTTP_INVOKED'
    WHERE send_state = 'SENT';

10→ALTER TABLE routing_releases
    MODIFY COLUMN status VARCHAR(32) NOT NULL DEFAULT 'draft'
        COMMENT 'draft | published | superseded',
    ADD COLUMN content_canonical MEDIUMBLOB NULL
        COMMENT '发布内容的规范化 JSON 字节；S01 写入，空库迁移时允许为空' AFTER content,
    ADD COLUMN content_sha256 CHAR(64) NULL
        COMMENT 'content_canonical 的 SHA-256' AFTER content_canonical,
    ADD COLUMN fingerprint_version INT UNSIGNED NULL
        COMMENT '发布内容指纹算法版本' AFTER content_sha256;

20→ALTER TABLE delivery_tasks
    MODIFY COLUMN status VARCHAR(32) NOT NULL DEFAULT 'PENDING'
        COMMENT 'PENDING | PROCESSING | RETRY_WAIT | BLOCKED | SUCCEEDED | FAILED | UNKNOWN',
    MODIFY COLUMN result_certainty VARCHAR(32) NOT NULL DEFAULT 'NOT_RECEIVED'
        COMMENT 'RECEIVED | NOT_RECEIVED | UNCERTAIN',
    MODIFY COLUMN last_result_certainty VARCHAR(32) NULL
        COMMENT '最近一次尝试的确定性',
    MODIFY COLUMN resume_status VARCHAR(32) NULL
        COMMENT '阻塞恢复类别 PENDING | RETRY_WAIT',
    MODIFY COLUMN last_error_reason TEXT NULL
30→        COMMENT '脱敏错误摘要，容量覆盖 8192 字节上限',
    ADD COLUMN last_error_truncated BOOLEAN NOT NULL DEFAULT FALSE
        COMMENT '任务级错误摘要截断标记' AFTER last_error_reason,
    ADD COLUMN unresolved_evidence JSON NULL
        COMMENT '任务级未决证据关联；不能只靠最近一次结果推断' AFTER last_result_certainty;

ALTER TABLE delivery_attempts
    MODIFY COLUMN status VARCHAR(32) NOT NULL DEFAULT 'PROCESSING'
        COMMENT 'PROCESSING | FINISHED',
    MODIFY COLUMN send_state VARCHAR(32) NULL
40→        COMMENT 'NOT_SENT | HTTP_INVOKED | UNCERTAIN',
    MODIFY COLUMN result_certainty VARCHAR(32) NULL
        COMMENT 'RECEIVED | NOT_RECEIVED | UNCERTAIN',
    MODIFY COLUMN request_summary TEXT NULL
        COMMENT '脱敏请求摘要，容量覆盖 8192 字节上限',
    MODIFY COLUMN response_summary TEXT NULL
        COMMENT '脱敏响应摘要，容量覆盖 8192 字节上限',
    MODIFY COLUMN error_reason TEXT NULL
        COMMENT '脱敏错误摘要，容量覆盖 8192 字节上限',
    ADD COLUMN diagnostic_code VARCHAR(64) NULL
50→        COMMENT '可对外的诊断码，不含原始响应或凭证' AFTER error_code;

ALTER TABLE delivery_history
    MODIFY COLUMN from_status VARCHAR(32) NULL,
    MODIFY COLUMN to_status VARCHAR(32) NULL,
    MODIFY COLUMN reason TEXT NULL
        COMMENT '脱敏原因，容量覆盖摘要上限';

ALTER TABLE outbox_messages
    MODIFY COLUMN message_type VARCHAR(32) NOT NULL
60→        COMMENT 'immediate | delayed',
    MODIFY COLUMN publish_status VARCHAR(32) NOT NULL DEFAULT 'PENDING'
        COMMENT 'PENDING | PUBLISHING | PUBLISHED | FAILED | CANCELLED',
    MODIFY COLUMN last_error TEXT NULL
        COMMENT '脱敏发布错误摘要';

ALTER TABLE channels
    MODIFY COLUMN access_constraints JSON NULL
        COMMENT 'S05 目标许可与网络访问约束；本迁移只保留列并标明归属',
    MODIFY COLUMN runtime_policy JSON NULL
70→        COMMENT 'S05 限流与运行策略；本迁移只保留列并标明归属';

ALTER TABLE management_events
    ADD COLUMN expected_row_version INT UNSIGNED NULL
        COMMENT '操作时期望的任务行版本；保留 expected_version 兼容旧草案' AFTER expected_version,
    ADD COLUMN expected_schedule_version INT UNSIGNED NULL
        COMMENT '操作时期望的调度版本' AFTER expected_row_version;

-- +goose Down
ALTER TABLE management_events
80→    DROP COLUMN expected_schedule_version,
    DROP COLUMN expected_row_version;

ALTER TABLE channels
    MODIFY COLUMN access_constraints JSON NULL,
    MODIFY COLUMN runtime_policy JSON NULL;

ALTER TABLE outbox_messages
    MODIFY COLUMN last_error VARCHAR(512) NULL,
    MODIFY COLUMN publish_status VARCHAR(16) NOT NULL DEFAULT 'PENDING'
90→        COMMENT 'PENDING | PUBLISHING | PUBLISHED | FAILED | CANCELLED',
    MODIFY COLUMN message_type VARCHAR(16) NOT NULL
        COMMENT 'immediate | delayed';

ALTER TABLE delivery_history
    MODIFY COLUMN reason VARCHAR(1024) NULL,
    MODIFY COLUMN to_status VARCHAR(16) NULL,
    MODIFY COLUMN from_status VARCHAR(16) NULL;

ALTER TABLE delivery_attempts
100→    DROP COLUMN diagnostic_code,
    MODIFY COLUMN error_reason VARCHAR(2048) NULL
        COMMENT '脱敏错误摘要；容量覆盖允许的最大字节上限',
    MODIFY COLUMN response_summary VARCHAR(2048) NULL,
    MODIFY COLUMN request_summary VARCHAR(2048) NULL,
    MODIFY COLUMN result_certainty VARCHAR(16) NULL,
    MODIFY COLUMN send_state VARCHAR(32) NULL;

UPDATE delivery_attempts
    SET send_state = 'SENT'
110→    WHERE send_state = 'HTTP_INVOKED';

ALTER TABLE delivery_attempts
    MODIFY COLUMN send_state VARCHAR(16) NULL
        COMMENT 'NOT_SENT | SENT | UNCERTAIN',
    MODIFY COLUMN status VARCHAR(16) NOT NULL DEFAULT 'PROCESSING'
        COMMENT 'PROCESSING | FINISHED';

ALTER TABLE delivery_tasks
    DROP COLUMN unresolved_evidence,
120→    DROP COLUMN last_error_truncated,
    MODIFY COLUMN last_error_reason VARCHAR(1024) NULL,
    MODIFY COLUMN resume_status VARCHAR(16) NULL
        COMMENT '阻塞恢复类别 PENDING | RETRY_WAIT（S03 DLV-S02）',
    MODIFY COLUMN last_result_certainty VARCHAR(16) NULL,
    MODIFY COLUMN result_certainty VARCHAR(16) NOT NULL DEFAULT 'NOT_RECEIVED'
        COMMENT '任务级确定性 RECEIVED | NOT_RECEIVED | UNCERTAIN；初始无尝试为 NOT_RECEIVED',
    MODIFY COLUMN status VARCHAR(16) NOT NULL DEFAULT 'PENDING';

ALTER TABLE routing_releases
130→    DROP COLUMN fingerprint_version,
    DROP COLUMN content_sha256,
    DROP COLUMN content_canonical,
    MODIFY COLUMN status VARCHAR(16) NOT NULL DEFAULT 'draft'
        COMMENT 'draft | published | superseded';


### Turn 20 (Function)
[tool_response]
90→        COMMENT '允许再次补发的最早时间' AFTER last_repair_at,
    MODIFY COLUMN publish_status VARCHAR(16) NOT NULL DEFAULT 'PENDING'
        COMMENT 'PENDING | PUBLISHING | PUBLISHED | FAILED | CANCELLED',
    ADD KEY idx_outbox_publish_next (publish_status, next_publish_at, outbox_id),
    ADD KEY idx_outbox_publish_lease (publish_status, lease_expires_at, outbox_id);

-- =====================================================================
-- channels：操作、行版本、启停默认与唯一键（S05 第 8 节）
-- =====================================================================
ALTER TABLE channels
100→    ADD COLUMN operation VARCHAR(64) NOT NULL
        COMMENT '供应商业务操作；同账号不同操作必须独立通道，不能被唯一约束合并' AFTER provider_account_id,
    ADD COLUMN row_version INT UNSIGNED NOT NULL DEFAULT 1
        COMMENT '通道行版本，初始 1；每次实际变更加 1，供 CAS 更新' AFTER updated_at,
    MODIFY COLUMN enabled BOOLEAN NOT NULL DEFAULT FALSE
        COMMENT '完成目标许可/凭证/额度配置后显式启用；创建默认 false',
    DROP INDEX uq_channel_account,
    ADD UNIQUE KEY uq_channel_account (provider_id, provider_account_id, operation, adapter_type);

-- =====================================================================
110→-- management_events：指纹版本与风险/核对证据（S00 第 10 节、S07 第 7 节）
-- =====================================================================
ALTER TABLE management_events
    ADD COLUMN fingerprint_version INT UNSIGNED NULL
        COMMENT '请求指纹算法版本（S02 同类确定性规范化）' AFTER request_fingerprint,
    ADD COLUMN evidence JSON NULL
        COMMENT '风险确认与核对证据摘要；脱敏，不含原始响应/Token/个人信息' AFTER reason;

-- +goose Down
ALTER TABLE management_events
120→    DROP COLUMN evidence,
    DROP COLUMN fingerprint_version;

ALTER TABLE channels
    DROP INDEX uq_channel_account,
    MODIFY COLUMN enabled BOOLEAN NOT NULL DEFAULT TRUE,
    DROP COLUMN row_version,
    DROP COLUMN operation,
    ADD UNIQUE KEY uq_channel_account (provider_id, provider_account_id, adapter_type);

130→ALTER TABLE outbox_messages
    DROP INDEX idx_outbox_publish_lease,
    DROP INDEX idx_outbox_publish_next,
    MODIFY COLUMN publish_status VARCHAR(16) NOT NULL DEFAULT 'PENDING'
        COMMENT 'PENDING | PUBLISHED | FAILED',
    DROP COLUMN next_repair_at,
    DROP COLUMN last_repair_at,
    DROP COLUMN repair_count,
    DROP COLUMN last_publish_started_at,
    DROP COLUMN publish_revision,

### Turn 21 (Function)
[tool_response]
1→-- +goose Up
-- 初始数据模型：事件、投递任务、Outbox、尝试、时间线、配置发布、通道与管理操作。
-- 依据 TECH_DESIGN.md 第 11 节；状态与错误码取值、详细字段以评审后的契约为准。
-- 约定：内部主键为 BIGINT UNSIGNED 自增；业务/外部标识为字符串；
--       所有持久化时间使用 UTC DATETIME(6)；JSON 用于快照与摘要。

-- 路由发布快照（不可变；另维护当前发布指针）
CREATE TABLE routing_releases (
    release_id   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
10→    version_no   INT UNSIGNED    NOT NULL,                 -- 业务版本号
    content      JSON            NOT NULL,                 -- 路由规则、映射及语义相关配置
    status       VARCHAR(16)     NOT NULL DEFAULT 'draft', -- draft | published | superseded
    published_at DATETIME(6)     NULL,
    created_at   DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (release_id),
    UNIQUE KEY uq_release_version (version_no),
    KEY idx_release_status (status, published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin;

20→-- 当前发布指针（单行）
CREATE TABLE routing_current (
    singleton  TINYINT         NOT NULL DEFAULT 1,
    release_id BIGINT UNSIGNED NOT NULL,
    updated_at DATETIME(6)     NOT NULL,
    PRIMARY KEY (singleton),
    KEY idx_current_release (release_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin;

-- 通道：供应商账号与凭证引用、当前启停与访问约束、运行策略
30→CREATE TABLE channels (
    channel_id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    provider_id         VARCHAR(64)     NOT NULL,
    provider_account_id VARCHAR(64)     NOT NULL,
    credential_ref      VARCHAR(191)    NOT NULL,          -- 凭证引用，指向凭证存储
    adapter_type        VARCHAR(64)     NOT NULL,
    adapter_version     VARCHAR(32)     NOT NULL,
    enabled             BOOLEAN         NOT NULL DEFAULT TRUE,
    access_constraints  JSON            NULL,
    runtime_policy      JSON            NULL,
40→    created_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (channel_id),
    UNIQUE KEY uq_channel_account (provider_id, provider_account_id, adapter_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin;

-- 业务事件
CREATE TABLE business_events (
    event_id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    caller_id             VARCHAR(64)     NOT NULL,
50→    source_business       VARCHAR(64)     NOT NULL,
    source_event_id       VARCHAR(191)    NOT NULL,        -- 调用方范围内唯一，区分大小写
    event_type            VARCHAR(128)    NOT NULL,
    schema_version        VARCHAR(32)     NOT NULL,
    occurred_at           DATETIME(6)     NOT NULL,        -- 事件发生时间（业务事实）
    business_object_type  VARCHAR(64)     NOT NULL,
    business_object_id    VARCHAR(191)    NOT NULL,
    data_snapshot         JSON            NOT NULL,        -- 发生时的数据快照
    fingerprint           CHAR(64)        NOT NULL,        -- 事件指纹（不含动态凭证/发送时间）
    routing_release_id    BIGINT UNSIGNED NOT NULL,
60→    accepted_at           DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (event_id),
    UNIQUE KEY uq_event_source (caller_id, source_event_id),
    KEY idx_event_object (caller_id, source_business, business_object_type, business_object_id, accepted_at, event_id),
    CONSTRAINT fk_event_release FOREIGN KEY (routing_release_id) REFERENCES routing_releases (release_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin;

-- 投递任务（每个事件 × 每个路由目标一项，最小追踪与恢复单位）
CREATE TABLE delivery_tasks (
    delivery_id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
70→    event_id             BIGINT UNSIGNED NOT NULL,
    route_target_id      VARCHAR(128)    NOT NULL,         -- 路由目标标识
    channel_id           BIGINT UNSIGNED NOT NULL,
    provider_id          VARCHAR(64)     NOT NULL,
    provider_account_id  VARCHAR(64)     NOT NULL,
    operation            VARCHAR(64)     NOT NULL,
    payload              JSON            NOT NULL,         -- 固定映射载荷
    mapping_version      VARCHAR(32)     NOT NULL,
    adapter_version      VARCHAR(32)     NOT NULL,
    idempotency_key      VARCHAR(191)    NOT NULL,         -- 供应商业务幂等标识（稳定）
80→    status               VARCHAR(16)     NOT NULL DEFAULT 'PENDING',

### Turn 22 (Function)
[tool_response]
1→// Package constant 存放跨模块共享、且没有行为的常量。
package constant

// 权限码。ops:read 不隐含写权限；写操作还要检查 caller_scopes。
const (
	PermEventsWrite         = "events:write"
	PermDataRead            = "data:read"
	PermOpsRead             = "ops:read"
	PermConfigPublish       = "config:publish"
10→	PermChannelsManage      = "channels:manage"
	PermDeliveriesRetry     = "deliveries:retry"
	PermDeliveriesResolve   = "deliveries:resolve"
	PermDeliveriesRiskRetry = "deliveries:risk-retry"
	PermDLQRepair           = "dlq:repair"
)

// Permissions 是首版全部权限码，顺序稳定，供配置校验使用。
var Permissions = []string{
	PermEventsWrite,
20→	PermDataRead,
	PermOpsRead,
	PermConfigPublish,
	PermChannelsManage,
	PermDeliveriesRetry,
	PermDeliveriesResolve,
	PermDeliveriesRiskRetry,
	PermDLQRepair,
}

30→// KnownPermission 判断权限码是否属于首版集合。
func KnownPermission(code string) bool {
	for _, item := range Permissions {
		if item == code {
			return true
		}
	}
	return false
}

40→const (
	// FingerprintVersion 是首版规范化算法版本。升级算法时递增，不能静默替换已保存的版本。
	FingerprintVersion = 1

	// JSON 结构上限。深度包含 envelope；数字按原始字面量字节计。
	MaxJSONDepth           = 32
	MaxJSONNumberLiteral   = 128
	MaxJSONCoefficientBits = 64 // 十进制系数位数，不是二进制位宽
	MaxJSONExponent        = 308

50→	// MaxErrorDetails 是 422 明细条数上限。明细不含字段原始值。
	MaxErrorDetails = 100

	// MaxCallerScopes 是单个身份可声明的调用方范围上限。
	MaxCallerScopes = 100

	// Summary 字节上限的配置边界。截断按 UTF-8 字节进行，并另存截断标记。
	SummaryBytesMin = 256
	SummaryBytesMax = 8192
)


### Turn 23 (Function)
[tool_response]
1→// Package enums 存放跨模块共享的业务枚举。状态推进规则由 S03 完成。
package enums

// Outcome 是单次尝试的协议结论。
type Outcome string

const (
	OutcomeReceived        Outcome = "RECEIVED"
	OutcomeRetryableReject Outcome = "RETRYABLE_REJECT"
10→	OutcomePermanentReject Outcome = "PERMANENT_REJECT"
	OutcomeLocalFailure    Outcome = "LOCAL_FAILURE"
	OutcomeUncertain       Outcome = "UNCERTAIN"
)

// ResultCertainty 是任务级或尝试级的接收确定性。
// 初始任务没有尝试时为 NOT_RECEIVED，只表示当前没有已知接收或未决发送。
type ResultCertainty string

const (
20→	CertaintyReceived    ResultCertainty = "RECEIVED"
	CertaintyNotReceived ResultCertainty = "NOT_RECEIVED"
	CertaintyUncertain   ResultCertainty = "UNCERTAIN"
)

// SendState 区分明确未发送、已进入 HTTP 调用和无法判断。
// 进入 HTTP 调用不证明供应商已经收到。迁移草案中的 SENT 已校准为 HTTP_INVOKED。
type SendState string

const (
30→	SendNotSent     SendState = "NOT_SENT"
	SendHTTPInvoked SendState = "HTTP_INVOKED"
	SendUncertain   SendState = "UNCERTAIN"
)

// TaskStatus 是投递任务状态。允许的迁移由 S03 定义。
type TaskStatus string

const (
	TaskPending    TaskStatus = "PENDING"
40→	TaskProcessing TaskStatus = "PROCESSING"
	TaskRetryWait  TaskStatus = "RETRY_WAIT"
	TaskBlocked    TaskStatus = "BLOCKED"
	TaskSucceeded  TaskStatus = "SUCCEEDED"
	TaskFailed     TaskStatus = "FAILED"
	TaskUnknown    TaskStatus = "UNKNOWN"
)

// NextAction 是领域统一决策的动作名。决策过程由 S03 完成。
type NextAction string
50→
const (
	ActionSucceed NextAction = "SUCCEED"
	ActionFail    NextAction = "FAIL"
	ActionUnknown NextAction = "UNKNOWN"
	ActionRetry   NextAction = "RETRY"
	ActionWait    NextAction = "WAIT"
	ActionBlock   NextAction = "BLOCK"
)

60→// HistoryPhase 是时间线阶段全集。追加两类历史时必须使用不同动作值。
type HistoryPhase string

const (
	PhaseTaskCreated      HistoryPhase = "TASK_CREATED"
	PhaseScheduleCreated  HistoryPhase = "SCHEDULE_CREATED"
	PhasePublishSucceeded HistoryPhase = "PUBLISH_SUCCEEDED"
	PhasePublishFailed    HistoryPhase = "PUBLISH_FAILED"
	PhaseAttemptStarted   HistoryPhase = "ATTEMPT_STARTED"
	PhaseAttemptFinished  HistoryPhase = "ATTEMPT_FINISHED"
70→	PhaseRetryPlanned     HistoryPhase = "RETRY_PLANNED"
	PhaseWaitPlanned      HistoryPhase = "WAIT_PLANNED"
	PhaseBlocked          HistoryPhase = "BLOCKED"
	PhaseUnblocked        HistoryPhase = "UNBLOCKED"
	PhaseLeaseExpired     HistoryPhase = "LEASE_EXPIRED"
	PhaseDispatchRepaired HistoryPhase = "DISPATCH_REPAIRED"
	PhaseDLQDisposed      HistoryPhase = "DLQ_DISPOSED"
	PhaseManualRetry      HistoryPhase = "MANUAL_RETRY"
	PhaseManualResolve    HistoryPhase = "MANUAL_RESOLVE"
	PhaseLateResponse     HistoryPhase = "LATE_RESPONSE"
80→)

// HistoryPhases 是固定阶段全集，供迁移容量和校验对照。
var HistoryPhases = []HistoryPhase{
	PhaseTaskCreated,
	PhaseScheduleCreated,
	PhasePublishSucceeded,
	PhasePublishFailed,
	PhaseAttemptStarted,
	PhaseAttemptFinished,
90→	PhaseRetryPlanned,
	PhaseWaitPlanned,
	PhaseBlocked,
	PhaseUnblocked,
	PhaseLeaseExpired,
	PhaseDispatchRepaired,
	PhaseDLQDisposed,
	PhaseManualRetry,
	PhaseManualResolve,
	PhaseLateResponse,
100→}


### Turn 24 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/data/mysql/mysql.go
- limit: 250
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/service/respond.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/service/httpx.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/server/http.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/auth/auth.go
- limit: 200

### Turn 25 (Function)
[tool_response]
1→// Package server 构造传输服务，负责路由、中间件与后台角色生命周期。
package server

import (
	"net/http"

	"notifier/internal/conf"
	"notifier/internal/service"
)
10→
// NewHTTPServer 只组装 HTTP 传输，不承载协议转换或业务规则。
func NewHTTPServer(cfg conf.HTTP, health *service.HealthService) *http.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", health.Healthz)
	mux.HandleFunc("GET /readyz", health.Readyz)
	mux.Handle("/v1/", RequireJSON(http.HandlerFunc(service.NotImplemented)))
	return &http.Server{
		Addr:              cfg.Addr,
		Handler:           RequestID(mux),
20→		ReadHeaderTimeout: cfg.RequestTimeout,
		ReadTimeout:       cfg.RequestTimeout,
		WriteTimeout:      cfg.RequestTimeout,
		MaxHeaderBytes:    cfg.MaxHeaderBytes,
	}
}


### Turn 26 (Function)
[tool_response]
1→package service

import (
	"encoding/json"
	"net/http"

	"notifier/internal/domain"
)

10→// writeJSON 以 JSON 写出响应体；编码失败时返回统一 500 占位。
func writeJSON(w http.ResponseWriter, status int, v any) {
	b, err := json.Marshal(v)
	if err != nil {
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		w.WriteHeader(http.StatusInternalServerError)
		_, _ = w.Write([]byte(`{"error":{"code":"internal","message":"encode response failed"}}`))
		return
	}
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
20→	w.WriteHeader(status)
	_, _ = w.Write(b)
}

// NotImplemented 提供业务接口尚未实现时的统一 501 响应。
func NotImplemented(w http.ResponseWriter, r *http.Request) {
	err, createErr := domain.NewError(CodeNotImplemented, "接口尚未实现", "", nil)
	if createErr != nil {
		writeJSON(w, http.StatusNotImplemented, errorEnvelope{Error: errorBody{Code: CodeNotImplemented, Message: "接口尚未实现"}})
		return
30→	}
	WriteError(w, r, err)
}


### Turn 27 (Function)
[tool_response]
1→// Package mysql 提供连接池、通用事务执行器和历史序号分配。
// 具体业务事务由 S02～S07 完成。
package mysql

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
10→	"fmt"
	"net"
	"time"

	mysqldrv "github.com/go-sql-driver/mysql"

	"notifier/internal/auth"
	"notifier/internal/conf"
)

20→// Open 按 MYSQL_OPERATION_TIMEOUT 建立连接池并确认能连通。
// 依赖 *auth.Set 只是为了让身份配置先于拨号失败，错误里不出现 DSN。
func Open(cfg conf.MySQL, _ *auth.Set) (*sql.DB, func(), error) {
	dsn, err := withTimeouts(cfg.DSN, cfg.OperationTimeout)
	if err != nil {
		return nil, nil, errors.New("mysql: MYSQL_DSN: invalid")
	}
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		return nil, nil, errors.New("mysql: MYSQL_DSN: open failed")
30→	}
	db.SetConnMaxLifetime(5 * time.Minute)
	db.SetMaxOpenConns(20)
	db.SetMaxIdleConns(10)
	ctx, cancel := context.WithTimeout(context.Background(), cfg.OperationTimeout)
	defer cancel()
	if err := db.PingContext(ctx); err != nil {
		_ = db.Close()
		return nil, nil, errors.New("mysql: MYSQL_DSN: connect failed")
	}
40→	return db, func() { _ = db.Close() }, nil
}

func withTimeouts(dsn string, budget time.Duration) (string, error) {
	parsed, err := mysqldrv.ParseDSN(dsn)
	if err != nil {
		return "", err
	}
	parsed.Timeout = budget
	parsed.ReadTimeout = budget
50→	parsed.WriteTimeout = budget
	parsed.ParseTime = true
	return parsed.FormatDSN(), nil
}

// FailureKind 区分唯一键冲突、死锁和连接中断。
type FailureKind int

const (
	FailureOther FailureKind = iota
60→	FailureUnique
	FailureDeadlock
	FailureConnLost
	FailureCommitUncertain
)

// CommitUncertainError 表示提交时连接丢失，不能判断事务是否落地。调用方不得重做 HTTP 或 MQ。
type CommitUncertainError struct {
	cause error
}
70→
func (e *CommitUncertainError) Error() string { return "mysql: commit uncertain" }

func (e *CommitUncertainError) Unwrap() error { return e.cause }

// Classify 给调用方区分可重试的数据库错误。不包含驱动原文，避免带出连接信息。
func Classify(err error) FailureKind {
	if err == nil {
		return FailureOther
	}
80→	var uncertain *CommitUncertainError
	if errors.As(err, &uncertain) {
		return FailureCommitUncertain
	}
	if isDeadlock(err) {
		return FailureDeadlock
	}
	if isUnique(err) {
		return FailureUnique
	}
90→	if isConnLost(err) {
		return FailureConnLost
	}
	return FailureOther
}

// Executor 在单个事务里执行回调。只有确认回滚的死锁或连接中断才重试，最多 2 次。
// 不重试唯一键冲突、锁等待，也不重试提交结果不确定的错误。不得把 HTTP/MQ 调用放进回调。
type Executor struct {
	db      *sql.DB
100→	timeout time.Duration
}

func NewExecutor(db *sql.DB, timeout time.Duration) *Executor {
	return &Executor{db: db, timeout: timeout}
}

const maxAttempts = 3 // 首次加上最多 2 次重试

func (e *Executor) RunTx(ctx context.Context, fn func(context.Context, *sql.Tx) error) error {
110→	var last error
	for attempt := 1; attempt <= maxAttempts; attempt++ {
		opCtx, cancel := context.WithTimeout(ctx, e.timeout)
		tx, err := e.db.BeginTx(opCtx, nil)
		if err != nil {
			cancel()
			last = err
			if attempt < maxAttempts && ctx.Err() == nil && isConnLost(err) {
				continue
			}
120→			return err
		}
		err = fn(opCtx, tx)
		if err != nil {
			rbErr := tx.Rollback()
			cancel()
			if rbErr != nil && !errors.Is(rbErr, sql.ErrTxDone) {
				return fmt.Errorf("mysql: rollback failed")
			}
			last = err
130→			if attempt < maxAttempts && ctx.Err() == nil && (isDeadlock(err) || isConnLost(err)) {
				continue
			}
			return err
		}
		if err = tx.Commit(); err != nil {
			cancel()
			if isConnLost(err) {
				return &CommitUncertainError{cause: err}
			}
140→			last = err
			if attempt < maxAttempts && ctx.Err() == nil && isDeadlock(err) {
				continue
			}
			return err
		}
		cancel()
		return nil
	}
	return last
150→}

func isUnique(err error) bool {
	n, ok := mysqlNumber(err)
	return ok && n == 1062
}

func isDeadlock(err error) bool {
	n, ok := mysqlNumber(err)
	return ok && n == 1213
160→}

func isConnLost(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, driver.ErrBadConn) || errors.Is(err, mysqldrv.ErrInvalidConn) {
		return true
	}
	if n, ok := mysqlNumber(err); ok && (n == 2006 || n == 2013) {
170→		return true
	}
	var netErr net.Error
	return errors.As(err, &netErr)
}

func mysqlNumber(err error) (uint16, bool) {
	var me *mysqldrv.MySQLError
	if errors.As(err, &me) {
		return me.Number, true
180→	}
	return 0, false
}


### Turn 28 (Function)
[tool_response]
1→package service

import (
	"errors"
	"io"
	"net/http"
	"strings"

	"notifier/internal/canonicaljson"
10→	"notifier/internal/domain"
)

// 错误码与 HTTP 状态的对应关系见 S00 第 8 节。未知码按 internal/500 处理。
const (
	CodeInvalidRequest        = "invalid_request"
	CodeInvalidCursor         = "invalid_cursor"
	CodeUnauthenticated       = "unauthenticated"
	CodeForbidden             = "forbidden"
	CodeNotFound              = "not_found"
20→	CodeIdempotencyConflict   = "idempotency_conflict"
	CodeVersionConflict       = "version_conflict"
	CodeStateConflict         = "state_conflict"
	CodePayloadTooLarge       = "payload_too_large"
	CodeUnsupportedMediaType  = "unsupported_media_type"
	CodeUnsupportedSchema     = "unsupported_schema"
	CodeNoMatchingRoute       = "no_matching_route"
	CodeMappingInvalid        = "mapping_invalid"
	CodeUnsafeReplay          = "unsafe_replay"
	CodeRateLimited           = "rate_limited"
30→	CodeDependencyUnavailable = "dependency_unavailable"
	CodeAdmissionPaused       = "admission_paused"
	CodeInternal              = "internal"
	CodeNotImplemented        = "not_implemented"
)

// StatusOf 返回稳定错误码对应的 HTTP 状态。
func StatusOf(code string) int {
	switch code {
	case CodeInvalidRequest, CodeInvalidCursor:
40→		return http.StatusBadRequest
	case CodeUnauthenticated:
		return http.StatusUnauthorized
	case CodeForbidden:
		return http.StatusForbidden
	case CodeNotFound:
		return http.StatusNotFound
	case CodeIdempotencyConflict, CodeVersionConflict, CodeStateConflict:
		return http.StatusConflict
	case CodePayloadTooLarge:
50→		return http.StatusRequestEntityTooLarge
	case CodeUnsupportedMediaType:
		return http.StatusUnsupportedMediaType
	case CodeUnsupportedSchema, CodeNoMatchingRoute, CodeMappingInvalid, CodeUnsafeReplay:
		return http.StatusUnprocessableEntity
	case CodeRateLimited:
		return http.StatusTooManyRequests
	case CodeDependencyUnavailable, CodeAdmissionPaused:
		return http.StatusServiceUnavailable
	case CodeNotImplemented:
60→		return http.StatusNotImplemented
	default:
		return http.StatusInternalServerError
	}
}

type errorEnvelope struct {
	Error errorBody `json:"error"`
}

70→type errorBody struct {
	Code      string       `json:"code"`
	Message   string       `json:"message"`
	FieldPath string       `json:"field_path,omitempty"`
	RequestID string       `json:"request_id,omitempty"`
	Details   []detailBody `json:"details,omitempty"`
}

type detailBody struct {
	FieldPath string `json:"field_path,omitempty"`
80→	Code      string `json:"code"`
	Message   string `json:"message"`
}

// WriteError 按领域错误写出 envelope。message 使用领域错误里的安全文本。
func WriteError(w http.ResponseWriter, r *http.Request, err error) {
	var de *domain.Error
	if !errors.As(err, &de) || de == nil {
		de = &domain.Error{Code: CodeInternal, Message: "内部错误"}
	}
90→	code := de.Code
	if StatusOf(code) == http.StatusInternalServerError && code != CodeInternal {
		code = CodeInternal
	}
	body := errorBody{Code: code, Message: de.Message, FieldPath: de.FieldPath}
	if r != nil {
		body.RequestID = RequestIDFrom(r.Context())
	}
	if len(de.Details) > 0 {
		body.Details = make([]detailBody, len(de.Details))
100→		for i, item := range de.Details {
			body.Details[i] = detailBody{FieldPath: item.FieldPath, Code: item.Code, Message: item.Message}
		}
	}
	writeJSON(w, StatusOf(code), errorEnvelope{Error: body})
}

// CheckContentType 只接受 application/json，可选 charset=utf-8。
func CheckContentType(r *http.Request) error {
	media := r.Header.Get("Content-Type")
110→	media, _, _ = strings.Cut(media, ";")
	params := contentParams(r.Header.Get("Content-Type"))
	if !strings.EqualFold(strings.TrimSpace(media), "application/json") {
		err, _ := domain.NewError(CodeUnsupportedMediaType, "仅接受 application/json", "", nil)
		return err
	}
	if charset, ok := params["charset"]; ok && !strings.EqualFold(charset, "utf-8") {
		err, _ := domain.NewError(CodeUnsupportedMediaType, "仅接受 application/json", "", nil)
		return err
	}
120→	return nil
}

func contentParams(header string) map[string]string {
	out := map[string]string{}
	parts := strings.Split(header, ";")
	for _, part := range parts[1:] {
		key, value, ok := strings.Cut(part, "=")
		if !ok {
			continue
130→		}
		out[strings.ToLower(strings.TrimSpace(key))] = strings.Trim(strings.TrimSpace(value), `"`)
	}
	return out
}

// ReadBody 按实际读取字节判断大小，不信任 Content-Length。
// 超过 maxBytes 返回 payload_too_large。
func ReadBody(r *http.Request, maxBytes int64) ([]byte, error) {
	if maxBytes < 0 {
140→		maxBytes = 0
	}
	limited := io.LimitReader(r.Body, maxBytes+1)
	body, err := io.ReadAll(limited)
	if err != nil {
		de, _ := domain.NewError(CodeInvalidRequest, "无法读取请求体", "", nil)
		return nil, de
	}
	if int64(len(body)) > maxBytes {
		de, _ := domain.NewError(CodePayloadTooLarge, "请求体超过上限", "", nil)
150→		return nil, de
	}
	return body, nil
}

// RejectUnknownFields 拒绝 envelope 中的未知字段。不回显字段值。
func RejectUnknownFields(raw []byte, allowed []string) error {
	value, err := canonicaljson.ParseObject(raw)
	if err != nil {
		de, _ := domain.NewError(CodeInvalidRequest, "JSON 不是完整对象", "", nil)
160→		return de
	}
	fields, ok := value.Object()
	if !ok {
		de, _ := domain.NewError(CodeInvalidRequest, "JSON 不是完整对象", "", nil)
		return de
	}
	allow := make(map[string]struct{}, len(allowed))
	for _, key := range allowed {
		allow[key] = struct{}{}
170→	}
	for _, field := range fields {
		if _, ok := allow[field.Key]; !ok {
			de, _ := domain.NewError(CodeInvalidRequest, "请求包含未知字段", field.Key, nil)
			return de
		}
	}
	return nil
}

180→// RejectQuery 拒绝未知查询参数和重复参数。错误不包含参数值。
func RejectQuery(r *http.Request, allowed []string) error {
	query := r.URL.Query()
	allow := make(map[string]struct{}, len(allowed))
	for _, key := range allowed {
		allow[key] = struct{}{}
	}
	for key, values := range query {
		if _, ok := allow[key]; !ok {
			de, _ := domain.NewError(CodeInvalidRequest, "未知查询参数", key, nil)
190→			return de
		}
		if len(values) > 1 {
			de, _ := domain.NewError(CodeInvalidRequest, "查询参数重复", key, nil)
			return de
		}
	}
	return nil
}


### Turn 29 (Function)
[tool_response]
1→// Package auth 把受保护的身份配置解析成调用上下文。
//
// 服务只保存 Bearer 原始字节的 SHA-256，并用恒定时间比较。
// 真实 Token 不进入领域对象、数据库参数或日志。
// 单次进程使用启动时加载的配置；轮换和撤销通过滚动重启生效，本包不做热更新。
package auth

import (
	"crypto/sha256"
10→	"crypto/subtle"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"strings"

	"notifier/internal/canonicaljson"
	"notifier/internal/constant"
	"notifier/internal/domain"
20→)

const bearerPrefix = "Bearer "

var (
	// ErrUnauthenticated 表示没有匹配的凭证。
	ErrUnauthenticated = errors.New("auth: unauthenticated")
	// ErrDisabled 表示凭证匹配到已禁用身份。与错误凭证区分开。
	ErrDisabled = errors.New("auth: identity disabled")
)
30→
// Context 是认证层输出的调用上下文。凭证本身不在其中。
type Context struct {
	ActorID        string
	CallerID       string
	AllowedSources []string
	Permissions    []string
	CallerScopes   []string
}

40→// Allows 只判断权限码是否存在。写操作还要另查 CallerScopes，ops:read 不隐含写权限。
func (c Context) Allows(permission string) bool {
	for _, item := range c.Permissions {
		if item == permission {
			return true
		}
	}
	return false
}

50→// ScopeContains 判断目标调用方是否在本次身份的明确范围内。
func (c Context) ScopeContains(callerID string) bool {
	for _, item := range c.CallerScopes {
		if item == callerID {
			return true
		}
	}
	return false
}

60→// Identity 是一份已校验的身份。TokenSHA256 为小写十六进制。
type Identity struct {
	ActorID        string
	CallerID       string
	TokenSHA256    string
	AllowedSources []string
	CallerScopes   []string
	Permissions    []string
	Enabled        bool
}
70→
// Set 是进程内生效的身份集合。
type Set struct {
	items []stored
}

type stored struct {
	hash    [32]byte
	enabled bool
	ctx     Context
80→}

// Available 在至少有一个启用身份时为真。没有可用身份时进程不得对外就绪。
func (s *Set) Available() bool {
	if s == nil {
		return false
	}
	for _, item := range s.items {
		if item.enabled {
			return true
90→		}
	}
	return false
}

// Authenticate 用 Bearer 原始字节的 SHA-256 与全部身份做恒定时间比较。
// 不因先行命中而提前返回。禁用身份与未知凭证是不同错误。
func (s *Set) Authenticate(token string) (Context, error) {
	if s == nil || token == "" {
		return Context{}, ErrUnauthenticated
100→	}
	sum := sha256.Sum256([]byte(token))
	var matched *stored
	found := 0
	for i := range s.items {
		eq := subtle.ConstantTimeCompare(sum[:], s.items[i].hash[:])
		if eq == 1 && found == 0 {
			matched = &s.items[i]
		}
		found |= eq
110→	}
	if found == 0 || matched == nil {
		return Context{}, ErrUnauthenticated
	}
	if !matched.enabled {
		return Context{}, ErrDisabled
	}
	return matched.ctx, nil
}

120→// BearerToken 只接受精确前缀 "Bearer "。前后多余空白视为未认证。
func BearerToken(header string) (string, error) {
	if !strings.HasPrefix(header, bearerPrefix) {
		return "", ErrUnauthenticated
	}
	token := header[len(bearerPrefix):]
	if token == "" || strings.ContainsAny(token, " \t") {
		return "", ErrUnauthenticated
	}
	return token, nil
130→}

// NewStatic 校验并装载调用方注入的身份。本地测试用它代替文件。
func NewStatic(list []Identity) (*Set, error) {
	return build(list)
}

// LoadFile 读取 AUTH_CONFIG_REF 指向的身份文件。错误不包含 Token 或哈希。
func LoadFile(path string) (*Set, error) {
	if path == "" {
140→		return nil, errors.New("auth: AUTH_CONFIG_REF must not be empty")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, errors.New("auth: AUTH_CONFIG_REF: read failed")
	}
	list, err := parseConfig(raw)
	if err != nil {
		return nil, err
	}
150→	return build(list)
}

func build(list []Identity) (*Set, error) {
	if len(list) == 0 {
		return nil, errors.New("auth: AUTH_CONFIG_REF: no usable identity")
	}
	seenHash := make(map[string]struct{}, len(list))
	seenActor := make(map[string]struct{}, len(list))
	items := make([]stored, 0, len(list))
160→	enabled := 0
	for _, item := range list {
		if err := validateIdentity(item); err != nil {
			return nil, err
		}
		if _, ok := seenHash[item.TokenSHA256]; ok {
			return nil, errors.New("auth: AUTH_CONFIG_REF: duplicate token_sha256")
		}
		seenHash[item.TokenSHA256] = struct{}{}
		if _, ok := seenActor[item.ActorID]; ok {
170→			return nil, errors.New("auth: AUTH_CONFIG_REF: duplicate actor_id")
		}
		seenActor[item.ActorID] = struct{}{}
		decoded, err := hex.DecodeString(item.TokenSHA256)
		if err != nil || len(decoded) != sha256.Size || hex.EncodeToString(decoded) != item.TokenSHA256 {
			return nil, errors.New("auth: AUTH_CONFIG_REF: invalid token_sha256")
		}
		var hash [32]byte
		copy(hash[:], decoded)
		if item.Enabled {
180→			enabled++
		}
		items = append(items, stored{
			hash:    hash,
			enabled: item.Enabled,
			ctx: Context{
				ActorID:        item.ActorID,
				CallerID:       item.CallerID,
				AllowedSources: append([]string(nil), item.AllowedSources...),
				Permissions:    append([]string(nil), item.Permissions...),
190→				CallerScopes:   append([]string(nil), item.CallerScopes...),
			},
		})
	}
	if enabled == 0 {
		return nil, errors.New("auth: AUTH_CONFIG_REF: no usable identity")
	}
	return &Set{items: items}, nil
}

200→func validateIdentity(item Identity) error {

### Turn 30 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/migrations/00001_init.sql
- offset: 180
- limit: 70
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/conf/config.go
- limit: 250
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/canonicaljson/canonicaljson.go
- limit: 200
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/ident.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/server/middleware.go

### Turn 31 (Function)
[tool_response]
180→    CONSTRAINT fk_attempt_delivery FOREIGN KEY (delivery_id) REFERENCES delivery_tasks (delivery_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin;

-- 任务全过程时间线（追加记录）
CREATE TABLE delivery_history (
    history_id       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    delivery_id      BIGINT UNSIGNED NOT NULL,
    history_seq      INT UNSIGNED    NOT NULL,
    write_id         VARCHAR(64)     NOT NULL,              -- 写入标识，事务重试不重复追加
    phase            VARCHAR(64)     NOT NULL,
190→    from_status      VARCHAR(16)     NULL,
    to_status        VARCHAR(16)     NULL,
    reason           VARCHAR(1024)   NULL,
    round_no         INT UNSIGNED    NULL,
    schedule_version INT UNSIGNED    NULL,
    attempt_id       BIGINT UNSIGNED NULL,
    outbox_id        BIGINT UNSIGNED NULL,
    operation_id     VARCHAR(64)     NULL,
    actor            VARCHAR(64)     NULL,
    evidence         JSON            NULL,                  -- 脱敏补充证据
200→    occurred_at      DATETIME(6)     NULL,                  -- 实际发生时间
    recorded_at      DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (history_id),
    UNIQUE KEY uq_history_write (write_id),
    UNIQUE KEY uq_history_seq (delivery_id, history_seq),
    KEY idx_history_delivery (delivery_id, history_seq),
    CONSTRAINT fk_history_delivery FOREIGN KEY (delivery_id) REFERENCES delivery_tasks (delivery_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin;

-- 管理操作（配置发布、人工重投、结果核对及死信处理）
210→CREATE TABLE management_events (
    management_id       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    operation_type      VARCHAR(64)     NOT NULL,           -- config_publish | manual_retry | resolve | dlq_repair
    operation_id        VARCHAR(64)     NOT NULL,
    idempotency_key     VARCHAR(191)    NOT NULL,
    caller_scope        VARCHAR(64)     NOT NULL,
    request_fingerprint CHAR(64)        NULL,
    expected_version    INT UNSIGNED    NULL,
    actor               VARCHAR(64)     NOT NULL,
    reason              VARCHAR(1024)   NULL,
220→    target_type         VARCHAR(32)     NULL,
    target_id           VARCHAR(191)    NULL,
    result              JSON            NULL,
    created_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (management_id),
    UNIQUE KEY uq_mgmt_idempotency (caller_scope, operation_type, idempotency_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin;

-- +goose Down
DROP TABLE IF EXISTS management_events;
230→DROP TABLE IF EXISTS delivery_history;
DROP TABLE IF EXISTS delivery_attempts;
DROP TABLE IF EXISTS outbox_messages;
DROP TABLE IF EXISTS delivery_tasks;
DROP TABLE IF EXISTS business_events;
DROP TABLE IF EXISTS channels;
DROP TABLE IF EXISTS routing_current;
DROP TABLE IF EXISTS routing_releases;


### Turn 32 (Function)
[tool_response]
1→package server

import (
	"net/http"

	"notifier/internal/service"
)

// RequestID 保证每个响应都带 X-Request-ID。非法入参会换成 32 位十六进制随机值。
10→func RequestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := service.NormalizeRequestID(r.Header.Get("X-Request-ID"))
		w.Header().Set("X-Request-ID", id)
		next.ServeHTTP(w, r.WithContext(service.WithRequestID(r.Context(), id)))
	})
}

// RequireJSON 让写方法只接受 application/json。读方法保持原样，供后续查询接口使用。
func RequireJSON(next http.Handler) http.Handler {
20→	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodPost, http.MethodPut, http.MethodPatch:
			if err := service.CheckContentType(r); err != nil {
				service.WriteError(w, r, err)
				return
			}
		}
		next.ServeHTTP(w, r)
	})
30→}


### Turn 33 (Function)
[tool_response]
1→package domain

import (
	"errors"
	"fmt"
	"math"
	"strconv"
	"unicode"
	"unicode/utf8"
10→)

// 标识规则见 S00 第 9 节。比较区分大小写，不裁剪、不改大小写、不做 Unicode 归一化。

const (
	maxASCIIIdent64  = 64
	maxASCIIIdent128 = 128
	maxASCIIIdent32  = 32
	maxExternalID    = 191
	maxCount         = math.MaxUint32
20→)

// ValidateASCIIIdent 校验 `[A-Za-z0-9][A-Za-z0-9._:-]*`，长度按字节计。
func ValidateASCIIIdent(field, value string, maxLen int) error {
	if value == "" || len(value) > maxLen {
		return fmt.Errorf("domain: %s: invalid identifier", field)
	}
	for i := 0; i < len(value); i++ {
		c := value[i]
		ok := c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c >= '0' && c <= '9'
30→		if i > 0 {
			ok = ok || c == '.' || c == '_' || c == ':' || c == '-'
		}
		if !ok {
			return fmt.Errorf("domain: %s: invalid identifier", field)
		}
	}
	return nil
}

40→func ValidateCallerID(value string) error {
	return ValidateASCIIIdent("caller_id", value, maxASCIIIdent64)
}

func ValidateSourceBusiness(value string) error {
	return ValidateASCIIIdent("source_business", value, maxASCIIIdent64)
}

func ValidateProviderID(value string) error {
	return ValidateASCIIIdent("provider_id", value, maxASCIIIdent64)
50→}

func ValidateProviderAccountID(value string) error {
	return ValidateASCIIIdent("provider_account_id", value, maxASCIIIdent64)
}

func ValidateOperation(value string) error {
	return ValidateASCIIIdent("operation", value, maxASCIIIdent64)
}

60→func ValidateBusinessObjectType(value string) error {
	return ValidateASCIIIdent("business_object_type", value, maxASCIIIdent64)
}

func ValidateActorID(value string) error {
	return ValidateASCIIIdent("actor_id", value, maxASCIIIdent64)
}

func ValidateEventType(value string) error {
	return ValidateASCIIIdent("event_type", value, maxASCIIIdent128)
70→}

func ValidateRouteTargetID(value string) error {
	return ValidateASCIIIdent("route_target_id", value, maxASCIIIdent128)
}

func ValidateSchemaVersion(value string) error {
	return ValidateASCIIIdent("schema_version", value, maxASCIIIdent32)
}

80→func ValidateAdapterVersion(value string) error {
	return ValidateASCIIIdent("adapter_version", value, maxASCIIIdent32)
}

func ValidateMappingVersion(value string) error {
	return ValidateASCIIIdent("mapping_version", value, maxASCIIIdent32)
}

// ValidateExternalID 校验来源事件、业务对象和操作幂等键。
// 保留原文，禁止控制字符和纯空白。
90→func ValidateExternalID(field, value string) error {
	if value == "" || len(value) > maxExternalID || !utf8.ValidString(value) {
		return fmt.Errorf("domain: %s: invalid identifier", field)
	}
	blank := true
	for _, r := range value {
		if r < 0x20 || r == 0x7f {
			return fmt.Errorf("domain: %s: invalid identifier", field)
		}
		if !unicode.IsSpace(r) {
100→			blank = false
		}
	}
	if blank {
		return fmt.Errorf("domain: %s: invalid identifier", field)
	}
	return nil
}

// ParseInternalID 解析 HTTP/MQ 中的内部主键十进制字符串。
110→// 范围 1..uint64 max，禁止符号、前导零和浮点形式。
func ParseInternalID(field, value string) (uint64, error) {
	if value == "" || value[0] == '0' || value[0] == '+' || value[0] == '-' {
		return 0, fmt.Errorf("domain: %s: invalid identifier", field)
	}
	for i := 0; i < len(value); i++ {
		if value[i] < '0' || value[i] > '9' {
			return 0, fmt.Errorf("domain: %s: invalid identifier", field)
		}
	}
120→	n, err := strconv.ParseUint(value, 10, 64)
	if err != nil || n == 0 {
		return 0, fmt.Errorf("domain: %s: invalid identifier", field)
	}
	return n, nil
}

// FormatInternalID 把内部主键写成不带前导零的十进制字符串。
func FormatInternalID(id uint64) (string, error) {
	if id == 0 {
130→		return "", errors.New("domain: internal id must be positive")
	}
	return strconv.FormatUint(id, 10), nil
}

// CheckCount 校验轮次、版本、次数和历史序号的首版上限。溢出不回绕。
func CheckCount(field string, n uint64) error {
	if n > maxCount {
		return fmt.Errorf("domain: %s: count overflow", field)
	}
140→	return nil
}


### Turn 34 (Function)
[tool_response]
1→// Package conf 加载进程启动配置，汇总环境变量与 Azure Key Vault 密钥。
//
// 所有运行参数均可通过环境变量覆盖，未设置时使用技术方案第 13 节和 S00 第 9 节的初始值。
// 配置值在启动时解析，运行期间不可变；需要动态调整的运行参数属于发布快照，
// 由业务用例管理，不经过本包。GlobalConfig 通过构造函数注入，不使用可变全局变量。
// 越界或关系不成立时启动失败。错误只包含参数名，不包含秘密值。
package conf

import (
10→	"context"
	"fmt"
	"os"
	"strconv"
	"time"
)

// GlobalConfig 是启动完成后的配置快照，运行期间只读。
type GlobalConfig struct {
	KeyVault  KeyVault
20→	HTTP      HTTP
	MySQL     MySQL
	Redis     Redis
	RocketMQ  RocketMQ
	Delivery  Delivery
	Outbox    Outbox
	Recovery  Recovery
	Retention Retention
	Log       Log
	Auth      Auth
30→	Limits    Limits
}

// HTTP 接入与查询服务。
type HTTP struct {
	Addr            string        // 监听地址，如 ":8080"
	RequestTimeout  time.Duration // 接入和管理请求总预算
	ShutdownTimeout time.Duration // 先停止入口，再排空后台角色
	MaxHeaderBytes  int           // 请求头上限，超限由 net/http 拒绝
}
40→
// MySQL 主存储。
type MySQL struct {
	DSN              string        // 例：user:pass@tcp(127.0.0.1:3306)/notifier?parseTime=true&charset=utf8mb4
	OperationTimeout time.Duration // 每个完整事务或查询的上限
}

// Redis 缓存与限流。
type Redis struct {
	Addr     string
50→	Password string
	DB       int
}

// RocketMQ 消息收发（gRPC Proxy 接入）。
type RocketMQ struct {
	Endpoint       string // gRPC 接入端点，如 "127.0.0.1:8081"
	TopicImmediate string // 即时投递指令 Topic
	TopicDelayed   string // 延迟投递指令 Topic
	Group          string // 消费者分组
60→}

// Delivery 投递执行参数（技术方案第 13 节初始建议）。
// S03 还会增加构造、结果预留和 ACK 预算；那些参数到位后收紧这里的关系检查。
type Delivery struct {
	Parallelism    int           // 并行投递 worker 数，建议 10
	HTTPTimeout    time.Duration // 供应商 HTTP 超时，建议 10s
	LeaseTimeout   time.Duration // 任务领取期限，建议 30s
	MQInvisible    time.Duration // MQ 不可见期限，建议 60s
	MaxAttempts    int           // 每轮最多尝试次数，建议 8
70→	BackoffInitial time.Duration // 退避起始，建议 5s
	BackoffCap     time.Duration // 本地退避上限，建议 5m
	ServerWaitCap  time.Duration // 服务端等待建议上限，建议 1h
	RoundDeadline  time.Duration // 本轮等待截止，建议 24h
	BlockedCheck   time.Duration // 阻塞条件检查间隔，建议 60s
}

// Outbox 可靠发布参数。
type Outbox struct {
	PollInterval time.Duration // 空闲轮询，建议 1s
80→	GracePeriod  time.Duration // 补发宽限，建议 5m
}

// Recovery 补偿扫描参数。
type Recovery struct {
	ScanInterval time.Duration // 补偿扫描，建议 30s
}

// Retention 数据保留与缓存策略。
type Retention struct {
90→	OverviewCache time.Duration // 运行概览缓存，建议 5s
	ResolvedAfter time.Duration // 结案记录保留期，建议 30 天
}

// Log 结构化日志。
type Log struct {
	Level  string // debug | info | warn | error
	Format string // json | text
}

100→// Auth 是身份映射引用。文件内容由 auth 包加载，本结构只保存路径。
type Auth struct {
	ConfigRef string
}

// Limits 是跨请求、响应和错误摘要共用的字节上限。
type Limits struct {
	SummaryBytes int
}

110→// Default 返回技术方案第 13 节和 S00 第 9 节给出的初始建议配置。
func Default() GlobalConfig {
	return GlobalConfig{
		KeyVault: KeyVault{Timeout: 15 * time.Second},
		HTTP: HTTP{
			Addr:            ":8080",
			RequestTimeout:  5 * time.Second,
			ShutdownTimeout: 45 * time.Second,
			MaxHeaderBytes:  16 * 1024,
		},
120→		MySQL: MySQL{
			DSN:              "notifier:notifier@tcp(127.0.0.1:3306)/notifier?parseTime=true&charset=utf8mb4",
			OperationTimeout: 2 * time.Second,
		},
		Redis: Redis{Addr: "127.0.0.1:6379"},
		RocketMQ: RocketMQ{
			Endpoint:       "127.0.0.1:8081",
			TopicImmediate: "notifier-delivery",
			TopicDelayed:   "notifier-delivery-delay",
			Group:          "notifier-worker",
130→		},
		Delivery: Delivery{
			Parallelism:    10,
			HTTPTimeout:    10 * time.Second,
			LeaseTimeout:   30 * time.Second,
			MQInvisible:    60 * time.Second,
			MaxAttempts:    8,
			BackoffInitial: 5 * time.Second,
			BackoffCap:     5 * time.Minute,
			ServerWaitCap:  time.Hour,
140→			RoundDeadline:  24 * time.Hour,
			BlockedCheck:   60 * time.Second,
		},
		Outbox: Outbox{
			PollInterval: time.Second,
			GracePeriod:  5 * time.Minute,
		},
		Recovery: Recovery{ScanInterval: 30 * time.Second},
		Retention: Retention{
			OverviewCache: 5 * time.Second,
150→			ResolvedAfter: 30 * 24 * time.Hour,
		},
		Log:    Log{Level: "info", Format: "json"},
		Auth:   Auth{ConfigRef: "config/identities.example.json"},
		Limits: Limits{SummaryBytes: 2048},
	}
}

// Load 汇总默认值、环境变量和 Key Vault 密钥。任一来源失败时不返回部分配置。
func Load(ctx context.Context) (GlobalConfig, error) {
160→	return (Loader{}).Load(ctx)
}

// Load 支持注入密钥读取器；未注入时使用 Azure SDK。
func (l Loader) Load(ctx context.Context) (GlobalConfig, error) {
	c := Default()

	c.KeyVault.URL = envStr("AZURE_KEY_VAULT_URL", c.KeyVault.URL)
	c.KeyVault.MySQLDSNSecret = envStr("MYSQL_DSN_SECRET", c.KeyVault.MySQLDSNSecret)
	c.KeyVault.RedisPasswordSecret = envStr("REDIS_PASSWORD_SECRET", c.KeyVault.RedisPasswordSecret)
170→	c.HTTP.Addr = envStr("HTTP_ADDR", c.HTTP.Addr)
	var err error
	if c.MySQL.DSN, err = envRequired("MYSQL_DSN", c.MySQL.DSN); err != nil {
		return GlobalConfig{}, err
	}
	if c.Redis.Addr, err = envRequired("REDIS_ADDR", c.Redis.Addr); err != nil {
		return GlobalConfig{}, err
	}
	c.Redis.Password = envStr("REDIS_PASSWORD", c.Redis.Password)
	if c.RocketMQ.Endpoint, err = envRequired("ROCKETMQ_ENDPOINT", c.RocketMQ.Endpoint); err != nil {
180→		return GlobalConfig{}, err
	}
	c.RocketMQ.TopicImmediate = envStr("ROCKETMQ_TOPIC_IMMEDIATE", c.RocketMQ.TopicImmediate)
	c.RocketMQ.TopicDelayed = envStr("ROCKETMQ_TOPIC_DELAYED", c.RocketMQ.TopicDelayed)
	c.RocketMQ.Group = envStr("ROCKETMQ_GROUP", c.RocketMQ.Group)
	c.Log.Level = envStr("LOG_LEVEL", c.Log.Level)
	c.Log.Format = envStr("LOG_FORMAT", c.Log.Format)
	if c.Auth.ConfigRef, err = envRequired("AUTH_CONFIG_REF", c.Auth.ConfigRef); err != nil {
		return GlobalConfig{}, err
	}
190→
	if c.Redis.DB, err = envInt("REDIS_DB", c.Redis.DB); err != nil {
		return GlobalConfig{}, err
	}
	if c.Delivery.Parallelism, err = envInt("DELIVERY_PARALLELISM", c.Delivery.Parallelism); err != nil {
		return GlobalConfig{}, err
	}
	if c.Delivery.MaxAttempts, err = envInt("DELIVERY_MAX_ATTEMPTS", c.Delivery.MaxAttempts); err != nil {
		return GlobalConfig{}, err
	}
200→	if c.HTTP.MaxHeaderBytes, err = envInt("HTTP_MAX_HEADER_BYTES", c.HTTP.MaxHeaderBytes); err != nil {
		return GlobalConfig{}, err
	}
	if c.Limits.SummaryBytes, err = envInt("SUMMARY_MAX_BYTES", c.Limits.SummaryBytes); err != nil {
		return GlobalConfig{}, err
	}

	durations := []struct {
		key string
		dst *time.Duration
210→	}{
		{"AZURE_KEY_VAULT_TIMEOUT", &c.KeyVault.Timeout},
		{"HTTP_REQUEST_TIMEOUT", &c.HTTP.RequestTimeout},
		{"HTTP_SHUTDOWN_TIMEOUT", &c.HTTP.ShutdownTimeout},
		{"MYSQL_OPERATION_TIMEOUT", &c.MySQL.OperationTimeout},
		{"DELIVERY_HTTP_TIMEOUT", &c.Delivery.HTTPTimeout},
		{"DELIVERY_LEASE_TIMEOUT", &c.Delivery.LeaseTimeout},
		{"DELIVERY_MQ_INVISIBLE", &c.Delivery.MQInvisible},
		{"DELIVERY_BACKOFF_INITIAL", &c.Delivery.BackoffInitial},
		{"DELIVERY_BACKOFF_CAP", &c.Delivery.BackoffCap},
220→		{"DELIVERY_SERVER_WAIT_CAP", &c.Delivery.ServerWaitCap},
		{"DELIVERY_ROUND_DEADLINE", &c.Delivery.RoundDeadline},
		{"DELIVERY_BLOCKED_CHECK", &c.Delivery.BlockedCheck},
		{"OUTBOX_POLL_INTERVAL", &c.Outbox.PollInterval},
		{"OUTBOX_GRACE_PERIOD", &c.Outbox.GracePeriod},
		{"RECOVERY_SCAN_INTERVAL", &c.Recovery.ScanInterval},
		{"RETENTION_OVERVIEW_CACHE", &c.Retention.OverviewCache},
		{"RETENTION_RESOLVED_AFTER", &c.Retention.ResolvedAfter},
	}
	for _, d := range durations {
230→		if *d.dst, err = envDuration(d.key, *d.dst); err != nil {
			return GlobalConfig{}, err
		}
	}

	if err := l.resolveSecrets(ctx, &c); err != nil {
		return GlobalConfig{}, err
	}
	if err := validate(&c); err != nil {
		return GlobalConfig{}, err
240→	}
	return c, nil
}

func envStr(key, def string) string {
	if v, ok := os.LookupEnv(key); ok && v != "" {
		return v
	}
	return def
}
250→

### Turn 35 (Function)
[tool_response]
1→// Package canonicaljson 解析并规范化精确 JSON。
//
// 数字保持十进制，不经过 float64。对象键按 Unicode 码点排序。
// 指纹算法版本见 constant.FingerprintVersion；本包只对已规范化字节计算 SHA-256。
package canonicaljson

import (
	"crypto/sha256"
	"encoding/hex"
10→	"fmt"
	"slices"
	"strconv"
	"strings"
	"unicode/utf8"

	"notifier/internal/constant"
)

const (
20→	maxDepth         = constant.MaxJSONDepth
	maxNumberLiteral = constant.MaxJSONNumberLiteral
	maxCoefficient   = constant.MaxJSONCoefficientBits
	maxExponent      = constant.MaxJSONExponent
)

// Error 是可定位的 JSON 语法或范围错误。
type Error struct {
	Reason string
	Offset int
30→}

func (e *Error) Error() string {
	return fmt.Sprintf("canonicaljson: %s at byte %d", e.Reason, e.Offset)
}

func errAt(reason string, offset int) error {
	return &Error{Reason: reason, Offset: offset}
}

40→// Kind 是 JSON 值类别。
type Kind int

const (
	KindNull Kind = iota
	KindBool
	KindNumber
	KindString
	KindArray
	KindObject
50→)

// Field 是对象的一个成员。编码时按键排序，不保留原文顺序。
type Field struct {
	Key   string
	Value Value
}

// Value 是精确 JSON 值。数字以规范化十进制文本保存。
type Value struct {
60→	kind Kind
	b    bool
	num  string
	str  string
	arr  []Value
	obj  []Field
}

func (v Value) Kind() Kind { return v.kind }

70→func (v Value) Bool() (bool, bool) {
	if v.kind != KindBool {
		return false, false
	}
	return v.b, true
}

func (v Value) Text() (string, bool) {
	if v.kind != KindString {
		return "", false
80→	}
	return v.str, true
}

// NumberCanonical 返回规范化数字文本，例如 1e0、123e-4。零为 "0"。
func (v Value) NumberCanonical() (string, bool) {
	if v.kind != KindNumber {
		return "", false
	}
	return v.num, true
90→}

func (v Value) Array() ([]Value, bool) {
	if v.kind != KindArray {
		return nil, false
	}
	return v.arr, true
}

func (v Value) Object() ([]Field, bool) {
100→	if v.kind != KindObject {
		return nil, false
	}
	return v.obj, true
}

// ParseObject 解析一个完整 JSON 对象。拒绝重复键、尾随数据、非法 UTF-8、
// 不成对的代理项、超过 32 层的容器、超过 128 字节的数字字面量，
// 以及规范化后系数超过 64 位或指数超出 -308..308 的数字。
func ParseObject(raw []byte) (Value, error) {
110→	p := parser{b: raw}
	p.skipWS()
	if p.i >= len(p.b) || p.b[p.i] != '{' {
		return Value{}, errAt("expected object", p.i)
	}
	v, err := p.parseObject(1)
	if err != nil {
		return Value{}, err
	}
	p.skipWS()
120→	if p.i != len(p.b) {
		return Value{}, errAt("trailing data", p.i)
	}
	return v, nil
}

// Canonical 解析对象并返回规范化字节。
func Canonical(raw []byte) ([]byte, error) {
	v, err := ParseObject(raw)
	if err != nil {
130→		return nil, err
	}
	return AppendCanonical(nil, v), nil
}

// AppendCanonical 把值写成规范化 JSON。
func AppendCanonical(dst []byte, v Value) []byte {
	switch v.kind {
	case KindNull:
		return append(dst, "null"...)
140→	case KindBool:
		if v.b {
			return append(dst, "true"...)
		}
		return append(dst, "false"...)
	case KindNumber:
		return append(dst, v.num...)
	case KindString:
		return appendString(dst, v.str)
	case KindArray:
150→		dst = append(dst, '[')
		for i, item := range v.arr {
			if i > 0 {
				dst = append(dst, ',')
			}
			dst = AppendCanonical(dst, item)
		}
		return append(dst, ']')
	case KindObject:
		fields := append([]Field(nil), v.obj...)
160→		slices.SortFunc(fields, func(a, b Field) int {
			return strings.Compare(a.Key, b.Key)
		})
		dst = append(dst, '{')
		for i, field := range fields {
			if i > 0 {
				dst = append(dst, ',')
			}
			dst = appendString(dst, field.Key)
			dst = append(dst, ':')
170→			dst = AppendCanonical(dst, field.Value)
		}
		return append(dst, '}')
	default:
		return append(dst, "null"...)
	}
}

// Fingerprint 是规范化字节的 SHA-256 小写十六进制。版本号单独持久化。
func Fingerprint(canonical []byte) string {
180→	sum := sha256.Sum256(canonical)
	return hex.EncodeToString(sum[:])
}

func appendString(dst []byte, s string) []byte {
	dst = append(dst, '"')
	for _, r := range s {
		switch r {
		case '"':
			dst = append(dst, '\\', '"')
190→		case '\\':
			dst = append(dst, '\\', '\\')
		default:
			if r < 0x20 {
				dst = fmt.Appendf(dst, `\u%04x`, r)
			} else {
				dst = utf8.AppendRune(dst, r)
			}
		}
	}
200→	return append(dst, '"')

### Turn 36 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/docs/05-provider-runtime.spec.md
- limit: 180
[tool_request: grep]
- pattern: config|发布|routing|CalculatePlan|CONFIG_MAX
- glob: TECH_DESIGN.md
- head_limit: 40
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/conf/validate.go
- limit: 200
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/cmd/notifier/wire_gen.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/data/redis/redis.go

### Turn 37 (Function)
[tool_response]
1→// Package redis 构造缓存客户端。业务缓存与限流由 S01、S05、S08 完成。
package redis

import (
	"context"
	"database/sql"
	"errors"
	"time"

10→	goredis "github.com/redis/go-redis/v9"

	"notifier/internal/conf"
)

// Open 连接 Redis。错误只包含参数名，不包含密码。
// *sql.DB 参数保证 MySQL 拨号先于 Redis，便于启动失败时定位第一处依赖。
func Open(cfg conf.Redis, _ *sql.DB) (*goredis.Client, func(), error) {
	client := goredis.NewClient(&goredis.Options{
		Addr:         cfg.Addr,
20→		Password:     cfg.Password,
		DB:           cfg.DB,
		DialTimeout:  2 * time.Second,
		ReadTimeout:  2 * time.Second,
		WriteTimeout: 2 * time.Second,
	})
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		_ = client.Close()
30→		return nil, nil, errors.New("redis: REDIS_ADDR: connect failed")
	}
	return client, func() { _ = client.Close() }, nil
}

// Healthy 执行 PING。失败信息不包含地址或密码。
func Healthy(ctx context.Context, client *goredis.Client) error {
	if client == nil {
		return errors.New("redis: REDIS_ADDR: not ready")
	}
40→	if err := client.Ping(ctx).Err(); err != nil {
		return errors.New("redis: REDIS_ADDR: not ready")
	}
	return nil
}


### Turn 38 (Function)
[tool_response]
1→# S05 供应商执行边界

| 项目 | 内容 |
| --- | --- |
| 版本 / 状态 | v0.2 / 待实施 |
| 依据 | [技术方案](../TECH_DESIGN.md)第 6、7、10、11 节 |
| 依赖 | [S00](00-shared-contracts.md)；读取 S01 固定目标语义 |
| 使用方 | S01 发布校验、S03 执行、S06 恢复、S07 重投检查 |
| 建议代码 | `internal/biz/biz_provider` 经 `internal/data_interface` 编排；协议与凭证实现在 `internal/data/provider`，缓存与限流实现在 `internal/data/redis` |
10→
## 1. 目标与范围

把固定任务业务载荷与当前有效发送上下文转换为一次受控供应商调用，并输出标准结果。模块解释供应商协议、凭证和运行约束，不拥有任务重试调度或任务状态写入权。

首版仅接入明确注册的适配器。异步任务编号可作为供应商接收依据保存；跨供应商通用业务完成轮询、回调验签和流程编排不在首版范围。

## 2. 适配器契约

### PRV-A01：注册与本地校验
20→
适配器以 `(adapter_type, adapter_version)` 注册，同一版本必须保持声明的协议语义。启动时拒绝重复注册；原任务引用的版本缺失时报告阻塞，不能选择最新版本代替。

适配器元数据至少声明：支持操作、载荷校验约束、鉴权类型、请求与响应格式、接收判定规则、幂等能力、供应商等待规则及摘要字段白名单。

### PRV-A02：最小操作边界

| 操作 | 输入 | 输出 / 限制 |
| --- | --- | --- |
| `ValidateTarget` | 固定目标配置、操作及凭证引用元数据 | 发布期静态校验；不发网络请求 |
30→| `ValidatePayload` | 已映射业务载荷及固定语义 | 确定性本地校验；不生成动态业务字段 |
| `BuildRequest` | 固定载荷/语义、稳定业务幂等键、有效凭证、本次上下文 | 结构化 HTTP 请求与允许记录的摘要；不自行发送 |
| `InterpretResponse` | HTTP 状态、受限响应体及传输事实 | S00 标准结果、供应商编号/业务码、等待建议与证据范围 |
| `DescribeReplaySafety` | 固定协议能力及当前时间、历史尝试依据 | 安全重发判断材料；最终状态与计划仍由 S03 决定 |

本次上下文包含 `event_id / delivery_id / attempt_id`、原事件时间、本次发送/签名时间、截止时间和 trace。适配器不获得可以任意推进任务状态的存储接口。

### PRV-A03：统一协议结果

至少返回 `outcome`、`result_certainty`、`retryable`、稳定 `error_code`、脱敏原因、HTTP 状态、业务码、供应商请求/受理编号、等待建议及覆盖哪些未决结果的证据。
40→
- HTTP 200 不自动等于接收；按业务码或协议字段判断。
- 429、5xx 或鉴权错误也不一律等于未接收，按供应商协议判断。
- 网络超时、连接中断或响应读取失败无法证明未接收时返回 `UNCERTAIN`。
- 本地构造失败且能够证明未发出时返回 `LOCAL_FAILURE / NOT_RECEIVED`。
- 协议声明异步任务已受理时可返回 `RECEIVED` 并保存编号；等待其业务完成期间不得重复创建外部任务。

## 3. 固定语义与动态信息

固定语义来自任务或不可变发布：供应商、账号、操作、接口业务版本、映射载荷、业务幂等键及语义相关目标参数。
50→
动态信息来自本次上下文：有效 Token、签名时间、发送时间及协议要求的随机值。不能把上一次完整请求作为重放依据，也不能用本次时间覆盖事件发生时间。

目标地址的语义部分取原配置，当前安全允许范围另行检查。若原地址不再允许，阻塞旧任务，不静默改为新地址或其他供应商账号。

## 4. 凭证生命周期

### PRV-C01：引用与缓存

任务保存逻辑凭证引用与账号归属，事件和 MQ 不保存动态秘密。长期凭证放入受保护存储或秘密配置；普通查询和配置接口只展示引用及脱敏元数据。
60→
Access Token 缓存键至少包含供应商、账号、授权范围和凭证版本，TTL 留出失效余量。轮换或撤销后旧版本缓存不可继续使用。

### PRV-C02：有界获取与刷新

凭证准备在创建业务尝试前执行，使用独立超时和有界获取/刷新预算。获取失败交 S03 保存等待或阻塞，不消耗业务尝试次数。

同账号并发获取尽量合并；涉及 Refresh Token 轮换时必须通过受保护的持久化版本/CAS 或等价持久协调，Redis 锁只做减压。只有刷新结果及新版本持久化确认后才发布到缓存。

刷新提交结果不确定先读取持久化版本；供应商可能已轮换而本地没有新凭证时，不能盲目沿用旧 Refresh Token，进入可见凭证异常处置。未接入 OAuth 的供应商无需预建 OAuth 流程，但接入时必须满足这些条件。
70→
### PRV-C03：业务请求鉴权失败

已经发出的业务请求计为一次尝试。适配器或凭证模块不能在收到 401 后隐式刷新并重发同一尝试；应保存本次结果，再由公共流程安排下一次尝试。

## 5. 当前通道约束与限流

### PRV-L01：当前约束

每次执行核对通道启停、账号归属、调用方权限、目标许可和适配器可用性。当前限制以 MySQL/受保护配置为准，不因运行参数缓存过期而越权发送。
80→
首版通道接口为 `GET /v1/channels`、`GET /v1/channels/{id}`、`POST /v1/channels` 和 `PATCH /v1/channels/{id}`。管理修改携带操作幂等键、原因与期望通道版本，原子保存变更及管理审计；现有迁移需补充版本依据。

禁用与运行限制可更新；既有账号归属和操作语义不能通过修改可变通道重新解释旧任务。新增不同账号/操作时创建适当的新实体并发布新配置。同账号不同操作不能被唯一约束误合并。

### PRV-L02：分布式限流

以通道或供应商实际共享额度范围定义限流 key，使用 Redis 原子令牌桶或等价算法；同账号多个通道共享供应商额度时不能各自获得完整额度。

不满足限流返回最早可再检查时间，由 S03 保存等待计划。限流通过后任务 CAS 失败允许浪费本次额度，不能因此绕过下一次限流或产生额外业务请求。
90→
Redis 限流不可用时暂停相关新投递，保存有界等待，不退化为无限放行。配置缓存故障可回源；凭证缓存故障按协议获取；不同用途分别降级。

## 6. 受控 HTTP 传输

### PRV-H01：请求约束

- 只接收注册适配器生成且通过当前目标许可检查的请求；业务方不能直接传任意 URL。
- URL scheme、主机、端口及解析后的目标地址受部署策略约束，禁止访问未授权的本地、私有或元数据地址；本地模拟供应商仅在测试环境显式许可。
- 检查覆盖实际连接目标，防止只校验字符串而连接到未授权地址；代理也必须显式配置并受同一策略控制。
100→- 正常供应商接入校验 TLS，不跳过证书验证；关闭自动重定向。
- HTTP 客户端、传输层和适配器均不得隐式重复业务请求；实现时验证底层连接重试行为满足一次尝试一次调用契约。
- 请求构造、连接、TLS、响应头、响应读取和总执行均受有界上下文及大小限制。

### PRV-H02：响应与摘要

响应读取另设字节上限，与 2 KiB 摘要上限分别配置。超限即停止读取、关闭响应并记录实际已读字节数和协议错误；不能为记录追踪无限读取。

请求/响应/错误摘要按供应商白名单提取，默认各最多 2 KiB，UTF-8 安全截断并标记。认证 Header、Token、签名、Refresh Token 和无关个人信息不能进入持久化摘要或日志。

110→未收到响应时状态码和响应摘要为空；收到响应头后读取失败仍保留状态码。响应不完整且不能证明接收或拒绝时维持不确定，不将读取失败简单归类为永久拒绝。

## 7. 幂等能力与重发窗口

每个协议声明：是否支持幂等、键所在字段、参数一致性要求、去重窗口、窗口起算依据、重复调用返回语义，以及不确定结果的允许处置。

S03/S06/S07 必须能用这些声明和历史时间判断当前是否安全；窗口起算无法确定时保守判断，不以最近一次尝试重新延长窗口。本地记录保留 30 天不代表供应商去重 30 天。

业务幂等键沿用 `delivery_id` 对应的稳定值，自动重试和新轮次不更换。参数必须保持一致；若协议把动态签名字段排除在业务参数一致性之外，适配器显式表达该约定。

120→## 8. 通道与协议参数

| 字段 | 类型 / 必填 | 首版规则 |
| --- | --- | --- |
| `channel_id / row_version` | ID / 整数，服务端返回 | 创建后 ID 不变，row_version 初始 1，每次实际变更加 1 |
| `provider_id / provider_account_id / operation` | S00 标识，必填 | 账号和业务操作归属不可编辑；新归属新建通道 |
| `adapter_type / adapter_version` | S00 标识，必填 | 创建时必须注册；变更协议需新通道及新发布，不重解释旧任务 |
| `credential_ref` | 1～191 字节 UTF-8，必填 | 逻辑引用，不含秘密；绑定相同 provider/account，不允许 PATCH 换至其他逻辑引用 |
| `enabled` | 布尔 | 创建默认 false，完成目标许可/凭证/额度配置后显式启用 |
| `access_constraints.allowed_callers` | 调用方 ID 数组，必填 | 非空，最多 100 项；不支持全局通配符 |
130→| `access_constraints.allowed_origins` | `{scheme, host, port}` 数组 | 非空；主机规范成 ASCII 域名，精确匹配，不允许用户信息及 URL fragment |
| `access_constraints.allowed_cidrs` | CIDR 数组 | 与 origin 同时满足；生产默认拒绝本地/私有/链路本地及元数据地址，测试例外须显式列出 |
| `runtime_policy.quota_key` | 1～128 位 ASCII 标识，必填 | 供应商账号实际共享额度的逻辑键；同额度必须同 key |
| `runtime_policy.rate_per_second / burst` | 正整数，必填 | 1～10000 / 1～10000；无额度配置的通道不能启用 |
| `runtime_policy.rate_policy_version` | 正整数，服务端分配 | 同 quota_key 的通道必须使用相同额度参数和策略版本 |
| `semantic_config.base_url / path` | URL / 路径，必填 | 原地址冻结在发布；path 以 `/` 开头且不含认证查询参数 |
| `semantic_config.auth_type` | `bearer / hmac_sha256 / none` | 由适配器版本声明支持；none 仅测试通道许可 |
| `semantic_config.idempotency` | 对象，必填 | `{mode:"key"或"none", window_seconds, starts_at:"first_possible_send"}`；key 模式有效期 1～604800 秒 |

幂等声明是所接协议经验证的能力，不能由业务调用方自由填写。S01 必须调用该版本适配器元数据校验声明；声明超出实现支持范围则发布失败。窗口起点取全部未决尝试可能首次发送的最早时间；崩溃无法还原时保守取对应 `started_at`。安全条件为当前时间加本次请求最大预算严格小于窗口终点，禁止在刚好过期边界发出新请求。
140→
## 9. 通道管理接口和凭证契约

| 接口 | 参数 | 成功 / 错误 |
| --- | --- | --- |
| `POST /v1/channels` | 操作键、原因、第 8 节创建字段 | 201 `{operation_id, channel}`；同 provider/account/operation/adapter_type 重复为 409 `channel_conflict` |
| `PATCH /v1/channels/{id}` | 操作键、原因、expected_row_version；enabled/access_constraints/runtime_policy 至少一项 | 200 `{operation_id, channel}`；禁止 JSON Merge Patch 的隐式 null 删除，未知/不可变字段 400 |
| `GET /v1/channels/{id}` | 路径 ID | 200 脱敏通道、row_version、凭证状态及更新时间，无 Token |
| `GET /v1/channels` | provider_id、provider_account_id、enabled、page_size、cursor | S08 同类稳定游标，按 channel_id 倒序；管理权限限定范围 |

150→通道管理操作使用全局 caller_scope `__global__`，类型 `channel_create / channel_update`，要求 `channels:manage` 及受影响调用方范围；幂等先于新操作 CAS。禁用时不逐个改写所有任务，由 S03 当前检查和 S06 阻塞恢复处理。共享 quota_key 的额度变更必须在一个管理事务中更新全部关联通道并递增各自版本；受影响通道超过 100 个则拒绝变更并要求拆分额度组，不能让同一 key 并存两个策略。

凭证端口 `ResolveCredential(ref, provider_account_id, scopes)` 返回短期 `CredentialHandle{version, expires_at, account, opaque_handle}`，只由 `data/provider` 解引用为秘密。业务用例只判断账号/有效时间，不接收原始 Token。逻辑 ref 不变的密钥轮换更新凭证版本并保持相同账号归属；撤销后立即拒绝旧版本获取，不等待缓存 TTL。

Access Token key 为 `notifier:token:v1:<provider>:<account>:<scope_sha256>:<credential_version>`，缓存有效期 `expires_at - now - skew`，非正数则不可用。获取返回的 Token 剩余寿命必须覆盖 HTTP_TIMEOUT + 失效余量。获取失败分 `TEMPORARY`（保存 WAIT）、`REVOKED / ACCOUNT_MISMATCH`（BLOCK）和无法安全轮换（BLOCK 并告警）。凭证获取/刷新失败不能制造业务尝试。

需要 Refresh Token 的接入在受保护存储中维护 `{credential_ref, account, version, state, refresh_owner, refresh_deadline}`。先以持久 CAS 进入 REFRESHING，调用供应商后持久化新版本和 Token，再置 ACTIVE 并写缓存。刷新窗口中进程崩溃或响应丢失时，依协议判断能否重取；无法证明旧 Refresh Token 仍有效时置 REAUTH_REQUIRED，禁止第二个实例盲目刷新。短期 Redis 锁只减少等待，不承担上述状态机正确性。

## 10. 限流、执行返回值和运行参数

160→令牌桶 key 为 `notifier:quota:v1:<quota_key>`，状态含 `tokens / last_refill_ms / policy_version`，用 Redis 服务器时间和单次原子脚本计算。`tokens = min(burst, tokens + elapsed_ms × rate_per_second / 1000)`；至少 1 才扣 1，否则返回凑足一个令牌的最早时间。实现使用有界定点数，不让时钟回退产生额度；策略版本不匹配先从 MySQL确认新策略再原子重建桶，不增加旧版本容量。空闲 TTL 为 `max(60秒, 2 × burst/rate)`。同一 quota_key 不能把重建操作当成每次请求的额外 burst。

| 输出结构 | 必需字段 | 调用规则 |
| --- | --- | --- |
| `PrepareResult` | `READY / WAIT / BLOCK / UNSAFE`、reason_code | WAIT 必含 not_before；BLOCK 必含稳定阻塞原因；UNSAFE 交 S03 UNKNOWN |
| READY 附件 | credential_handle、channel_row_version、credential_version、safety_basis、safe_until、证据覆盖、manual_authorization_operation_id | 均与原任务账号匹配；真正发出前重查有效性 |
| `PreparedRequest` | method、经过校验的地址、body bytes、脱敏摘要、request_size_bytes | 不存整包；原 body 用后释放，不能作为重试依据 |
| `TransportFacts` | 是否进入 HTTP、状态/时间/已读字节、读取完整性、传输错误 | 连接错误不凭错误文本猜测“对方未收到” |
| `ProtocolResult` | S00 outcome/certainty、retryable、错误、provider_code/request_id、wait_until、evidence_scope | 不含下一任务状态，不执行自动重试 |

170→safety_basis 为 `NOT_NEEDED / PROVIDER_IDEMPOTENCY / MANUAL_FIRST_ATTEMPT`。没有未决结果时为 NOT_NEEDED；供应商幂等依据必须返回 safe_until。人工风险重投由 S03 传入已校验的本轮未使用操作授权，PrepareDelivery 可据此返回 MANUAL_FIRST_ATTEMPT，不把供应商不支持幂等单独判为 UNSAFE；safe_until 此时为空，operation_id 必填，StartAttempt 再原子核验并消耗授权。只有两类依据都不成立且存在未决结果时才返回 UNSAFE。S06 过期恢复不能传入已被原尝试消耗的授权。

| 参数 | 默认 | 范围 / 关系 |
| --- | --- | --- |
| `PROVIDER_CREDENTIAL_TIMEOUT` | 5 秒 | 100 毫秒～10 秒；整个准备阶段最多一次获取及一次协议允许的刷新 |
| `PROVIDER_TOKEN_EXPIRY_SKEW` | 30 秒 | 5～300 秒；短期 Token 不足覆盖请求则 WAIT |
| `PROVIDER_DIAL_TIMEOUT / PROVIDER_TLS_TIMEOUT / PROVIDER_HEADER_TIMEOUT` | 2 / 3 / 5 秒 | 各不少于 100 毫秒且不超过 HTTP 总预算 |
| `PROVIDER_MAX_RESPONSE_BYTES` | 1 MiB | 4 KiB～8 MiB；最多读取上限加 1 字节来判超限 |
| `PROVIDER_MAX_REQUEST_BYTES` | 256 KiB | 1 KiB～1 MiB；构造超限为 NOT_SENT 本地失败 |
| `PROVIDER_MAX_IDLE_CONNECTIONS` | 100 | 1～1000；每主机上限不超过执行并行数 |
180→| `PROVIDER_IDLE_TIMEOUT` | 90 秒 | 10～300 秒 |

### Turn 39 (Function)
[tool_response]
1→package conf

import (
	"fmt"
	"time"
)

const (
	httpRequestMin  = time.Second
10→	httpRequestMax  = 30 * time.Second
	mysqlOpMin      = 100 * time.Millisecond
	mysqlOpMax      = 5 * time.Second
	httpShutdownMin = 5 * time.Second
	httpShutdownMax = 120 * time.Second
	headerBytesMin  = 1 * 1024
	headerBytesMax  = 64 * 1024
	summaryBytesMin = 256
	summaryBytesMax = 8192
)
20→
// validate 检查 S00 第 9 节的取值边界，以及第 7 节的时间关系。
//
// HTTP 截止必须早于领取到期，结果事务余量按 MYSQL_OPERATION_TIMEOUT 计：
// DELIVERY_HTTP_TIMEOUT + MYSQL_OPERATION_TIMEOUT < DELIVERY_LEASE_TIMEOUT。
// MQ 不可见期限覆盖这一次本地处理预算：
// DELIVERY_MQ_INVISIBLE >= DELIVERY_LEASE_TIMEOUT + MYSQL_OPERATION_TIMEOUT。
// S03 的构造超时、结果预留、ACK 和凭证准备预算尚未进入本配置，届时再收紧。
func validate(c *GlobalConfig) error {
	if err := durationBetween("HTTP_REQUEST_TIMEOUT", c.HTTP.RequestTimeout, httpRequestMin, httpRequestMax); err != nil {
30→		return err
	}
	if err := durationBetween("MYSQL_OPERATION_TIMEOUT", c.MySQL.OperationTimeout, mysqlOpMin, mysqlOpMax); err != nil {
		return err
	}
	if err := durationBetween("HTTP_SHUTDOWN_TIMEOUT", c.HTTP.ShutdownTimeout, httpShutdownMin, httpShutdownMax); err != nil {
		return err
	}
	if c.HTTP.MaxHeaderBytes < headerBytesMin || c.HTTP.MaxHeaderBytes > headerBytesMax {
		return fmt.Errorf("conf: HTTP_MAX_HEADER_BYTES out of range")
40→	}
	if c.Limits.SummaryBytes < summaryBytesMin || c.Limits.SummaryBytes > summaryBytesMax {
		return fmt.Errorf("conf: SUMMARY_MAX_BYTES out of range")
	}
	if c.Delivery.HTTPTimeout <= 0 {
		return fmt.Errorf("conf: DELIVERY_HTTP_TIMEOUT out of range")
	}
	if c.Delivery.LeaseTimeout <= 0 {
		return fmt.Errorf("conf: DELIVERY_LEASE_TIMEOUT out of range")
	}
50→	if c.Delivery.MQInvisible <= 0 {
		return fmt.Errorf("conf: DELIVERY_MQ_INVISIBLE out of range")
	}
	if c.Delivery.HTTPTimeout+c.MySQL.OperationTimeout >= c.Delivery.LeaseTimeout {
		return fmt.Errorf("conf: DELIVERY_HTTP_TIMEOUT + MYSQL_OPERATION_TIMEOUT must be < DELIVERY_LEASE_TIMEOUT")
	}
	if c.Delivery.MQInvisible < c.Delivery.LeaseTimeout+c.MySQL.OperationTimeout {
		return fmt.Errorf("conf: DELIVERY_MQ_INVISIBLE must be >= DELIVERY_LEASE_TIMEOUT + MYSQL_OPERATION_TIMEOUT")
	}
	return nil
60→}

func durationBetween(name string, value, min, max time.Duration) error {
	if value < min || value > max {
		return fmt.Errorf("conf: %s out of range", name)
	}
	return nil
}


### Turn 40 (Function)
[tool_response]
1→// Code generated by Wire. DO NOT EDIT.

//go:generate go run -mod=mod github.com/google/wire/cmd/wire
//go:build !wireinject
// +build !wireinject

package main

import (
10→	"context"
	"notifier/internal/conf"
	"notifier/internal/data/mysql"
	"notifier/internal/data/redis"
	"notifier/internal/data/rocketmq"
	"notifier/internal/server"
	"notifier/internal/service"
)

// Injectors from wire.go:
20→
// initializeApp 组装启动配置、身份、基础设施和 HTTP 入口。
// 身份文件先于数据库拨号；连接失败时清理函数由 Wire 逆序调用。
func initializeApp(ctx context.Context) (*application, func(), error) {
	globalConfig, err := conf.Load(ctx)
	if err != nil {
		return nil, nil, err
	}
	http := globalConfig.HTTP
	log := globalConfig.Log
30→	mySQL := globalConfig.MySQL
	auth := globalConfig.Auth
	set, err := loadIdentities(auth)
	if err != nil {
		return nil, nil, err
	}
	db, cleanup, err := mysql.Open(mySQL, set)
	if err != nil {
		return nil, nil, err
	}
40→	confRedis := globalConfig.Redis
	client, cleanup2, err := redis.Open(confRedis, db)
	if err != nil {
		cleanup()
		return nil, nil, err
	}
	rocketMQ := globalConfig.RocketMQ
	rocketmqClient, cleanup3, err := rocketmq.Open(rocketMQ, db)
	if err != nil {
		cleanup2()
50→		cleanup()
		return nil, nil, err
	}
	readiness := newReadiness(db, client, rocketmqClient, set, mySQL)
	healthService := service.NewHealthService(readiness)
	httpServer := server.NewHTTPServer(http, healthService)
	group := emptyRoles()
	mainApplication := newApplication(http, log, httpServer, group)
	return mainApplication, func() {
		cleanup3()
60→		cleanup2()
		cleanup()
	}, nil
}


### Turn 41 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 38 matching lines
/Users/kiteeater/jobwork/ai-coding-test/TECH_DESIGN.md
61:        P[Outbox 发布器]
73:    A -->|选择已发布配置快照| R
74:    O -->|发布路由与映射版本| R
76:    P -->|领取待发布记录| D
90:首版同一代码库、同一进程运行 API、发布器、消费者与扫描器，模块分别管理生命周期。路由扇出由应用建立独立任务，不依赖 MQ 的订阅关系隐式决定业务接收方。
104:| Outbox 消息标识 | 某任务、轮次、调度版本的一条投递指令 | 发布重试与补发保持稳定 |
125:首版根据调用方、事件类型与受限条件匹配已发布的路由。条件仅支持明确列出的字段相等、集合匹配和字段存在判断等简单操作，缺失字段与类型不匹配有确定规则。
141:服务选定一个已发布且不可变的路由快照，完成全部匹配与映射校验，再用一个 MySQL 事务保存：
168:### 6.2 配置发布与保留
170:路由、映射和语义相关的通道配置作为一份配置发布快照管理。发布前校验事件数据版本、目标、映射、适配器及凭证引用的有效性，发布后内容不可变，以新版本替代修改。
172:首次受理读取当前发布版本并记录引用。这里冻结的是实际受理所用版本，不根据调用方提供的历史发生时间自动回溯选择配置；按事件发生时刻重放历史规则属于另行定义的能力。
192:### 8.1 可靠发布
194:事件、全部投递任务与首次 Outbox 消息在同一个 MySQL 事务中保存。发布器通过短事务领取待发消息，提交后调用 MQ，收到发送成功结果后再标记已发布。确认不确定时，按原消息标识退避重发。
196:发布领取具有期限与领取标识，使用 MySQL 条件更新及 `FOR UPDATE SKIP LOCKED` 协调。网络调用不占用数据库锁，迟到发布结果不能覆盖新领取者。[MySQL 锁定读说明](https://dev.mysql.com/doc/refman/8.4/en/innodb-locking-reads.html)
198:本版采用 Outbox，不同时维护另一套事务消息发布协议。MySQL 持久性依赖正常日志同步、持久卷及备份；MQ 的持久性和故障切换保证依赖实际部署。[MySQL 日志同步说明](https://dev.mysql.com/doc/refman/8.4/en/replication-options-binary-log.html#sysvar_sync_binlog)
214:| 发布重试 | 发送失败、MQ 不可用或确认丢失 | Outbox 退避重发 | 发布次数，不消耗业务尝试预算 |
216:| 供应商投递重试 | 协议允许重试的拒绝或不确定结果 | MySQL 持久化下一次计划，由 Outbox 发布延迟指令 | 消耗该任务本轮预算 |
250:任务保存本轮次数 `round_attempt_count`、累计次数 `total_attempt_count` 和本轮上限 `max_attempts`；人工重投新增轮次，只重置本轮次数。MQ 消费次数、Outbox 发布次数分别记录。等待另有本轮截止时间 `round_deadline_at`，限流或凭证一直不可用也不能无限等待；到期且没有未决请求时记录 `FAILED`，结果仍不确定时记录 `UNKNOWN`。到期不会强行撤销有效的在途请求，应先完成或恢复该次尝试再结案。
262:| 事件提交成功，尚未发布 | 首次 Outbox 保留，恢复后继续发布每个任务 |
263:| Broker 已接收但发布确认丢失 | 重复发布原指令，按任务与调度版本去重 |
281:1. 对尚未执行的到期任务，先检查是否已有有效领取者及当前 Outbox。缺失时创建当前版本指令；已有记录则恢复发布或在宽限期后重发原指令，不为同一调度版本另造消息标识。
302:| 已发布的不可变路由与映射 | 以配置版本为 Key 缓存；受理从 MySQL 确认当前发布版本 | 按所需版本回源，不退回最新或其他版本 |
316:| `business_events` | 调用方、来源业务、来源事件标识、事件类型及数据版本、发生/受理时间、业务对象类型与 ID、数据快照、指纹和路由发布版本 |
318:| `outbox_messages` | 稳定消息标识、任务、轮次、调度版本、消息类型、计划时间、发布状态、发布次数、下次发布时间、领取信息、最近发布错误与补发记录 |
321:| `routing_releases` | 不可变发布快照，包含路由规则、映射及语义相关配置；另维护当前发布指针 |
323:| `management_events` | 配置发布、人工重投、结果核对及死信处理的操作标识、幂等键、请求指纹、期望版本、操作者、原因、时间、关联对象与处理结果 |
348:时间线至少覆盖受理建任务、创建调度、Outbox 发布成功或失败、领取开始、尝试结束、安排重试、等待或阻塞、领取超时、补发修复、死信处置、人工重投及核对结案。状态变化与时间线同事务提交；Outbox 发布结果与对应时间线同事务提交。MQ ACK 的调用结果记录在结构化日志中，不能将本地 ACK 日志视为 Broker 已确认的可靠证明，重投时仍以数据库处置为准。
372:| 运维配置接口 | 校验、发布和查询路由及映射快照，管理通道 |
381:例如，按订单 ID 查询到某 CRM 通知处于 `RETRY_WAIT`，详情可见第 1 轮已尝试 2 次、累计 2 次、下次执行时间及最近 `HTTP_TIMEOUT`；展开后能分别看到两次请求的耗时、供应商响应或无响应原因，再沿时间线定位发布、领取、退避和补偿记录。若此后未再次发送便因等待期限耗尽进入 `UNKNOWN`，授权人工重投后的第 2 轮从本轮 0 次开始，累计仍为 2 次，之前的发送证据完整保留。
398:    biz_config/             # 配置发布、路由及映射用例
401:    biz_outbox/             # 可靠发布编排
446:- `server` 创建 HTTP / gRPC 服务、注册路由与中间件，不解析业务字段或编写业务规则。MQ 消费、发布器和扫描器入口也只负责生命周期、并发及调用用例，不自己推进任务状态。
459:`GlobalConfig` 是构造时注入的只读配置快照，不是包级可变单例。Wire 按字段向组件注入所需配置，例如 HTTP 服务只接收 `conf.HTTP`，不获得数据库凭证。业务路由、映射和轮次策略仍按已发布版本管理，不从启动配置替换；供应商运行凭证通过受保护的引用读取和刷新，不把所有账号凭证加载到全局配置。
479:| 路由或映射发布新版本后重试 | 原接收方、固定映射结果和版本不变 |
498:Compose 包含具备 Proxy 接入端点的 RocketMQ 环境、MySQL、Redis、应用与模拟供应商。迁移、配置发布和 Topic 初始化显式执行，数据库及 Broker 使用持久卷。故障测试保留事件与任务记录，不能靠清空数据代替恢复。
504:运行概览与告警至少覆盖待发布 Outbox 的数量及最老年龄、到期未执行任务、领取过期、各状态数量、`BLOCKED / UNKNOWN` 持续时间、DLQ 数量、补偿失败、投递成功率及耗时分布。告警阈值可配置，详情可关联到具体任务；指标标签只使用来源业务、供应商、状态及错误分类等低基数字段，事件 ID、任务 ID 和业务对象 ID 留在查询与日志中。
506:API 受理能力以 MySQL 和分发计划构建链路为准。MQ 停机时可在积压保护阈值内接收，超限明确拒绝；运维分别观察事件受理、计划建立、消息发布和供应商投递进展。
508:下一步评审聚焦事件数据约定、路由与映射配置格式、状态及错误分类、追踪字段与恢复事务、发布和版本保留规则，以及供应商适配器的最小接口。技术栈及运行方式沿用当前组合。
</workspace_result>

### Turn 42 (Assistant)
[tool_request: grep]
- pattern: duplicate|重复
- glob: internal/canonicaljson/*.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/canonicaljson/canonicaljson.go
- offset: 200
- limit: 400
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/cmd/notifier/main.go
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/unit_test/server/http_test.go
- limit: 120
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/tests/integration/harness_test.go
- limit: 150

### Turn 43 (Function)
[tool_response]
1→//go:build integration

package integration_test

import (
	"context"
	"database/sql"
	"fmt"
	"os"
10→	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

func repoRoot(t *testing.T) string {
20→	t.Helper()
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		t.Fatal("cannot locate integration tests")
	}
	return filepath.Clean(filepath.Join(filepath.Dir(file), "..", ".."))
}

func mysqlEnv(key, def string) string {
	if v := os.Getenv(key); v != "" {
30→		return v
	}
	return def
}

func adminDB(t *testing.T) *sql.DB {
	t.Helper()
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%s)/?parseTime=true&charset=utf8mb4&multiStatements=true",
		mysqlEnv("MYSQL_USER", "root"),
		mysqlEnv("MYSQL_PASSWORD", "root"),
40→		mysqlEnv("MYSQL_HOST", "127.0.0.1"),
		mysqlEnv("MYSQL_PORT", "3306"),
	)
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = db.Close() })
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
50→	if err := db.PingContext(ctx); err != nil {
		t.Fatalf("mysql: MYSQL_HOST: connect failed: %v", err)
	}
	return db
}

func dbNamed(t *testing.T, name string) *sql.DB {
	t.Helper()
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?parseTime=true&charset=utf8mb4&multiStatements=true",
		mysqlEnv("MYSQL_USER", "root"),
60→		mysqlEnv("MYSQL_PASSWORD", "root"),
		mysqlEnv("MYSQL_HOST", "127.0.0.1"),
		mysqlEnv("MYSQL_PORT", "3306"),
		name,
	)
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = db.Close() })
70→	return db
}

func gooseDSN(name string) string {
	return fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?parseTime=true&charset=utf8mb4",
		mysqlEnv("MYSQL_USER", "root"),
		mysqlEnv("MYSQL_PASSWORD", "root"),
		mysqlEnv("MYSQL_HOST", "127.0.0.1"),
		mysqlEnv("MYSQL_PORT", "3306"),
		name,
80→	)
}

func redact(s string) string {
	return strings.ReplaceAll(s, mysqlEnv("MYSQL_PASSWORD", "root"), "[REDACTED]")
}


### Turn 44 (Function)
[tool_response]
1→// 通知服务入口：负责依赖组装与进程生命周期。
//
// 依赖图声明在 wire.go，wire_gen.go 由 make wire 生成。
package main

import (
	"context"
	"database/sql"
	"errors"
10→	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	goredis "github.com/redis/go-redis/v9"

	"notifier/internal/auth"
	"notifier/internal/conf"
20→	"notifier/internal/data/redis"
	"notifier/internal/data/rocketmq"
	"notifier/internal/logredact"
	"notifier/internal/server"
	"notifier/internal/service"
)

func main() {
	if err := run(); err != nil {
		slog.Error("notifier exited", "error", err)
30→		os.Exit(1)
	}
}

func run() error {
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	app, cleanup, err := initializeApp(ctx)
	if cleanup != nil {
		defer cleanup()
40→	}
	if err != nil {
		return err
	}
	slog.SetDefault(app.log)
	return app.run(ctx)
}

type application struct {
	app *server.App
50→	log *slog.Logger
}

func newApplication(httpCfg conf.HTTP, logCfg conf.Log, srv *http.Server, roles *server.Group) *application {
	logger := logredact.New(logCfg)
	return &application{
		log: logger,
		app: &server.App{
			HTTP:            srv,
			Roles:           roles,
60→			ShutdownTimeout: httpCfg.ShutdownTimeout,
			Log:             logger,
		},
	}
}

func (a *application) run(ctx context.Context) error { return a.app.Run(ctx) }

func loadIdentities(cfg conf.Auth) (*auth.Set, error) {
	return auth.LoadFile(cfg.ConfigRef)
70→}

func emptyRoles() *server.Group { return server.NewGroup() }

// newReadiness 检查 MySQL、Redis、RocketMQ 和可用身份。探针响应不回传这里的错误文本。
func newReadiness(db *sql.DB, rdb *goredis.Client, mq *rocketmq.Client, ids *auth.Set, cfg conf.MySQL) service.Readiness {
	return func() error {
		ctx, cancel := context.WithTimeout(context.Background(), cfg.OperationTimeout)
		defer cancel()
		if err := db.PingContext(ctx); err != nil {
80→			return errors.New("mysql: MYSQL_DSN: not ready")
		}
		if err := redis.Healthy(ctx, rdb); err != nil {
			return err
		}
		if err := mq.Healthy(ctx); err != nil {
			return err
		}
		if ids == nil || !ids.Available() {
			return errors.New("auth: AUTH_CONFIG_REF: no usable identity")
90→		}
		return nil
	}
}


### Turn 45 (Function)
[tool_response]
1→package server_test

import (
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
10→
	"notifier/internal/conf"
	"notifier/internal/server"
	"notifier/internal/service"
)

func TestHTTPRoutes(t *testing.T) {
	for _, tc := range []struct {
		method string
		path   string
20→		status int
		body   string
	}{
		{http.MethodGet, "/healthz", http.StatusOK, "ok"},
		{http.MethodGet, "/readyz", http.StatusOK, "ready"},
		{http.MethodPost, "/v1/events", http.StatusNotImplemented, "not_implemented"},
		{http.MethodPost, "/healthz", http.StatusMethodNotAllowed, ""},
		{http.MethodGet, "/missing", http.StatusNotFound, ""},
	} {
		t.Run(tc.method+" "+tc.path, func(t *testing.T) {
30→			srv := server.NewHTTPServer(conf.Default().HTTP, service.NewHealthService(nil))
			response := httptest.NewRecorder()
			request := httptest.NewRequest(tc.method, tc.path, nil)
			if tc.method == http.MethodPost {
				request.Header.Set("Content-Type", "application/json")
			}
			srv.Handler.ServeHTTP(response, request)
			if response.Code != tc.status {
				t.Fatalf("status = %d, want %d", response.Code, tc.status)
			}
40→			if tc.body != "" {
				if response.Header().Get("Content-Type") != "application/json; charset=utf-8" {
					t.Fatal("protocol response must declare JSON")
				}
				var body struct {
					Status string `json:"status"`
					Error  struct {
						Code string `json:"code"`
					} `json:"error"`
				}
50→				if err := json.Unmarshal(response.Body.Bytes(), &body); err != nil {
					t.Fatal(err)
				}
				if tc.status == http.StatusNotImplemented {
					if body.Error.Code != tc.body {
						t.Fatalf("error code = %q, want %q", body.Error.Code, tc.body)
					}
				} else if body.Status != tc.body {
					t.Fatalf("status body = %q, want %q", body.Status, tc.body)
				}
60→			}
		})
	}
}

func TestReadinessFailureDoesNotExposeDependencyErrors(t *testing.T) {
	health := service.NewHealthService(func() error { return errors.New("mysql: secret-password") })
	srv := server.NewHTTPServer(conf.Default().HTTP, health)
	response := httptest.NewRecorder()
	srv.Handler.ServeHTTP(response, httptest.NewRequest(http.MethodGet, "/readyz", nil))
70→	if response.Code != http.StatusServiceUnavailable || strings.Contains(response.Body.String(), "secret-password") {
		t.Fatalf("unexpected readiness failure response: %s", response.Body.String())
	}
	response = httptest.NewRecorder()
	srv.Handler.ServeHTTP(response, httptest.NewRequest(http.MethodGet, "/healthz", nil))
	if response.Code != http.StatusOK {
		t.Fatal("dependency failure must not fail process liveness")
	}
}


### Turn 46 (Function)
[tool_response]
200→	return append(dst, '"')
}

type parser struct {
	b []byte
	i int
}

func (p *parser) skipWS() {
	for p.i < len(p.b) {
210→		switch p.b[p.i] {
		case ' ', '\n', '\r', '\t':
			p.i++
		default:
			return
		}
	}
}

func (p *parser) parseObject(depth int) (Value, error) {
220→	if depth > maxDepth {
		return Value{}, errAt("max depth", p.i)
	}
	p.i++ // '{'
	p.skipWS()
	fields := make([]Field, 0)
	seen := make(map[string]struct{})
	if p.i < len(p.b) && p.b[p.i] == '}' {
		p.i++
		return Value{kind: KindObject, obj: fields}, nil
230→	}
	for {
		p.skipWS()
		if p.i >= len(p.b) || p.b[p.i] != '"' {
			return Value{}, errAt("expected object key", p.i)
		}
		key, err := p.parseString()
		if err != nil {
			return Value{}, err
		}
240→		if _, ok := seen[key]; ok {
			return Value{}, errAt("duplicate key", p.i)
		}
		seen[key] = struct{}{}
		p.skipWS()
		if p.i >= len(p.b) || p.b[p.i] != ':' {
			return Value{}, errAt("expected colon", p.i)
		}
		p.i++
		val, err := p.parseValue(depth)
250→		if err != nil {
			return Value{}, err
		}
		fields = append(fields, Field{Key: key, Value: val})
		p.skipWS()
		if p.i >= len(p.b) {
			return Value{}, errAt("unexpected end", p.i)
		}
		switch p.b[p.i] {
		case ',':
260→			p.i++
			continue
		case '}':
			p.i++
			return Value{kind: KindObject, obj: fields}, nil
		default:
			return Value{}, errAt("expected comma or object end", p.i)
		}
	}
}
270→
func (p *parser) parseArray(depth int) (Value, error) {
	if depth > maxDepth {
		return Value{}, errAt("max depth", p.i)
	}
	p.i++ // '['
	p.skipWS()
	items := make([]Value, 0)
	if p.i < len(p.b) && p.b[p.i] == ']' {
		p.i++
280→		return Value{kind: KindArray, arr: items}, nil
	}
	for {
		val, err := p.parseValue(depth)
		if err != nil {
			return Value{}, err
		}
		items = append(items, val)
		p.skipWS()
		if p.i >= len(p.b) {
290→			return Value{}, errAt("unexpected end", p.i)
		}
		switch p.b[p.i] {
		case ',':
			p.i++
			continue
		case ']':
			p.i++
			return Value{kind: KindArray, arr: items}, nil
		default:
300→			return Value{}, errAt("expected comma or array end", p.i)
		}
	}
}

func (p *parser) parseValue(depth int) (Value, error) {
	p.skipWS()
	if p.i >= len(p.b) {
		return Value{}, errAt("unexpected end", p.i)
	}
310→	switch p.b[p.i] {
	case '{':
		return p.parseObject(depth + 1)
	case '[':
		return p.parseArray(depth + 1)
	case '"':
		s, err := p.parseString()
		if err != nil {
			return Value{}, err
		}
320→		return Value{kind: KindString, str: s}, nil
	case 't':
		if err := p.consumeLiteral("true"); err != nil {
			return Value{}, err
		}
		return Value{kind: KindBool, b: true}, nil
	case 'f':
		if err := p.consumeLiteral("false"); err != nil {
			return Value{}, err
		}
330→		return Value{kind: KindBool, b: false}, nil
	case 'n':
		if err := p.consumeLiteral("null"); err != nil {
			return Value{}, err
		}
		return Value{kind: KindNull}, nil
	default:
		if p.b[p.i] == '-' || (p.b[p.i] >= '0' && p.b[p.i] <= '9') {
			return p.parseNumber()
		}
340→		return Value{}, errAt("invalid value", p.i)
	}
}

func (p *parser) consumeLiteral(lit string) error {
	if p.i+len(lit) > len(p.b) || string(p.b[p.i:p.i+len(lit)]) != lit {
		return errAt("invalid literal", p.i)
	}
	p.i += len(lit)
	return nil
350→}

func (p *parser) parseString() (string, error) {
	start := p.i
	p.i++ // '"'
	var b strings.Builder
	for p.i < len(p.b) {
		c := p.b[p.i]
		if c == '"' {
			p.i++
360→			return b.String(), nil
		}
		if c == '\\' {
			r, err := p.parseEscape()
			if err != nil {
				return "", err
			}
			b.WriteRune(r)
			continue
		}
370→		if c < 0x20 {
			return "", errAt("raw control character", p.i)
		}
		r, size := utf8.DecodeRune(p.b[p.i:])
		if r == utf8.RuneError && size == 1 {
			return "", errAt("invalid utf-8", p.i)
		}
		b.WriteRune(r)
		p.i += size
	}
380→	return "", errAt("unterminated string", start)
}

func (p *parser) parseEscape() (rune, error) {
	if p.i >= len(p.b) || p.b[p.i] != '\\' {
		return 0, errAt("invalid escape", p.i)
	}
	p.i++
	if p.i >= len(p.b) {
		return 0, errAt("invalid escape", p.i)
390→	}
	switch p.b[p.i] {
	case '"', '\\', '/':
		r := rune(p.b[p.i])
		p.i++
		return r, nil
	case 'b':
		p.i++
		return '\b', nil
	case 'f':
400→		p.i++
		return '\f', nil
	case 'n':
		p.i++
		return '\n', nil
	case 'r':
		p.i++
		return '\r', nil
	case 't':
		p.i++
410→		return '\t', nil
	case 'u':
		p.i++
		r, err := p.parseHex4()
		if err != nil {
			return 0, err
		}
		if r < 0xD800 || r > 0xDFFF {
			return r, nil
		}
420→		if r > 0xDBFF {
			return 0, errAt("lone surrogate", p.i)
		}
		if p.i+1 >= len(p.b) || p.b[p.i] != '\\' || p.b[p.i+1] != 'u' {
			return 0, errAt("lone surrogate", p.i)
		}
		p.i += 2
		lo, err := p.parseHex4()
		if err != nil {
			return 0, err
430→		}
		if lo < 0xDC00 || lo > 0xDFFF {
			return 0, errAt("lone surrogate", p.i)
		}
		return 0x10000 + (r-0xD800)<<10 + (lo - 0xDC00), nil
	default:
		return 0, errAt("invalid escape", p.i)
	}
}

440→func (p *parser) parseHex4() (rune, error) {
	if p.i+4 > len(p.b) {
		return 0, errAt("invalid unicode escape", p.i)
	}
	var r rune
	for n := 0; n < 4; n++ {
		c := p.b[p.i]
		var d rune
		switch {
		case c >= '0' && c <= '9':
450→			d = rune(c - '0')
		case c >= 'a' && c <= 'f':
			d = rune(c-'a') + 10
		case c >= 'A' && c <= 'F':
			d = rune(c-'A') + 10
		default:
			return 0, errAt("invalid unicode escape", p.i)
		}
		r = r<<4 | d
		p.i++
460→	}
	return r, nil
}

func (p *parser) parseNumber() (Value, error) {
	start := p.i
	if p.b[p.i] == '-' {
		p.i++
	}
	if p.i >= len(p.b) || p.b[p.i] < '0' || p.b[p.i] > '9' {
470→		return Value{}, errAt("invalid number", start)
	}
	if p.b[p.i] == '0' {
		p.i++
	} else {
		for p.i < len(p.b) && p.b[p.i] >= '0' && p.b[p.i] <= '9' {
			p.i++
		}
	}
	intEnd := p.i
480→	fracStart := -1
	if p.i < len(p.b) && p.b[p.i] == '.' {
		p.i++
		fracStart = p.i
		if p.i >= len(p.b) || p.b[p.i] < '0' || p.b[p.i] > '9' {
			return Value{}, errAt("invalid number", start)
		}
		for p.i < len(p.b) && p.b[p.i] >= '0' && p.b[p.i] <= '9' {
			p.i++
		}
490→	}
	fracEnd := p.i
	exp := 0
	if p.i < len(p.b) && (p.b[p.i] == 'e' || p.b[p.i] == 'E') {
		p.i++
		sign := 1
		if p.i < len(p.b) && (p.b[p.i] == '+' || p.b[p.i] == '-') {
			if p.b[p.i] == '-' {
				sign = -1
			}
500→			p.i++
		}
		if p.i >= len(p.b) || p.b[p.i] < '0' || p.b[p.i] > '9' {
			return Value{}, errAt("invalid number", start)
		}
		expOverflow := false
		for p.i < len(p.b) && p.b[p.i] >= '0' && p.b[p.i] <= '9' {
			if !expOverflow {
				exp = exp*10 + int(p.b[p.i]-'0')
				if exp > 1_000_000 {
510→					expOverflow = true
				}
			}
			p.i++
		}
		if expOverflow {
			// 系数全零时仍规范成 0；非零数字的指数必然越界。用哨兵留给 canonicalNumber。
			exp = maxExponent + 1
		}
		exp *= sign
520→	}
	if p.i-start > maxNumberLiteral {
		return Value{}, errAt("number literal too long", start)
	}
	// 前导零只允许单独的 0。整数部分在负号之后。
	intStart := start
	neg := p.b[start] == '-'
	if neg {
		intStart++
	}
530→	if intEnd-intStart > 1 && p.b[intStart] == '0' {
		return Value{}, errAt("invalid number", start)
	}
	intDigits := string(p.b[intStart:intEnd])
	fracDigits := ""
	if fracStart >= 0 {
		fracDigits = string(p.b[fracStart:fracEnd])
	}
	num, err := canonicalNumber(neg, intDigits, fracDigits, exp)
	if err != nil {
540→		return Value{}, err
	}
	return Value{kind: KindNumber, num: num}, nil
}

func canonicalNumber(neg bool, intDigits, fracDigits string, exp int) (string, error) {
	coef := strings.TrimLeft(intDigits+fracDigits, "0")
	exp -= len(fracDigits)
	if coef == "" {
		return "0", nil
550→	}
	trimmed := strings.TrimRight(coef, "0")
	exp += len(coef) - len(trimmed)
	coef = trimmed
	if len(coef) > maxCoefficient {
		return "", errAt("coefficient too long", 0)
	}
	if exp < -maxExponent || exp > maxExponent {
		return "", errAt("exponent out of range", 0)
	}
560→	var b strings.Builder
	if neg {
		b.WriteByte('-')
	}
	b.WriteString(coef)
	b.WriteByte('e')
	b.WriteString(strconv.Itoa(exp))
	return b.String(), nil
}


### Turn 47 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 2 matching lines
/Users/kiteeater/jobwork/ai-coding-test/internal/canonicaljson/canonicaljson.go
106:// ParseObject 解析一个完整 JSON 对象。拒绝重复键、尾随数据、非法 UTF-8、
241:			return Value{}, errAt("duplicate key", p.i)
</workspace_result>

### Turn 48 (Assistant)
[tool_request: grep]
- pattern: EVENT_MAX|event size|事件大小|MAX_EVENT|payload
- glob: docs/*.md
- head_limit: 30
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/time.go
- limit: 80
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/Makefile
[tool_request: grep]
- pattern: Field\{|func Null|func String|func Number|func Bool|func Object
- glob: internal/canonicaljson/*.go

### Turn 49 (Function)
[tool_response]
1→package domain

import (
	"fmt"
	"time"
)

// ParseRFC3339 解析带时区的 RFC3339 时间。
// 小数最多 6 位，年份 1000..9999，结果为 UTC。超过微秒精度时拒绝，不截断。
10→func ParseRFC3339(field, value string) (time.Time, error) {
	if err := validateRFC3339Text(value); err != nil {
		return time.Time{}, fmt.Errorf("domain: %s: %w", field, err)
	}
	parsed, err := time.Parse(time.RFC3339Nano, value)
	if err != nil {
		return time.Time{}, fmt.Errorf("domain: %s: invalid time", field)
	}
	year := parsed.UTC().Year()
	if year < 1000 || year > 9999 {
20→		return time.Time{}, fmt.Errorf("domain: %s: invalid time", field)
	}
	return parsed.UTC(), nil
}

func validateRFC3339Text(value string) error {
	dot := -1
	for i := 0; i < len(value); i++ {
		if value[i] == '.' {
			dot = i
30→			break
		}
	}
	if dot < 0 {
		return nil
	}
	frac := 0
	for i := dot + 1; i < len(value); i++ {
		c := value[i]
		if c < '0' || c > '9' {
40→			break
		}
		frac++
	}
	if frac == 0 || frac > 6 {
		return fmt.Errorf("invalid time")
	}
	return nil
}

50→// FormatUTCMicros 写成指纹使用的 UTC 微秒文本，固定 6 位小数。
func FormatUTCMicros(t time.Time) string {
	return t.UTC().Format("2006-01-02T15:04:05.000000Z")
}


### Turn 50 (Function)
[tool_response]
1→# API 通知服务构建与运行入口。
# 依赖：Go 1.26.2、Docker（compose 场景）、Goose（迁移，经 go run 拉取）。

BIN_DIR  := bin
NOTIFIER := $(BIN_DIR)/notifier
MOCK     := $(BIN_DIR)/mockvendor

GO       ?= go
GOOSE    := $(GO) run github.com/pressly/goose/v3/cmd/goose
10→MYSQL_DSN ?= notifier:notifier@tcp(127.0.0.1:3306)/notifier?parseTime=true&charset=utf8mb4

.PHONY: build run mockvendor test vet race fmt tidy deps wire \
        migrate-up migrate-down migrate-status migrate-create \
        topics compose-up compose-down compose-logs clean

build:
	@mkdir -p $(BIN_DIR)
	$(GO) build -trimpath -o $(NOTIFIER) ./cmd/notifier
	$(GO) build -trimpath -o $(MOCK) ./cmd/mockvendor
20→
run: build
	./$(NOTIFIER)

mockvendor: build
	./$(MOCK)

test:
	$(GO) test ./...

30→vet:
	$(GO) vet ./...

race:
	$(GO) test -race ./...

fmt:
	gofmt -w cmd internal unit_test

wire:
40→	$(GO) tool wire ./cmd/notifier

tidy:
	$(GO) mod tidy

# 版本与 compose 镜像的对应关系见 TECH_DESIGN.md 第 2 节。不要改回 @latest。
deps:
	$(GO) get github.com/go-sql-driver/mysql@v1.9.3
	$(GO) get github.com/redis/go-redis/v9@v9.17.2
	$(GO) get github.com/pressly/goose/v3@v3.26.0
50→	$(GO) get github.com/apache/rocketmq-clients/golang/v5@v5.1.4
	$(GO) mod tidy

topics:
	sh scripts/init-topics.sh

migrate-up:
	$(GOOSE) -dir migrations mysql "$(MYSQL_DSN)" up

migrate-down:
60→	$(GOOSE) -dir migrations mysql "$(MYSQL_DSN)" down

migrate-status:
	$(GOOSE) -dir migrations mysql "$(MYSQL_DSN)" status

migrate-create:
	$(GOOSE) -dir migrations mysql "$(MYSQL_DSN)" create $(name) sql

compose-up:
	docker compose up -d --build
70→
compose-down:
	docker compose down

compose-logs:
	docker compose logs -f

clean:
	rm -rf $(BIN_DIR)


### Turn 51 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 1 matching lines
/Users/kiteeater/jobwork/ai-coding-test/internal/canonicaljson/canonicaljson.go
253:		fields = append(fields, Field{Key: key, Value: val})
</workspace_result>

### Turn 52 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 12 matching lines
/Users/kiteeater/jobwork/ai-coding-test/docs/00-shared-contracts.md
133:事件大小、最大扇出、响应读取、查询范围、分页、积压保护等上限采用本契约及各模块参数表的默认值，必须在启动配置中显式定义并校验，不允许无限制运行。
149:| 413 | 请求超过上限：`payload_too_large` |
216:| `delivery_tasks` | `payload_canonical MEDIUMBLOB`；风险授权操作/首次尝试关联 | 精确载荷与一次性授权 |
223:`data_canonical / payload_canonical` 是指纹、映射和请求构造的事实来源；已有 JSON 列可保留为查询投影。规范化字节必须是可解析 JSON，不允许从 MySQL JSON 的浮点投影重建精确原值。配置发布内容同样保存规范化字节及 SHA-256，读取校验后再解释。任务引用发布外键保留实际内容，禁止存储动态凭证。

/Users/kiteeater/jobwork/ai-coding-test/docs/01-configuration-release.spec.md
61:限制配置大小、规则数、条件数、路径长度/深度、映射字段数、事件大小及最终扇出。超限返回可定位错误，不截断目标列表后继续受理。

/Users/kiteeater/jobwork/ai-coding-test/docs/02-event-ingestion.spec.md
115:| 超过请求体上限 | 413 `payload_too_large`，有界读取 |
142:| `EVENT_MAX_BODY_BYTES` | 256 KiB | 1 KiB～1 MiB；包含完整 envelope，读取最多上限加 1 字节 |
143:| `EVENT_MAX_FANOUT` | 50 | 1～200；所有目标完整计算，不截断受理 |
144:| `EVENT_MAX_PLAN_BYTES` | 2 MiB | 256 KiB～8 MiB；固定载荷与语义总编码大小 |
145:| `EVENT_MAX_PENDING_OUTBOX` | 100000 | 100～1000000；尚未完成发布的有效 Outbox 数量 |
146:| `EVENT_MAX_OLDEST_OUTBOX_AGE` | 1 小时 | 1 分钟～24 小时；与数量任一超限即暂停新受理 |

/Users/kiteeater/jobwork/ai-coding-test/docs/08-delivery-tracking.spec.md
153:首版排序固定，禁止 `sort` 等任意排序参数。读取 size+1 条确定 next_cursor；对外仅返回 size 条。cursor payload 包含 `{version:1, key_id, caller_scope_hash, filter_sha256, order, last_sort_values, effective_time_range, issued_at, expires_at}`，对规范化字节做 HMAC-SHA256，再使用 base64url 编码。签名密钥从受保护引用读取，可轮换并在 24 小时内保留旧 key_id；不把秘密写入 GlobalConfig 日志。
</workspace_result>

### Turn 53 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/tests/integration/migrate_test.go
- limit: 120
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/unit_test/conf/bounds_test.go
- limit: 80
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/go.mod
- limit: 40
[tool_request: grep]
- pattern: NewHTTPServer|FieldsOf
- glob: **/*.{go}

### Turn 54 (Function)
[tool_response]
1→package conf_test

import (
	"context"
	"strings"
	"testing"

	"notifier/internal/conf"
)
10→
func TestC08_RelationshipAndBoundsRejectSecrets(t *testing.T) {
	const secret = "supersecret-s00-value"
	cases := []struct {
		name  string
		key   string
		value string
		want  []string
	}{
		{name: "http timeout eats the lease", key: "DELIVERY_HTTP_TIMEOUT", value: "29s", want: []string{"DELIVERY_HTTP_TIMEOUT", "DELIVERY_LEASE_TIMEOUT", "MYSQL_OPERATION_TIMEOUT"}},
20→		{name: "invisible shorter than processing budget", key: "DELIVERY_MQ_INVISIBLE", value: "20s", want: []string{"DELIVERY_MQ_INVISIBLE", "DELIVERY_LEASE_TIMEOUT", "MYSQL_OPERATION_TIMEOUT"}},
		{name: "request timeout too high", key: "HTTP_REQUEST_TIMEOUT", value: "31s", want: []string{"HTTP_REQUEST_TIMEOUT"}},
		{name: "request timeout too low", key: "HTTP_REQUEST_TIMEOUT", value: "999ms", want: []string{"HTTP_REQUEST_TIMEOUT"}},
		{name: "mysql timeout too low", key: "MYSQL_OPERATION_TIMEOUT", value: "50ms", want: []string{"MYSQL_OPERATION_TIMEOUT"}},
		{name: "mysql timeout too high", key: "MYSQL_OPERATION_TIMEOUT", value: "6s", want: []string{"MYSQL_OPERATION_TIMEOUT"}},
		{name: "shutdown too low", key: "HTTP_SHUTDOWN_TIMEOUT", value: "4s", want: []string{"HTTP_SHUTDOWN_TIMEOUT"}},
		{name: "shutdown too high", key: "HTTP_SHUTDOWN_TIMEOUT", value: "121s", want: []string{"HTTP_SHUTDOWN_TIMEOUT"}},
		{name: "header too small", key: "HTTP_MAX_HEADER_BYTES", value: "512", want: []string{"HTTP_MAX_HEADER_BYTES"}},
		{name: "header too large", key: "HTTP_MAX_HEADER_BYTES", value: "65537", want: []string{"HTTP_MAX_HEADER_BYTES"}},
		{name: "summary too small", key: "SUMMARY_MAX_BYTES", value: "255", want: []string{"SUMMARY_MAX_BYTES"}},
30→		{name: "summary too large", key: "SUMMARY_MAX_BYTES", value: "8193", want: []string{"SUMMARY_MAX_BYTES"}},
		{name: "empty dsn", key: "MYSQL_DSN", value: "", want: []string{"MYSQL_DSN"}},
		{name: "empty auth ref", key: "AUTH_CONFIG_REF", value: "", want: []string{"AUTH_CONFIG_REF"}},
		{name: "duration parse hides the raw value", key: "DELIVERY_LEASE_TIMEOUT", value: secret, want: []string{"DELIVERY_LEASE_TIMEOUT"}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			localConfig(t)
			t.Setenv("MYSQL_DSN", "user:"+secret+"@tcp(127.0.0.1:3306)/notifier")
			t.Setenv("REDIS_PASSWORD", secret)
40→			t.Setenv(tc.key, tc.value)
			cfg, err := conf.Load(context.Background())
			if err == nil || cfg != (conf.GlobalConfig{}) {
				t.Fatal("out of range config must fail closed")
			}
			for _, name := range tc.want {
				if !strings.Contains(err.Error(), name) {
					t.Fatalf("error %q does not name %s", err, name)
				}
			}
50→			if strings.Contains(err.Error(), secret) || strings.Contains(err.Error(), tc.value) && tc.value == secret {
				t.Fatalf("error leaked a secret: %v", err)
			}
		})
	}
}

func TestC08_BoundaryValuesLoad(t *testing.T) {
	localConfig(t)
	t.Setenv("HTTP_REQUEST_TIMEOUT", "1s")
60→	t.Setenv("HTTP_REQUEST_TIMEOUT", "30s")
	t.Setenv("MYSQL_OPERATION_TIMEOUT", "100ms")
	t.Setenv("HTTP_SHUTDOWN_TIMEOUT", "5s")
	t.Setenv("HTTP_MAX_HEADER_BYTES", "1024")
	t.Setenv("SUMMARY_MAX_BYTES", "8192")
	t.Setenv("DELIVERY_HTTP_TIMEOUT", "1s")
	t.Setenv("DELIVERY_LEASE_TIMEOUT", "5s")
	t.Setenv("DELIVERY_MQ_INVISIBLE", "5200ms")
	cfg, err := conf.Load(context.Background())
	if err != nil {
70→		t.Fatal(err)
	}
	if cfg.HTTP.RequestTimeout.String() != "30s" || cfg.Limits.SummaryBytes != 8192 {
		t.Fatalf("boundary values were not kept: %+v", cfg.HTTP)
	}
}


### Turn 55 (Function)
[tool_response]
1→//go:build integration

package integration_test

import (
	"context"
	"database/sql"
	"os/exec"
	"strings"
10→	"testing"
	"time"

	"notifier/internal/data/mysql"
)

func TestBatch0_EmptyDatabaseGooseUpDownUp(t *testing.T) {
	const name = "notifier_s00_mig"
	admin := adminDB(t)
	ctx := context.Background()
20→	if _, err := admin.ExecContext(ctx, "DROP DATABASE IF EXISTS "+name); err != nil {
		t.Fatal(err)
	}
	if _, err := admin.ExecContext(ctx, "CREATE DATABASE "+name); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		_, _ = admin.ExecContext(context.Background(), "DROP DATABASE IF EXISTS "+name)
	})

30→	root := repoRoot(t)
	dsn := gooseDSN(name)
	runGoose(t, root, dsn, "up-to", "2")
	db := dbNamed(t, name)
	if err := insertAttempt(ctx, db, "SENT"); err != nil {
		t.Fatal(err)
	}

	runGoose(t, root, dsn, "up")
	var sendState string
40→	if err := db.QueryRowContext(ctx, `SELECT send_state FROM delivery_attempts`).Scan(&sendState); err != nil {
		t.Fatal(err)
	}
	if sendState != "HTTP_INVOKED" {
		t.Fatalf("send_state = %s, want HTTP_INVOKED", sendState)
	}
	assertColumn(t, db, name, "delivery_attempts", "send_state", "varchar", 32)
	assertColumn(t, db, name, "delivery_attempts", "request_summary", "text", 0)
	assertColumn(t, db, name, "delivery_tasks", "status", "varchar", 32)
	assertColumn(t, db, name, "routing_releases", "content_canonical", "mediumblob", 0)
50→	assertColumn(t, db, name, "management_events", "expected_schedule_version", "int", 0)

	summary := strings.Repeat("a", 8192)
	res, err := db.ExecContext(ctx, `
		UPDATE delivery_attempts
		SET request_summary = ?, request_summary_truncated = TRUE
		WHERE attempt_no = 1`, summary)
	if err != nil {
		t.Fatal(err)
	}
60→	if n, _ := res.RowsAffected(); n != 1 {
		t.Fatalf("summary update affected %d", n)
	}
	if _, err := db.ExecContext(ctx, `DELETE FROM delivery_attempts`); err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(ctx, `DELETE FROM delivery_tasks`); err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(ctx, `DELETE FROM business_events`); err != nil {
70→		t.Fatal(err)
	}
	if _, err := db.ExecContext(ctx, `DELETE FROM channels`); err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(ctx, `DELETE FROM routing_releases`); err != nil {
		t.Fatal(err)
	}

	runGoose(t, root, dsn, "down-to", "0")
80→	runGoose(t, root, dsn, "up")

	taskID, err := insertTask(ctx, db)
	if err != nil {
		t.Fatal(err)
	}
	deliveryID := uint64(taskID)
	ex := mysql.NewExecutor(db, 2*time.Second)
	var first, second uint32
	err = ex.RunTx(ctx, func(ctx context.Context, tx *sql.Tx) error {
90→		var seqErr error
		first, seqErr = mysql.NextHistorySeq(ctx, tx, deliveryID)
		return seqErr
	})
	if err != nil || first != 1 {
		t.Fatalf("first history seq = %d %v", first, err)
	}
	err = ex.RunTx(ctx, func(ctx context.Context, tx *sql.Tx) error {
		var seqErr error
		second, seqErr = mysql.NextHistorySeq(ctx, tx, deliveryID)
100→		return seqErr
	})
	if err != nil || second != 2 {
		t.Fatalf("second history seq = %d %v", second, err)
	}
}

func insertAttempt(ctx context.Context, db *sql.DB, sendState string) error {
	taskID, err := insertTask(ctx, db)
	if err != nil {
110→		return err
	}
	_, err = db.ExecContext(ctx, `
		INSERT INTO delivery_attempts (delivery_id, round_no, attempt_no, started_at, send_state)
		VALUES (?, 1, 1, UTC_TIMESTAMP(6), ?)`, taskID, sendState)
	return err
}

func insertTask(ctx context.Context, db *sql.DB) (int64, error) {
	res, err := db.ExecContext(ctx, `INSERT INTO routing_releases (version_no, content) VALUES (1, JSON_OBJECT('k', 'v'))`)
120→	if err != nil {

### Turn 56 (Function)
[tool_response]
1→module notifier

go 1.26.2

require (
	github.com/Azure/azure-sdk-for-go/sdk/azidentity v1.13.1
	github.com/Azure/azure-sdk-for-go/sdk/security/keyvault/azsecrets v1.5.0
	github.com/apache/rocketmq-clients/golang/v5 v5.1.4
	github.com/go-sql-driver/mysql v1.9.3
10→	github.com/google/wire v0.7.0
	github.com/pressly/goose/v3 v3.26.0
	github.com/redis/go-redis/v9 v9.17.2
)

require (
	contrib.go.opencensus.io/exporter/ocagent v0.7.0 // indirect
	filippo.io/edwards25519 v1.1.0 // indirect
	github.com/Azure/azure-sdk-for-go/sdk/azcore v1.21.0 // indirect
	github.com/Azure/azure-sdk-for-go/sdk/internal v1.11.2 // indirect
20→	github.com/Azure/azure-sdk-for-go/sdk/security/keyvault/internal v1.2.0 // indirect
	github.com/AzureAD/microsoft-authentication-library-for-go v1.7.0 // indirect
	github.com/ClickHouse/ch-go v0.67.0 // indirect
	github.com/ClickHouse/clickhouse-go/v2 v2.40.1 // indirect
	github.com/andybalholm/brotli v1.2.0 // indirect
	github.com/antlr4-go/antlr/v4 v4.13.0 // indirect
	github.com/census-instrumentation/opencensus-proto v0.4.1 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/coder/websocket v1.8.12 // indirect
	github.com/dchest/siphash v1.2.3 // indirect
30→	github.com/dgryski/go-rendezvous v0.0.0-20200823014737-9f7001d12a5f // indirect
	github.com/dustin/go-humanize v1.0.1 // indirect
	github.com/elastic/go-sysinfo v1.15.4 // indirect
	github.com/elastic/go-windows v1.0.2 // indirect
	github.com/gabriel-vasile/mimetype v1.4.9 // indirect
	github.com/go-faster/city v1.0.1 // indirect
	github.com/go-faster/errors v0.7.1 // indirect
	github.com/go-playground/locales v0.14.1 // indirect
	github.com/go-playground/universal-translator v0.18.1 // indirect
	github.com/go-playground/validator/v10 v10.26.0 // indirect
40→	github.com/golang-jwt/jwt/v4 v4.5.2 // indirect

### Turn 57 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 9 matching lines
/Users/kiteeater/jobwork/ai-coding-test/internal/server/http.go
11:// NewHTTPServer 只组装 HTTP 传输，不承载协议转换或业务规则。
12:func NewHTTPServer(cfg conf.HTTP, health *service.HealthService) *http.Server {

/Users/kiteeater/jobwork/ai-coding-test/cmd/notifier/wire.go
23:		wire.FieldsOf(new(conf.GlobalConfig), "HTTP", "MySQL", "Redis", "RocketMQ", "Log", "Auth"),
30:		server.NewHTTPServer,

/Users/kiteeater/jobwork/ai-coding-test/unit_test/server/http_test.go
30:			srv := server.NewHTTPServer(conf.Default().HTTP, service.NewHealthService(nil))
67:	srv := server.NewHTTPServer(conf.Default().HTTP, health)

/Users/kiteeater/jobwork/ai-coding-test/unit_test/server/lifecycle_test.go
19:	srv := server.NewHTTPServer(conf.Default().HTTP, service.NewHealthService(nil))
52:	srv := server.NewHTTPServer(cfg, service.NewHealthService(nil))

/Users/kiteeater/jobwork/ai-coding-test/cmd/notifier/wire_gen.go
55:	httpServer := server.NewHTTPServer(http, healthService)
</workspace_result>

### Turn 58 (Assistant)
[tool_request: grep]
- pattern: redis:
- glob: compose.yaml
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/conf/config.go
- offset: 244
- limit: 120
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/unit_test/server/lifecycle_test.go
- limit: 60

### Turn 59 (Function)
[tool_response]
1→package server_test

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
10→	"testing"
	"time"

	"notifier/internal/conf"
	"notifier/internal/server"
	"notifier/internal/service"
)

func TestRequestIDAndUnsupportedMediaType(t *testing.T) {
	srv := server.NewHTTPServer(conf.Default().HTTP, service.NewHealthService(nil))
20→	rec, req := newPost(t, "/v1/events", "")
	srv.Handler.ServeHTTP(rec, req)
	if rec.Code != http.StatusUnsupportedMediaType {
		t.Fatalf("missing content type = %d %s", rec.Code, rec.Body.String())
	}
	if len(rec.Header().Get("X-Request-ID")) != 32 {
		t.Fatalf("generated request id = %q", rec.Header().Get("X-Request-ID"))
	}

	rec, req = newPost(t, "/v1/events", "application/json; charset=utf-8")
30→	req.Header.Set("X-Request-ID", "trace-1")
	srv.Handler.ServeHTTP(rec, req)
	if rec.Code != http.StatusNotImplemented || rec.Header().Get("X-Request-ID") != "trace-1" {
		t.Fatalf("json request = %d id %s", rec.Code, rec.Header().Get("X-Request-ID"))
	}
	if !strings.Contains(rec.Body.String(), `"request_id":"trace-1"`) {
		t.Fatalf("body = %s", rec.Body.String())
	}

	rec, req = newPost(t, "/v1/events", "application/json")
40→	req.Header.Set("X-Request-ID", "bad id")
	srv.Handler.ServeHTTP(rec, req)
	id := rec.Header().Get("X-Request-ID")
	if id == "bad id" || len(id) != 32 {
		t.Fatalf("illegal request id was kept: %q", id)
	}
}

func TestMaxHeaderBytes(t *testing.T) {
	cfg := conf.Default().HTTP
50→	cfg.MaxHeaderBytes = 1024
	cfg.RequestTimeout = time.Second
	srv := server.NewHTTPServer(cfg, service.NewHealthService(nil))
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	go func() { _ = srv.Serve(ln) }()
	defer srv.Close()
60→

### Turn 60 (Function)
[tool_response]
244→func envStr(key, def string) string {
	if v, ok := os.LookupEnv(key); ok && v != "" {
		return v
	}
	return def
}
250→
// envRequired 把显式空字符串当成错误。未设置时仍用默认值。
func envRequired(key, def string) (string, error) {
	v, ok := os.LookupEnv(key)
	if !ok {
		return def, nil
	}
	if v == "" {
		return "", fmt.Errorf("conf: %s must not be empty", key)
	}
260→	return v, nil
}

func envInt(key string, def int) (int, error) {
	v, ok := os.LookupEnv(key)
	if !ok || v == "" {
		return def, nil
	}
	n, err := strconv.Atoi(v)
	if err != nil {
270→		return 0, fmt.Errorf("conf: %s: expected integer", key)
	}
	return n, nil
}

func envDuration(key string, def time.Duration) (time.Duration, error) {
	v, ok := os.LookupEnv(key)
	if !ok || v == "" {
		return def, nil
	}
280→	d, err := time.ParseDuration(v)
	if err != nil {
		return 0, fmt.Errorf("conf: %s: expected duration", key)
	}
	return d, nil
}


### Turn 61 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 4 matching lines
/Users/kiteeater/jobwork/ai-coding-test/compose.yaml
22:  redis:
23:    image: redis:7.4.12-alpine
78:      REDIS_ADDR: "redis:6379"
84:      redis:
</workspace_result>

### Turn 62 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/compose.yaml
- offset: 20
- limit: 30
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/data/mysql/history.go
- limit: 40

### Turn 63 (Function)
[tool_response]
20→      retries: 20

  redis:
    image: redis:7.4.12-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
30→      interval: 5s
      timeout: 3s
      retries: 20

  rocketmq-namesrv:
    image: apache/rocketmq:5.3.1
    command: sh mqnamesrv
    environment:
      JAVA_OPT_EXT: "-Xms256m -Xmx256m"
    ports:
40→      - "9876:9876"

  rocketmq-broker:
    image: apache/rocketmq:5.3.1
    # 命名卷默认属主是 root，镜像用户 rocketmq(3000) 无法写 store/lock。
    user: "0:0"
    command: sh mqbroker -n rocketmq-namesrv:9876 -c /opt/rocketmq/broker.conf
    depends_on:
      - rocketmq-namesrv
    environment:

### Turn 64 (Function)
[tool_response]
1→package mysql

import (
	"context"
	"database/sql"
	"errors"
	"math"
	"slices"
)
10→
// 锁顺序：事件（需要时，由调用方先锁）→ 按 ID 升序的任务 → 尝试/Outbox/历史/操作记录。
// Outbox 单独领取事务不再反向锁任务。history_seq 的递增不要求增加业务 row_version。

// LockTasks 按 delivery_id 升序锁定任务行。调用方需要事件锁时必须先取得事件锁。
func LockTasks(ctx context.Context, tx *sql.Tx, ids []uint64) error {
	ordered := append([]uint64(nil), ids...)
	slices.Sort(ordered)
	for _, id := range ordered {
		var got uint64
20→		err := tx.QueryRowContext(ctx,
			`SELECT delivery_id FROM delivery_tasks WHERE delivery_id = ? FOR UPDATE`, id).Scan(&got)
		if err != nil {
			return err
		}
	}
	return nil
}

// NextHistorySeq 锁定任务行并递增 history_seq。溢出时报错，不回绕。
30→// 具体历史写入由后续事务操作完成。
func NextHistorySeq(ctx context.Context, tx *sql.Tx, deliveryID uint64) (uint32, error) {
	var seq uint32
	err := tx.QueryRowContext(ctx,
		`SELECT history_seq FROM delivery_tasks WHERE delivery_id = ? FOR UPDATE`, deliveryID).Scan(&seq)
	if err != nil {
		return 0, err
	}
	if uint64(seq) == math.MaxUint32 {
		return 0, errors.New("mysql: history_seq overflow")
40→	}

### Turn 65 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/tests/integration/migrate_test.go
- offset: 140
- limit: 80

### Turn 66 (Function)
[tool_response]
140→			business_object_type, business_object_id, data_snapshot, data_canonical, fingerprint, routing_release_id)
		VALUES ('caller', 'src', 'evt-1', 'demo', 'v1', UTC_TIMESTAMP(6), 'order', 'obj-1',
			JSON_OBJECT('n', 1), CAST('{"n":1e0}' AS BINARY), REPEAT('a', 64), ?)`, rel)
	if err != nil {
		return 0, err
	}
	ev, err := res.LastInsertId()
	if err != nil {
		return 0, err
	}
150→	res, err = db.ExecContext(ctx, `
		INSERT INTO delivery_tasks (
			event_id, route_target_id, channel_id, provider_id, provider_account_id, operation,
			adapter_type, mapping_id, fixed_target, round_policy, payload, payload_canonical,
			mapping_version, adapter_version, idempotency_key, max_attempts, round_deadline_at)
		VALUES (?, 'target-1', ?, 'prov', 'acct', 'notify', 'http', 'map-1',
			JSON_OBJECT('op', 'notify'), JSON_OBJECT('max', 1), JSON_OBJECT('n', 1),
			CAST('{"n":1e0}' AS BINARY), 'v1', 'v1', 'idem-1', 3, UTC_TIMESTAMP(6))`, ev, ch)
	if err != nil {
		return 0, err
160→	}
	return res.LastInsertId()
}

func runGoose(t *testing.T, root, dsn string, args ...string) {
	t.Helper()
	cmdArgs := append([]string{"run", "github.com/pressly/goose/v3/cmd/goose", "-dir", root + "/migrations", "mysql", dsn}, args...)
	cmd := exec.Command("go", cmdArgs...)
	cmd.Dir = root
	out, err := cmd.CombinedOutput()
170→	if err != nil {
		t.Fatalf("goose %s: %v\n%s", strings.Join(args, " "), err, redact(string(out)))
	}
}

func assertColumn(t *testing.T, db *sql.DB, schema, table, column, dataType string, minChars int) {
	t.Helper()
	var gotType string
	var chars sql.NullInt64
	err := db.QueryRowContext(context.Background(), `
180→		SELECT DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
		FROM information_schema.COLUMNS
		WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
		schema, table, column).Scan(&gotType, &chars)
	if err != nil {
		t.Fatalf("%s.%s: %v", table, column, err)
	}
	if gotType != dataType {
		t.Fatalf("%s.%s type = %s, want %s", table, column, gotType, dataType)
	}
190→	if minChars > 0 && (!chars.Valid || chars.Int64 < int64(minChars)) {
		t.Fatalf("%s.%s length = %v, want >= %d", table, column, chars, minChars)
	}
}


### Turn 67 (Assistant)
[tool_request: grep]
- pattern: DeliveryPlan\{|TargetPlan\{
- glob: **/*_test.go

### Turn 68 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
No matches found
</workspace_result>

### Turn 69 (Assistant)
S00 的分层和表结构已经对齐。接下来按规格做最小实现：发布校验、指针 CAS、幂等、路由映射和按版本回源。
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/canonicaljson/build.go
- new_string: package canonicaljson

import (
	"strconv"
	"strings"
)

// Parse 解析一个完整 JSON 值。规则与 ParseObject 相同。
func Parse(raw []byte) (Value, error) {
	p := parser{b: raw}
	p.skipWS()
	if p.i >= len(p.b) {
		return Value{}, errAt("unexpected end", p.i)
	}
	// 根对象的深度与 ParseObject 一致：容器本身算第 1 层。
	v, err := p.parseValue(0)
	if err != nil {
		return Value{}, err
	}
	p.skipWS()
	if p.i != len(p.b) {
		return Value{}, errAt("trailing data", p.i)
	}
	return v, nil
}

// Null、Bool、String、Number、Object、Array 构造精确值。
// Object 和 Array 复制切片，调用方之后改原切片不影响值。
func Null() Value { return Value{kind: KindNull} }

func Bool(b bool) Value { return Value{kind: KindBool, b: b} }

func String(s string) Value { return Value{kind: KindString, str: s} }

func Number(canonical string) Value { return Value{kind: KindNumber, num: canonical} }

func Object(fields []Field) Value {
	return Value{kind: KindObject, obj: append([]Field(nil), fields...)}
}

func Array(items []Value) Value {
	return Value{kind: KindArray, arr: append([]Value(nil), items...)}
}

// Uint 把非负整数规范成 JSON 数字。
func Uint(n uint64) (Value, error) {
	return Parse([]byte(strconv.FormatUint(n, 10)))
}

// Member 按键查找对象字段。
func (v Value) Member(key string) (Value, bool) {
	fields, ok := v.Object()
	if !ok {
		return Value{}, false
	}
	for _, field := range fields {
		if field.Key == key {
			return field.Value, true
		}
	}
	return Value{}, false
}

// Equal 用规范化字节比较。数字 1 与 1.0 相等，不同类型不相等。
func Equal(a, b Value) bool {
	if a.kind != b.kind {
		return false
	}
	return string(AppendCanonical(nil, a)) == string(AppendCanonical(nil, b))
}

// IsInteger 判断规范化数字是否为整数。1.0 规范成 1e0，视为整数。
func (v Value) IsInteger() bool {
	if v.kind != KindNumber {
		return false
	}
	if v.num == "0" {
		return true
	}
	s := v.num
	if s[0] == '-' {
		s = s[1:]
	}
	e := strings.IndexByte(s, 'e')
	if e <= 0 {
		return false
	}
	exp, err := strconv.Atoi(s[e+1:])
	return err == nil && exp >= 0
}

// Int64 读取整数。非整数或超出 int64 时返回 false。
func (v Value) Int64() (int64, bool) {
	if !v.IsInteger() {
		return 0, false
	}
	if v.num == "0" {
		return 0, true
	}
	neg := v.num[0] == '-'
	s := v.num
	if neg {
		s = s[1:]
	}
	e := strings.IndexByte(s, 'e')
	exp, err := strconv.Atoi(s[e+1:])
	if err != nil || exp < 0 {
		return 0, false
	}
	coef := s[:e]
	if len(coef)+exp > 18 {
		return 0, false
	}
	var n int64
	for _, c := range coef {
		if c < '0' || c > '9' {
			return 0, false
		}
		n = n*10 + int64(c-'0')
	}
	for i := 0; i < exp; i++ {
		if n > (1<<63-1)/10 {
			return 0, false
		}
		n *= 10
	}
	if neg {
		n = -n
	}
	return n, true
}

- old_string: 
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/migrations/00004_config_release.sql
- new_string: -- +goose Up
-- S01 发布指针与凭证引用版本。不改 00001–00003。
-- routing_current 预置 singleton=1，release_id 允许 NULL，首次发布与后续发布锁同一行。
-- credential_refs 只保存逻辑引用、账号归属和版本，不含秘密。完整凭证存储与刷新由 S05 完成。

ALTER TABLE routing_current
    MODIFY COLUMN release_id BIGINT UNSIGNED NULL
        COMMENT '当前发布；未发布时为 NULL';

INSERT INTO routing_current (singleton, release_id, updated_at)
VALUES (1, NULL, UTC_TIMESTAMP(6))
ON DUPLICATE KEY UPDATE singleton = singleton;

ALTER TABLE routing_releases
    ADD COLUMN reference_snapshot JSON NULL
        COMMENT '草稿创建时冻结的通道与凭证引用版本，发布事务内复核' AFTER fingerprint_version;

CREATE TABLE credential_refs (
    credential_ref      VARCHAR(191)    NOT NULL,
    provider_id         VARCHAR(64)     NOT NULL,
    provider_account_id VARCHAR(64)     NOT NULL,
    version             INT UNSIGNED    NOT NULL,
    updated_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (credential_ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_bin
  COMMENT='逻辑凭证引用版本。不含秘密。完整凭证存储由 S05 完成';

-- +goose Down
DROP TABLE IF EXISTS credential_refs;

ALTER TABLE routing_releases
    DROP COLUMN reference_snapshot;

DELETE FROM routing_current WHERE release_id IS NULL;

ALTER TABLE routing_current
    MODIFY COLUMN release_id BIGINT UNSIGNED NOT NULL;

- old_string: 
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/constant/constant.go
- old_string: 	// Summary 字节上限的配置边界。截断按 UTF-8 字节进行，并另存截断标记。
	SummaryBytesMin = 256
	SummaryBytesMax = 8192
)
- new_string: 	// Summary 字节上限的配置边界。截断按 UTF-8 字节进行，并另存截断标记。
	SummaryBytesMin = 256
	SummaryBytesMax = 8192

	// GlobalCallerScope 是配置发布等全局管理操作的调用方范围。
	GlobalCallerScope = "__global__"

	// 配置发布操作类型。与 S07 的管理操作共用 management_events。
	OpConfigCreate  = "config_create"
	OpConfigPublish = "config_publish"
)

// 领域错误码。HTTP 映射在 service。未知码不得当成成功。
const (
	CodeInvalidRequest            = "invalid_request"
	CodeForbidden                 = "forbidden"
	CodeNotFound                  = "not_found"
	CodeIdempotencyConflict       = "idempotency_conflict"
	CodeVersionConflict           = "version_conflict"
	CodeStateConflict             = "state_conflict"
	CodeConfigInvalid             = "config_invalid"
	CodeConfigurationChanged      = "configuration_changed"
	CodeConfigurationUnavailable  = "configuration_unavailable"
	CodeUnsupportedSchema         = "unsupported_schema"
	CodeNoMatchingRoute           = "no_matching_route"
	CodeMappingInvalid            = "mapping_invalid"
	CodePlanTimeout               = "plan_timeout"
	CodeLimitExceeded             = "limit_exceeded"
	CodeDependencyUnavailable     = "dependency_unavailable"
	CodeInternal                  = "internal"
)

### Turn 70 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/migrations/00004_config_release.sql has been created successfully.

### Turn 71 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/canonicaljson/build.go has been created successfully.

### Turn 72 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/constant/constant.go has been updated successfully.

### Turn 73 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/constant/constant.go
- offset: 40

### Turn 74 (Function)
[tool_response]
40→const (
	// FingerprintVersion 是首版规范化算法版本。升级算法时递增，不能静默替换已保存的版本。
	FingerprintVersion = 1

	// JSON 结构上限。深度包含 envelope；数字按原始字面量字节计。
	MaxJSONDepth           = 32
	MaxJSONNumberLiteral   = 128
	MaxJSONCoefficientBits = 64 // 十进制系数位数，不是二进制位宽
	MaxJSONExponent        = 308

50→	// MaxErrorDetails 是 422 明细条数上限。明细不含字段原始值。
	MaxErrorDetails = 100

	// MaxCallerScopes 是单个身份可声明的调用方范围上限。
	MaxCallerScopes = 100

	// Summary 字节上限的配置边界。截断按 UTF-8 字节进行，并另存截断标记。
	SummaryBytesMin = 256
	SummaryBytesMax = 8192

60→	// GlobalCallerScope 是配置发布等全局管理操作的调用方范围。
	GlobalCallerScope = "__global__"

	// 配置发布操作类型。与 S07 的管理操作共用 management_events。
	OpConfigCreate  = "config_create"
	OpConfigPublish = "config_publish"
)

// 领域错误码。HTTP 映射在 service。未知码不得当成成功。
const (
70→	CodeInvalidRequest            = "invalid_request"
	CodeForbidden                 = "forbidden"
	CodeNotFound                  = "not_found"
	CodeIdempotencyConflict       = "idempotency_conflict"
	CodeVersionConflict           = "version_conflict"
	CodeStateConflict             = "state_conflict"
	CodeConfigInvalid             = "config_invalid"
	CodeConfigurationChanged      = "configuration_changed"
	CodeConfigurationUnavailable  = "configuration_unavailable"
	CodeUnsupportedSchema         = "unsupported_schema"
80→	CodeNoMatchingRoute           = "no_matching_route"
	CodeMappingInvalid            = "mapping_invalid"
	CodePlanTimeout               = "plan_timeout"
	CodeLimitExceeded             = "limit_exceeded"
	CodeDependencyUnavailable     = "dependency_unavailable"
	CodeInternal                  = "internal"
)


### Turn 75 (Assistant)
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/types.go
- old_string: // DeliveryPlan 是一次发布计算出的固定计划。轮次策略 JSON 的结构由 S01 定义。
type DeliveryPlan struct {
	ReleaseRef  string
	Targets     []TargetPlan
	RoundPolicy []byte
}
- new_string: // DeliveryPlan 是一次发布计算出的固定计划。轮次策略 JSON 的结构由 S01 定义。
// VersionNo 是服务器分配的发布序号；FormatVersion 是内容里的 format_version。
type DeliveryPlan struct {
	ReleaseRef    string
	VersionNo     uint32
	FormatVersion int
	Targets       []TargetPlan
	RoundPolicy   []byte
}
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/pointer.go
- new_string: package domain

import "strings"

const (
	maxPointerSegments   = 16
	maxShapeDepth        = 16
	maxEnumItems         = 100
	maxInItems           = 100
	maxStringRunesCap    = 65536
	defaultStringRunes   = 4096
	maxArrayItemsCap     = 1000
	defaultArrayItems    = 100
	maxCollectedIssues   = 1000
	maxEventFieldCount   = 10000
)

// DecodePointer 解析配置里的 JSON Pointer。
// 禁止空根路径、数字数组索引、非法转义，并受路径字节数和段数限制。
func DecodePointer(path string, maxBytes int) ([]string, error) {
	if path == "" || len(path) > maxBytes || path[0] != '/' {
		return nil, errPointer
	}
	parts := strings.Split(path[1:], "/")
	if len(parts) == 0 || len(parts) > maxPointerSegments {
		return nil, errPointer
	}
	out := make([]string, len(parts))
	for i, part := range parts {
		seg, err := unescapePointer(part)
		if err != nil || seg == "" || isArrayIndex(seg) {
			return nil, errPointer
		}
		out[i] = seg
	}
	return out, nil
}

var errPointer = errString("invalid pointer")

type errString string

func (e errString) Error() string { return string(e) }

func unescapePointer(seg string) (string, error) {
	var b strings.Builder
	for i := 0; i < len(seg); i++ {
		if seg[i] != '~' {
			b.WriteByte(seg[i])
			continue
		}
		if i+1 >= len(seg) {
			return "", errPointer
		}
		switch seg[i+1] {
		case '0':
			b.WriteByte('~')
		case '1':
			b.WriteByte('/')
		default:
			return "", errPointer
		}
		i++
	}
	return b.String(), nil
}

func isArrayIndex(s string) bool {
	if s == "-" || s == "0" {
		return true
	}
	if s[0] < '1' || s[0] > '9' {
		return false
	}
	for i := 1; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			return false
		}
	}
	return true
}

func pointerToken(s string) string {
	s = strings.ReplaceAll(s, "~", "~0")
	return strings.ReplaceAll(s, "/", "~1")
}

func joinPath(path, key string) string {
	return path + "/" + pointerToken(key)
}

- old_string: 
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/bounds.go
- new_string: package domain

import "time"

// Bounds 是 S01 第 8 节的发布与计划计算上限。启动配置注入，计算时不再读取环境变量。
type Bounds struct {
	MaxBytes         int
	MaxRoutes        int
	MaxTargets       int
	MaxConditions    int
	MaxMappingFields int
	MaxPathBytes     int
	MaxEventBytes    int
	MaxFanout        int
	MaxPayloadBytes  int
	ServerWaitCap    time.Duration
}

// DefaultBounds 返回规格中的默认上限。
func DefaultBounds() Bounds {
	return Bounds{
		MaxBytes:         1 << 20,
		MaxRoutes:        500,
		MaxTargets:       500,
		MaxConditions:    20,
		MaxMappingFields: 200,
		MaxPathBytes:     256,
		MaxEventBytes:    256 << 10,
		MaxFanout:        50,
		MaxPayloadBytes:  256 << 10,
		ServerWaitCap:    time.Hour,
	}
}

- old_string: 

### Turn 76 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/bounds.go has been created successfully.

### Turn 77 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/pointer.go has been created successfully.

### Turn 78 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/types.go has been updated successfully.

### Turn 79 (Assistant)
发布内容的静态规则放在 domain，接下来补上校验、路由和映射。
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- new_string: package domain

import (
	"slices"
	"strings"

	"notifier/internal/canonicaljson"
	"notifier/internal/constant"
)

// Issue 是配置静态校验的一条错误。消息不含字段原始值。
type Issue struct {
	Code          string
	FieldPath     string
	RouteTargetID string
	Message       string
}

// ContentResult 是静态校验结果。存在 Issues 时 Doc 为空，不进入发布。
type ContentResult struct {
	Doc       *ReleaseDocument
	Callers   []string
	Issues    []Issue
	Truncated bool
}

// TargetBinding 是发布事务要复核的目标归属。语义正文是规范化字节。
type TargetBinding struct {
	RouteTargetID     string
	ChannelID         uint64
	ProviderID        string
	ProviderAccountID string
	Operation         string
	AdapterType       string
	AdapterVersion    string
	CredentialRef     string
	MappingID         string
	MappingVersion    string
	Semantic          []byte
}

// ReleaseDocument 是一份通过静态校验的发布内容。字段顺序不影响后续计算。
type ReleaseDocument struct {
	FormatVersion   int
	Canonical       []byte
	SHA256          string
	PolicyCanonical []byte
	callers         []string
	bindings        []TargetBinding
	schemas         []schemaDef
	routes          []routeDef
	targets         map[string]targetDef
	mappings        map[string]mappingDef
}

// CallerIDs 返回路由中出现的调用方，供发布权限核对。
func (d *ReleaseDocument) CallerIDs() []string {
	if d == nil {
		return nil
	}
	return append([]string(nil), d.callers...)
}

// Bindings 返回目标归属，顺序按 route_target_id 固定。
func (d *ReleaseDocument) Bindings() []TargetBinding {
	if d == nil {
		return nil
	}
	return append([]TargetBinding(nil), d.bindings...)
}

type collector struct {
	items    []Issue
	overflow bool
}

func (c *collector) add(code, path, target, msg string) {
	if len(c.items) >= maxCollectedIssues {
		c.overflow = true
		return
	}
	c.items = append(c.items, Issue{Code: code, FieldPath: path, RouteTargetID: target, Message: msg})
}

func (c *collector) result() ([]Issue, bool) {
	slices.SortFunc(c.items, func(a, b Issue) int {
		if n := strings.Compare(a.FieldPath, b.FieldPath); n != 0 {
			return n
		}
		if n := strings.Compare(a.RouteTargetID, b.RouteTargetID); n != 0 {
			return n
		}
		if n := strings.Compare(a.Code, b.Code); n != 0 {
			return n
		}
		return strings.Compare(a.Message, b.Message)
	})
	truncated := c.overflow || len(c.items) > constant.MaxErrorDetails
	if len(c.items) > constant.MaxErrorDetails {
		c.items = append([]Issue(nil), c.items[:constant.MaxErrorDetails]...)
	}
	return c.items, truncated
}

type bag struct {
	m    map[string]canonicaljson.Value
	path string
	c    *collector
}

func newBag(v canonicaljson.Value, path string, c *collector) (bag, bool) {
	fields, ok := v.Object()
	if !ok {
		c.add("type_mismatch", loc(path), "", "必须是对象")
		return bag{}, false
	}
	m := make(map[string]canonicaljson.Value, len(fields))
	for _, field := range fields {
		m[field.Key] = field.Value
	}
	return bag{m: m, path: path, c: c}, true
}

func (b bag) allow(keys ...string) {
	allow := make(map[string]struct{}, len(keys))
	for _, key := range keys {
		allow[key] = struct{}{}
	}
	for key := range b.m {
		if _, ok := allow[key]; ok {
			continue
		}
		code := "unknown_field"
		if alt, bad := forbiddenKey(key); bad {
			code = alt
		}
		b.c.add(code, joinPath(b.path, key), "", "不支持的字段")
	}
}

func forbiddenKey(key string) (string, bool) {
	switch key {
	case "script", "function", "pattern", "eval":
		return "script_forbidden", true
	case "$ref", "$schema", "allOf", "anyOf", "oneOf", "not":
		return "unsupported_keyword", true
	default:
		return "", false
	}
}

func (b bag) want(key string) (canonicaljson.Value, bool) {
	v, ok := b.m[key]
	if !ok {
		b.c.add("missing_field", joinPath(b.path, key), "", "缺少字段")
		return canonicaljson.Value{}, false
	}
	return v, true
}

func (b bag) text(key string, required bool) (string, bool) {
	v, ok := b.m[key]
	if !ok {
		if required {
			b.c.add("missing_field", joinPath(b.path, key), "", "缺少字段")
		}
		return "", false
	}
	s, ok := v.Text()
	if !ok {
		b.c.add("type_mismatch", joinPath(b.path, key), "", "必须是字符串")
		return "", false
	}
	return s, true
}

func (b bag) boolean(key string, def bool) bool {
	v, ok := b.m[key]
	if !ok {
		return def
	}
	flag, ok := v.Bool()
	if !ok {
		b.c.add("type_mismatch", joinPath(b.path, key), "", "必须是布尔值")
		return def
	}
	return flag
}

func (b bag) integer(key string) (int64, bool) {
	v, ok := b.want(key)
	if !ok {
		return 0, false
	}
	n, ok := v.Int64()
	if !ok {
		b.c.add("type_mismatch", joinPath(b.path, key), "", "必须是整数")
		return 0, false
	}
	return n, true
}

func loc(path string) string {
	if path == "" {
		return "/"
	}
	return path
}

// ValidateContent 做本地静态校验，不访问通道、凭证或网络。
// JSON 语法错误通过 error 返回；内容不合法放在 Issues，调用方据此拒绝发布。
func ValidateContent(raw []byte, bounds Bounds) (ContentResult, error) {
	if len(raw) > bounds.MaxBytes {
		return ContentResult{Issues: []Issue{{
			Code: constant.CodeLimitExceeded, FieldPath: "/", Message: "配置超过大小上限",
		}}}, nil
	}
	value, err := canonicaljson.ParseObject(raw)
	if err != nil {
		return ContentResult{}, err
	}
	canon := canonicaljson.AppendCanonical(nil, value)
	if len(canon) > bounds.MaxBytes {
		return ContentResult{Issues: []Issue{{
			Code: constant.CodeLimitExceeded, FieldPath: "/", Message: "配置超过大小上限",
		}}}, nil
	}
	c := &collector{}
	doc := parseDocument(value, bounds, c)
	issues, truncated := c.result()
	if len(issues) > 0 {
		return ContentResult{Callers: doc.callers, Issues: issues, Truncated: truncated}, nil
	}
	doc.Canonical = canon
	doc.SHA256 = canonicaljson.Fingerprint(canon)
	return ContentResult{Doc: doc, Callers: append([]string(nil), doc.callers...)}, nil
}

// ReadFormatVersion 只读取已保存内容的格式版本，不用当前默认值补齐缺项。
func ReadFormatVersion(raw []byte) (int, error) {
	value, err := canonicaljson.ParseObject(raw)
	if err != nil {
		return 0, err
	}
	field, ok := value.Member("format_version")
	if !ok {
		return 0, errPointer
	}
	n, ok := field.Int64()
	if !ok || n != 1 {
		return 0, errPointer
	}
	return int(n), nil
}

func parseDocument(root canonicaljson.Value, bounds Bounds, c *collector) *ReleaseDocument {
	doc := &ReleaseDocument{targets: map[string]targetDef{}, mappings: map[string]mappingDef{}}
	b, ok := newBag(root, "", c)
	if !ok {
		return doc
	}
	b.allow("format_version", "event_schemas", "routes", "targets", "mappings", "policy")
	if v, ok := b.want("format_version"); ok {
		n, ok := v.Int64()
		if !ok || n != 1 {
			c.add("unsupported_version", "/format_version", "", "格式版本必须为 1")
		} else {
			doc.FormatVersion = 1
		}
	}
	if v, ok := b.want("event_schemas"); ok {
		doc.schemas = parseSchemas(v, c)
	}
	if v, ok := b.want("routes"); ok {
		doc.routes = parseRoutes(v, bounds, doc, c)
	}
	if v, ok := b.want("targets"); ok {
		parseTargets(v, bounds, doc, c)
	}
	if v, ok := b.want("mappings"); ok {
		parseMappings(v, bounds, doc, c)
	}
	if v, ok := b.want("policy"); ok {
		doc.PolicyCanonical = parsePolicy(v, bounds, c)
	}
	link(doc, bounds, c)
	return doc
}

type schemaDef struct {
	EventType     string
	SchemaVersion string
	Shape         shapeDef
}

type shapeDef struct {
	Type       string
	Nullable   bool
	Properties map[string]shapeDef
	Required   []string
	Additional bool
	Items      *shapeDef
	MaxItems   int
	MaxLength  int
	Enum       []canonicaljson.Value
}

func parseSchemas(v canonicaljson.Value, c *collector) []schemaDef {
	items, ok := v.Array()
	if !ok || len(items) == 0 {
		c.add("missing_field", "/event_schemas", "", "至少要有一个事件 schema")
		return nil
	}
	seen := map[string]struct{}{}
	out := make([]schemaDef, 0, len(items))
	for i, item := range items {
		path := joinPath("/event_schemas", itoa(i))
		b, ok := newBag(item, path, c)
		if !ok {
			continue
		}
		b.allow("event_type", "schema_version", "shape")
		eventType, eOK := b.text("event_type", true)
		version, vOK := b.text("schema_version", true)
		if eOK && !validIdent(c, joinPath(path, "event_type"), eventType, maxASCIIIdent128) {
			eOK = false
		}
		if vOK && !validIdent(c, joinPath(path, "schema_version"), version, maxASCIIIdent32) {
			vOK = false
		}
		shapeV, sOK := b.want("shape")
		var shape shapeDef
		if sOK {
			shape = parseShape(shapeV, joinPath(path, "shape"), 1, c)
		}
		if eOK && vOK {
			key := eventType + "\x00" + version
			if _, dup := seen[key]; dup {
				c.add("duplicate", path, "", "事件类型与版本重复")
			} else {
				seen[key] = struct{}{}
				out = append(out, schemaDef{EventType: eventType, SchemaVersion: version, Shape: shape})
			}
		}
	}
	return out
}

func parseShape(v canonicaljson.Value, path string, depth int, c *collector) shapeDef {
	if depth > maxShapeDepth {
		c.add(constant.CodeLimitExceeded, path, "", "schema 层级超过上限")
		return shapeDef{}
	}
	b, ok := newBag(v, path, c)
	if !ok {
		return shapeDef{}
	}
	typ, ok := b.text("type", true)
	if !ok {
		return shapeDef{}
	}
	sh := shapeDef{Type: typ, Nullable: false}
	switch typ {
	case "object":
		b.allow("type", "properties", "required", "additional_properties", "nullable")
		sh.Nullable = b.boolean("nullable", false)
		sh.Additional = b.boolean("additional_properties", false)
		props, ok := b.want("properties")
		sh.Properties = map[string]shapeDef{}
		if ok {
			pb, ok := newBag(props, joinPath(path, "properties"), c)
			if ok {
				for key, child := range pb.m {
					if !validIdent(c, joinPath(joinPath(path, "properties"), key), key, maxASCIIIdent128) {
						continue
					}
					sh.Properties[key] = parseShape(child, joinPath(joinPath(path, "properties"), key), depth+1, c)
				}
			}
		}
		if req, ok := b.m["required"]; ok {
			sh.Required = parseRequired(req, sh.Properties, joinPath(path, "required"), c)
		}
	case "array":
		b.allow("type", "items", "max_items", "nullable")
		sh.Nullable = b.boolean("nullable", false)
		items, ok := b.want("items")
		if ok {
			child := parseShape(items, joinPath(path, "items"), depth+1, c)
			sh.Items = &child
		}
		sh.MaxItems = defaultArrayItems
		if raw, ok := b.m["max_items"]; ok {
			n, ok := raw.Int64()
			if !ok || n < 0 || n > maxArrayItemsCap {
				c.add(constant.CodeLimitExceeded, joinPath(path, "max_items"), "", "max_items 超出上限")
			} else {
				sh.MaxItems = int(n)
			}
		}
	case "string", "number", "integer", "boolean", "null":
		b.allow("type", "enum", "max_length", "nullable")
		if typ != "string" {
			if _, ok := b.m["max_length"]; ok {
				c.add("unknown_field", joinPath(path, "max_length"), "", "不支持的字段")
			}
		}
		sh.Nullable = b.boolean("nullable", false)
		if typ == "string" {
			sh.MaxLength = defaultStringRunes
			if raw, ok := b.m["max_length"]; ok {
				n, ok := raw.Int64()
				if !ok || n < 0 || n > maxStringRunesCap {
					c.add(constant.CodeLimitExceeded, joinPath(path, "max_length"), "", "max_length 超出上限")
				} else {
					sh.MaxLength = int(n)
				}
			}
		}
		if raw, ok := b.m["enum"]; ok {
			sh.Enum = parseEnum(raw, typ, joinPath(path, "enum"), c)
		}
	default:
		c.add("unsupported_keyword", joinPath(path, "type"), "", "不支持的 schema 类型")
	}
	return sh
}

func parseRequired(v canonicaljson.Value, props map[string]shapeDef, path string, c *collector) []string {
	items, ok := v.Array()
	if !ok {
		c.add("type_mismatch", path, "", "required 必须是字符串数组")
		return nil
	}
	seen := map[string]struct{}{}
	out := make([]string, 0, len(items))
	for i, item := range items {
		text, ok := item.Text()
		if !ok {
			c.add("type_mismatch", joinPath(path, itoa(i)), "", "required 必须是字符串")
			continue
		}
		if _, ok := props[text]; !ok {
			c.add("missing_field", joinPath(path, itoa(i)), "", "required 字段不在 properties 中")
			continue
		}
		if _, dup := seen[text]; dup {
			c.add("duplicate", joinPath(path, itoa(i)), "", "required 重复")
			continue
		}
		seen[text] = struct{}{}
		out = append(out, text)
	}
	return out
}

func parseEnum(v canonicaljson.Value, typ, path string, c *collector) []canonicaljson.Value {
	items, ok := v.Array()
	if !ok {
		c.add("type_mismatch", path, "", "enum 必须是数组")
		return nil
	}
	if len(items) == 0 || len(items) > maxEnumItems {
		c.add(constant.CodeLimitExceeded, path, "", "enum 数量超出上限")
		return nil
	}
	out := make([]canonicaljson.Value, 0, len(items))
	for i, item := range items {
		if !valueMatchesType(item, typ) {
			c.add("type_mismatch", joinPath(path, itoa(i)), "", "enum 成员类型不一致")
			continue
		}
		dup := false
		for _, prev := range out {
			if canonicaljson.Equal(prev, item) {
				dup = true
				break
			}
		}
		if dup {
			c.add("duplicate", joinPath(path, itoa(i)), "", "enum 成员重复")
			continue
		}
		out = append(out, item)
	}
	return out
}

func valueMatchesType(v canonicaljson.Value, typ string) bool {
	switch typ {
	case "string":
		_, ok := v.Text()
		return ok
	case "number":
		return v.Kind() == canonicaljson.KindNumber
	case "integer":
		return v.IsInteger()
	case "boolean":
		_, ok := v.Bool()
		return ok
	case "null":
		return v.Kind() == canonicaljson.KindNull
	case "object":
		return v.Kind() == canonicaljson.KindObject
	case "array":
		return v.Kind() == canonicaljson.KindArray
	default:
		return false
	}
}

type routeDef struct {
	ID             string
	CallerID       string
	SourceBusiness string
	EventType      string
	SchemaVersion  string
	Conditions     []conditionDef
	Targets        []string
}

type conditionDef struct {
	Segments []string
	Op       string
	Value    canonicaljson.Value
	In       []canonicaljson.Value
}

func parseRoutes(v canonicaljson.Value, bounds Bounds, doc *ReleaseDocument, c *collector) []routeDef {
	items, ok := v.Array()
	if !ok {
		c.add("type_mismatch", "/routes", "", "routes 必须是数组")
		return nil
	}
	if len(items) > bounds.MaxRoutes {
		c.add(constant.CodeLimitExceeded, "/routes", "", "路由数量超过上限")
	}
	limit := len(items)
	if limit > bounds.MaxRoutes {
		limit = bounds.MaxRoutes
	}
	seen := map[string]struct{}{}
	out := make([]routeDef, 0, limit)
	for i := 0; i < limit; i++ {
		path := joinPath("/routes", itoa(i))
		b, ok := newBag(items[i], path, c)
		if !ok {
			continue
		}
		b.allow("route_id", "caller_id", "source_business", "event_type", "schema_version", "conditions", "targets")
		route := routeDef{}
		if id, ok := b.text("route_id", true); ok && validIdent(c, joinPath(path, "route_id"), id, maxASCIIIdent128) {
			if _, dup := seen[id]; dup {
				c.add("duplicate", joinPath(path, "route_id"), "", "route_id 重复")
			} else {
				seen[id] = struct{}{}
				route.ID = id
			}
		}
		if caller, ok := b.text("caller_id", true); ok && validIdent(c, joinPath(path, "caller_id"), caller, maxASCIIIdent64) {
			route.CallerID = caller
			doc.callers = append(doc.callers, caller)
		}
		if src, ok := b.text("source_business", true); ok && validIdent(c, joinPath(path, "source_business"), src, maxASCIIIdent64) {
			route.SourceBusiness = src
		}
		if eventType, ok := b.text("event_type", true); ok && validIdent(c, joinPath(path, "event_type"), eventType, maxASCIIIdent128) {
			route.EventType = eventType
		}
		if version, ok := b.text("schema_version", true); ok && validIdent(c, joinPath(path, "schema_version"), version, maxASCIIIdent32) {
			route.SchemaVersion = version
		}
		cond, ok := b.want("conditions")
		if ok {
			route.Conditions = parseConditions(cond, bounds, joinPath(path, "conditions"), c)
		}
		targets, ok := b.want("targets")
		if ok {
			route.Targets = parseRouteTargets(targets, joinPath(path, "targets"), c)
		}
		out = append(out, route)
	}
	return out
}

func parseConditions(v canonicaljson.Value, bounds Bounds, path string, c *collector) []conditionDef {
	items, ok := v.Array()
	if !ok {
		c.add("type_mismatch", path, "", "conditions 必须是数组")
		return nil
	}
	if len(items) > bounds.MaxConditions {
		c.add(constant.CodeLimitExceeded, path, "", "条件数量超过上限")
	}
	limit := len(items)
	if limit > bounds.MaxConditions {
		limit = bounds.MaxConditions
	}
	out := make([]conditionDef, 0, limit)
	for i := 0; i < limit; i++ {
		out = append(out, parseCondition(items[i], bounds, joinPath(path, itoa(i)), c))
	}
	return out
}

func parseCondition(v canonicaljson.Value, bounds Bounds, path string, c *collector) conditionDef {
	b, ok := newBag(v, path, c)
	if !ok {
		return conditionDef{}
	}
	b.allow("path", "op", "value")
	op, _ := b.text("op", true)
	rawPath, _ := b.text("path", true)
	cond := conditionDef{Op: op}
	if rawPath != "" {
		segs, err := DecodePointer(rawPath, bounds.MaxPathBytes)
		if err != nil {
			c.add("invalid_pointer", joinPath(path, "path"), "", "JSON Pointer 不合法")
		} else {
			cond.Segments = segs
		}
	}
	switch op {
	case "exists":
		if _, ok := b.m["value"]; ok {
			c.add("unknown_field", joinPath(path, "value"), "", "exists 不能带 value")
		}
	case "eq":
		val, ok := b.want("value")
		if ok && !scalar(val) {
			c.add("type_mismatch", joinPath(path, "value"), "", "eq 的值必须是标量")
		} else if ok {
			cond.Value = val
		}
	case "in":
		val, ok := b.want("value")
		if !ok {
			break
		}
		items, ok := val.Array()
		if !ok || len(items) == 0 || len(items) > maxInItems {
			c.add(constant.CodeLimitExceeded, joinPath(path, "value"), "", "in 必须是非空标量数组且不超过 100 项")
			break
		}
		for i, item := range items {
			if !scalar(item) {
				c.add("type_mismatch", joinPath(joinPath(path, "value"), itoa(i)), "", "in 的成员必须是标量")
				continue
			}
			cond.In = append(cond.In, item)
		}
	default:
		if op == "" {
			break
		}
		code := "unsupported_op"
		if op == "script" || op == "eval" || op == "regex" || op == "function" {
			code = "script_forbidden"
		}
		c.add(code, joinPath(path, "op"), "", "不支持的条件运算")
	}
	return cond
}

func scalar(v canonicaljson.Value) bool {
	switch v.Kind() {
	case canonicaljson.KindNull, canonicaljson.KindBool, canonicaljson.KindNumber, canonicaljson.KindString:
		return true
	default:
		return false
	}
}

func parseRouteTargets(v canonicaljson.Value, path string, c *collector) []string {
	items, ok := v.Array()
	if !ok || len(items) == 0 || len(items) > 50 {
		c.add(constant.CodeLimitExceeded, path, "", "每条路由的目标数量必须在 1 到 50")
		return nil
	}
	seen := map[string]struct{}{}
	out := make([]string, 0, len(items))
	for i, item := range items {
		text, ok := item.Text()
		if !ok || !validIdent(c, joinPath(path, itoa(i)), text, maxASCIIIdent128) {
			if ok {
				c.add("invalid_identifier", joinPath(path, itoa(i)), "", "标识不合法")
			} else {
				c.add("type_mismatch", joinPath(path, itoa(i)), "", "目标引用必须是字符串")
			}
			continue
		}
		if _, dup := seen[text]; dup {
			c.add("duplicate", joinPath(path, itoa(i)), text, "同一路由内目标重复")
			continue
		}
		seen[text] = struct{}{}
		out = append(out, text)
	}
	return out
}

type targetDef struct {
	ID                string
	ChannelID         string
	ChannelNum        uint64
	ProviderID        string
	ProviderAccountID string
	Operation         string
	AdapterType       string
	AdapterVersion    string
	CredentialRef     string
	MappingID         string
	MappingVersion    string
	Semantic          canonicaljson.Value
	SemanticCanonical []byte
}

func parseTargets(v canonicaljson.Value, bounds Bounds, doc *ReleaseDocument, c *collector) {
	b, ok := newBag(v, "/targets", c)
	if !ok {
		return
	}
	if len(b.m) > bounds.MaxTargets {
		c.add(constant.CodeLimitExceeded, "/targets", "", "目标数量超过上限")
	}
	keys := make([]string, 0, len(b.m))
	for key := range b.m {
		keys = append(keys, key)
	}
	slices.Sort(keys)
	kept := 0
	for _, key := range keys {
		if kept >= bounds.MaxTargets {
			break
		}
		kept++
		path := joinPath("/targets", key)
		if !validIdent(c, path, key, maxASCIIIdent128) {
			continue
		}
		tb, ok := newBag(b.m[key], path, c)
		if !ok {
			continue
		}
		tb.allow("channel_id", "provider_id", "provider_account_id", "operation", "adapter_type", "adapter_version", "credential_ref", "mapping_id", "mapping_version", "semantic_config")
		target := targetDef{ID: key}
		if id, ok := tb.text("channel_id", true); ok {
			n, err := ParseInternalID("channel_id", id)
			if err != nil {
				c.add("invalid_identifier", joinPath(path, "channel_id"), key, "标识不合法")
			} else {
				target.ChannelID = id
				target.ChannelNum = n
			}
		}
		target.ProviderID = identField(tb, c, "provider_id", key, maxASCIIIdent64)
		target.ProviderAccountID = identField(tb, c, "provider_account_id", key, maxASCIIIdent64)
		target.Operation = identField(tb, c, "operation", key, maxASCIIIdent64)
		target.AdapterType = identField(tb, c, "adapter_type", key, maxASCIIIdent64)
		target.AdapterVersion = identField(tb, c, "adapter_version", key, maxASCIIIdent32)
		if ref, ok := tb.text("credential_ref", true); ok {
			if err := ValidateExternalID("credential_ref", ref); err != nil {
				c.add("invalid_identifier", joinPath(path, "credential_ref"), key, "标识不合法")
			} else {
				target.CredentialRef = ref
			}
		}
		target.MappingID = identField(tb, c, "mapping_id", key, maxASCIIIdent128)
		target.MappingVersion = identField(tb, c, "mapping_version", key, maxASCIIIdent32)
		sem, ok := tb.want("semantic_config")
		if ok {
			if sem.Kind() != canonicaljson.KindObject {
				c.add("type_mismatch", joinPath(path, "semantic_config"), key, "必须是对象")
			} else {
				walkForbidden(sem, joinPath(path, "semantic_config"), key, c)
				target.Semantic = sem
				target.SemanticCanonical = canonicaljson.AppendCanonical(nil, sem)
			}
		}
		doc.targets[key] = target
	}
}

func identField(b bag, c *collector, key, target string, maxLen int) string {
	text, ok := b.text(key, true)
	if !ok {
		return ""
	}
	if !validIdent(c, joinPath(b.path, key), text, maxLen) {
		return ""
	}
	return text
}

func walkForbidden(v canonicaljson.Value, path, target string, c *collector) {
	switch v.Kind() {
	case canonicaljson.KindObject:
		fields, _ := v.Object()
		for _, field := range fields {
			if code, bad := forbiddenKey(field.Key); bad {
				c.add(code, joinPath(path, field.Key), target, "不支持的字段")
			}
			walkForbidden(field.Value, joinPath(path, field.Key), target, c)
		}
	case canonicaljson.KindArray:
		items, _ := v.Array()
		for i, item := range items {
			walkForbidden(item, joinPath(path, itoa(i)), target, c)
		}
	}
}

type mappingDef struct {
	Version string
	Fields  []fieldDef
}

type fieldDef struct {
	To          string
	ToSeg       []string
	FromSeg     []string
	HasFrom     bool
	Constant    canonicaljson.Value
	HasConstant bool
	Default     canonicaljson.Value
	HasDefault  bool
	Required    bool
	Nullable    bool
	Type        string
	SourceType  string
	Enum        []enumPair
}

type enumPair struct {
	From canonicaljson.Value
	To   canonicaljson.Value
}

func parseMappings(v canonicaljson.Value, bounds Bounds, doc *ReleaseDocument, c *collector) {
	b, ok := newBag(v, "/mappings", c)
	if !ok {
		return
	}
	keys := make([]string, 0, len(b.m))
	for key := range b.m {
		keys = append(keys, key)
	}
	slices.Sort(keys)
	for _, key := range keys {
		path := joinPath("/mappings", key)
		if !validIdent(c, path, key, maxASCIIIdent128) {
			continue
		}
		mb, ok := newBag(b.m[key], path, c)
		if !ok {
			continue
		}
		mb.allow("version", "fields")
		mapping := mappingDef{}
		if ver, ok := mb.text("version", true); ok && validIdent(c, joinPath(path, "version"), ver, maxASCIIIdent32) {
			mapping.Version = ver
		}
		fields, ok := mb.want("fields")
		if ok {
			mapping.Fields = parseFields(fields, bounds, joinPath(path, "fields"), c)
		}
		doc.mappings[key] = mapping
	}
}

func parseFields(v canonicaljson.Value, bounds Bounds, path string, c *collector) []fieldDef {
	items, ok := v.Array()
	if !ok {
		c.add("type_mismatch", path, "", "fields 必须是数组")
		return nil
	}
	if len(items) == 0 || len(items) > bounds.MaxMappingFields {
		c.add(constant.CodeLimitExceeded, path, "", "映射字段数量超出上限")
	}
	limit := len(items)
	if limit > bounds.MaxMappingFields {
		limit = bounds.MaxMappingFields
	}
	out := make([]fieldDef, 0, limit)
	var toPaths [][]string
	for i := 0; i < limit; i++ {
		field, segs := parseField(items[i], bounds, joinPath(path, itoa(i)), c)
		out = append(out, field)
		if len(segs) > 0 {
			toPaths = append(toPaths, segs)
		}
	}
	for i := 0; i < len(toPaths); i++ {
		for j := i + 1; j < len(toPaths); j++ {
			if pathConflict(toPaths[i], toPaths[j]) {
				c.add("conflict", path, "", "输出路径重复或父子冲突")
			}
		}
	}
	return out
}

func pathConflict(a, b []string) bool {
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	for i := 0; i < n; i++ {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func parseField(v canonicaljson.Value, bounds Bounds, path string, c *collector) (fieldDef, []string) {
	b, ok := newBag(v, path, c)
	if !ok {
		return fieldDef{}, nil
	}
	b.allow("to", "from", "constant", "default", "required", "nullable", "type", "source_type", "enum_map")
	field := fieldDef{Required: b.boolean("required", false), Nullable: b.boolean("nullable", false)}
	rawTo, toOK := b.text("to", true)
	if toOK {
		segs, err := DecodePointer(rawTo, bounds.MaxPathBytes)
		if err != nil {
			c.add("invalid_pointer", joinPath(path, "to"), "", "JSON Pointer 不合法")
		} else {
			field.To = rawTo
			field.ToSeg = segs
		}
	}
	_, hasFrom := b.m["from"]
	_, hasConst := b.m["constant"]
	if hasFrom == hasConst {
		c.add("conflict", path, "", "from 与 constant 必须恰有一个")
	}
	if hasFrom {
		rawFrom, ok := b.text("from", true)
		if ok {
			segs, err := DecodePointer(rawFrom, bounds.MaxPathBytes)
			if err != nil {
				c.add("invalid_pointer", joinPath(path, "from"), "", "JSON Pointer 不合法")
			} else {
				field.HasFrom = true
				field.FromSeg = segs
			}
		}
	}
	if hasConst {
		field.HasConstant = true
		field.Constant = b.m["constant"]
		if _, ok := b.m["default"]; ok {
			c.add("unknown_field", joinPath(path, "default"), "", "constant 不能带 default")
		}
		if _, ok := b.m["enum_map"]; ok {
			c.add("unknown_field", joinPath(path, "enum_map"), "", "constant 不能带 enum_map")
		}
		if _, ok := b.m["source_type"]; ok {
			c.add("unknown_field", joinPath(path, "source_type"), "", "constant 不能带 source_type")
		}
	}
	if raw, ok := b.m["default"]; ok && hasFrom {
		field.HasDefault = true
		field.Default = raw
	}
	typ, ok := b.text("type", true)
	if ok && !knownJSONType(typ) {
		c.add("unsupported_keyword", joinPath(path, "type"), "", "不支持的 JSON 类型")
	} else if ok {
		field.Type = typ
	}
	if raw, ok := b.m["source_type"]; ok && hasFrom {
		text, ok := raw.Text()
		if !ok || !knownJSONType(text) {
			c.add("unsupported_keyword", joinPath(path, "source_type"), "", "不支持的 JSON 类型")
		} else {
			field.SourceType = text
		}
	}
	if raw, ok := b.m["enum_map"]; ok && hasFrom {
		if field.SourceType == "" {
			c.add("missing_field", joinPath(path, "source_type"), "", "使用 enum_map 时必须声明 source_type")
		}
		field.Enum = parseEnumMap(raw, field.SourceType, field.Type, joinPath(path, "enum_map"), c)
	}
	if field.HasConstant && field.Type != "" && !valueMatchesType(field.Constant, field.Type) {
		if !(field.Constant.Kind() == canonicaljson.KindNull && field.Nullable) {
			c.add("type_mismatch", joinPath(path, "constant"), "", "constant 与 type 不一致")
		}
	}
	if field.HasDefault && field.Type != "" {
		checkDefault(field, joinPath(path, "default"), c)
	}
	return field, field.ToSeg
}

func checkDefault(field fieldDef, path string, c *collector) {
	if len(field.Enum) > 0 {
		if field.SourceType != "" && !valueMatchesType(field.Default, field.SourceType) {
			c.add("type_mismatch", path, "", "default 与 source_type 不一致")
			return
		}
		found := false
		for _, pair := range field.Enum {
			if canonicaljson.Equal(pair.From, field.Default) {
				found = true
				break
			}
		}
		if !found {
			c.add("enum_miss", path, "", "default 不在枚举来源中")
		}
		return
	}
	expect := field.Type
	if field.SourceType != "" {
		expect = field.SourceType
	}
	if expect != "" && !valueMatchesType(field.Default, expect) {
		c.add("type_mismatch", path, "", "default 与类型不一致")
	}
}

func parseEnumMap(v canonicaljson.Value, sourceType, outType, path string, c *collector) []enumPair {
	items, ok := v.Array()
	if !ok || len(items) == 0 || len(items) > maxEnumItems {
		c.add(constant.CodeLimitExceeded, path, "", "enum_map 数量超出上限")
		return nil
	}
	out := make([]enumPair, 0, len(items))
	for i, item := range items {
		ip := joinPath(path, itoa(i))
		b, ok := newBag(item, ip, c)
		if !ok {
			continue
		}
		b.allow("from", "to")
		from, fOK := b.want("from")
		to, tOK := b.want("to")
		if !fOK || !tOK {
			continue
		}
		if !scalar(from) {
			c.add("type_mismatch", joinPath(ip, "from"), "", "enum_map 来源必须是标量")
			continue
		}
		if sourceType != "" && !valueMatchesType(from, sourceType) {
			c.add("type_mismatch", joinPath(ip, "from"), "", "enum_map 来源类型不一致")
			continue
		}
		if outType != "" && !valueMatchesType(to, outType) {
			c.add("type_mismatch", joinPath(ip, "to"), "", "enum_map 目标类型不一致")
			continue
		}
		dup := false
		for _, prev := range out {
			if canonicaljson.Equal(prev.From, from) {
				dup = true
				break
			}
		}
		if dup {
			c.add("duplicate", joinPath(ip, "from"), "", "枚举来源重复")
			continue
		}
		out = append(out, enumPair{From: from, To: to})
	}
	return out
}

func knownJSONType(typ string) bool {
	switch typ {
	case "string", "number", "integer", "boolean", "null", "object", "array":
		return true
	default:
		return false
	}
}

func parsePolicy(v canonicaljson.Value, bounds Bounds, c *collector) []byte {
	b, ok := newBag(v, "/policy", c)
	if !ok {
		return nil
	}
	b.allow("max_attempts", "round_timeout_seconds", "backoff_initial_ms", "backoff_cap_ms", "server_wait_cap_seconds")
	attempts, aOK := b.integer("max_attempts")
	round, rOK := b.integer("round_timeout_seconds")
	initial, iOK := b.integer("backoff_initial_ms")
	capMs, cOK := b.integer("backoff_cap_ms")
	wait, wOK := b.integer("server_wait_cap_seconds")
	if aOK && (attempts < 1 || attempts > 32) {
		c.add(constant.CodeLimitExceeded, "/policy/max_attempts", "", "超出允许范围")
	}
	if rOK && (round < 60 || round > 604800) {
		c.add(constant.CodeLimitExceeded, "/policy/round_timeout_seconds", "", "超出允许范围")
	}
	if iOK && (initial < 100 || initial > 60000) {
		c.add(constant.CodeLimitExceeded, "/policy/backoff_initial_ms", "", "超出允许范围")
	}
	if cOK && iOK && (capMs < initial || capMs > 3600000) {
		c.add(constant.CodeLimitExceeded, "/policy/backoff_cap_ms", "", "超出允许范围")
	}
	if wOK && (wait < 1 || wait > 3600 || timeSeconds(wait) > bounds.ServerWaitCap) {
		c.add(constant.CodeLimitExceeded, "/policy/server_wait_cap_seconds", "", "超出允许范围")
	}
	return canonicaljson.AppendCanonical(nil, v)
}

func timeSeconds(n int64) timeDurationSeconds {
	return timeDurationSeconds(n) * timeDurationSeconds(timeSecond)
}

// 避免 release.go 直接铺开 time 的调用点，秒数比较用 time.Duration。
const timeSecond = 1_000_000_000

type timeDurationSeconds int64

func (n timeDurationSeconds) seconds() int64 { return int64(n) / timeSecond }

func link(doc *ReleaseDocument, bounds Bounds, c *collector) {
	schemas := map[string]struct{}{}
	for _, schema := range doc.schemas {
		schemas[schema.EventType+"\x00"+schema.SchemaVersion] = struct{}{}
	}
	for i, route := range doc.routes {
		path := joinPath("/routes", itoa(i))
		if route.EventType != "" && route.SchemaVersion != "" {
			if _, ok := schemas[route.EventType+"\x00"+route.SchemaVersion]; !ok {
				c.add("missing_field", path, "", "路由引用了不存在的事件 schema")
			}
		}
		for j, id := range route.Targets {
			if _, ok := doc.targets[id]; !ok {
				c.add("missing_field", joinPath(joinPath(path, "targets"), itoa(j)), id, "目标不存在")
			}
		}
	}
	ids := make([]string, 0, len(doc.targets))
	for id := range doc.targets {
		ids = append(ids, id)
	}
	slices.Sort(ids)
	for _, id := range ids {
		target := doc.targets[id]
		mapping, ok := doc.mappings[target.MappingID]
		if target.MappingID != "" && !ok {
			c.add("missing_field", joinPath(joinPath("/targets", id), "mapping_id"), id, "映射不存在")
			continue
		}
		if ok && target.MappingVersion != "" && mapping.Version != "" && mapping.Version != target.MappingVersion {
			c.add("conflict", joinPath(joinPath("/targets", id), "mapping_version"), id, "映射版本不一致")
		}
		if target.ChannelNum != 0 && target.ProviderID != "" && target.CredentialRef != "" && len(target.SemanticCanonical) > 0 {
			doc.bindings = append(doc.bindings, TargetBinding{
				RouteTargetID:     id,
				ChannelID:         target.ChannelNum,
				ProviderID:        target.ProviderID,
				ProviderAccountID: target.ProviderAccountID,
				Operation:         target.Operation,
				AdapterType:       target.AdapterType,
				AdapterVersion:    target.AdapterVersion,
				CredentialRef:     target.CredentialRef,
				MappingID:         target.MappingID,
				MappingVersion:    target.MappingVersion,
				Semantic:          append([]byte(nil), target.SemanticCanonical...),
			})
		}
	}
	_ = bounds
}

func validIdent(c *collector, path, value string, maxLen int) bool {
	if err := ValidateASCIIIdent(path, value, maxLen); err != nil {
		c.add("invalid_identifier", path, "", "标识不合法")
		return false
	}
	return true
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	var b [16]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	return string(b[i:])
}

- old_string: 

### Turn 80 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go has been created successfully.

### Turn 81 (Assistant)
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- old_string: import (
	"slices"
	"strings"

	"notifier/internal/canonicaljson"
	"notifier/internal/constant"
)
- new_string: import (
	"slices"
	"strings"
	"time"

	"notifier/internal/canonicaljson"
	"notifier/internal/constant"
)
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- old_string: 			pb, ok := newBag(props, joinPath(path, "properties"), c)
			if ok {
				for key, child := range pb.m {
					if !validIdent(c, joinPath(joinPath(path, "properties"), key), key, maxASCIIIdent128) {
						continue
					}
					sh.Properties[key] = parseShape(child, joinPath(joinPath(path, "properties"), key), depth+1, c)
				}
			}
- new_string: 			pb, ok := newBag(props, joinPath(path, "properties"), c)
			if ok {
				for key, child := range pb.m {
					if key == "" {
						c.add("invalid_identifier", joinPath(path, "properties"), "", "属性名不能为空")
						continue
					}
					sh.Properties[key] = parseShape(child, joinPath(joinPath(path, "properties"), key), depth+1, c)
				}
			}
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- old_string: 	seen := map[string]struct{}{}
	out := make([]string, 0, len(items))
	for i, item := range items {
		text, ok := item.Text()
		if !ok || !validIdent(c, joinPath(path, itoa(i)), text, maxASCIIIdent128) {
			if ok {
				c.add("invalid_identifier", joinPath(path, itoa(i)), "", "标识不合法")
			} else {
				c.add("type_mismatch", joinPath(path, itoa(i)), "", "目标引用必须是字符串")
			}
			continue
		}
- new_string: 	seen := map[string]struct{}{}
	out := make([]string, 0, len(items))
	for i, item := range items {
		text, ok := item.Text()
		if !ok {
			c.add("type_mismatch", joinPath(path, itoa(i)), "", "目标引用必须是字符串")
			continue
		}
		if !validIdent(c, joinPath(path, itoa(i)), text, maxASCIIIdent128) {
			continue
		}
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- old_string: 	if wOK && (wait < 1 || wait > 3600 || timeSeconds(wait) > bounds.ServerWaitCap) {
		c.add(constant.CodeLimitExceeded, "/policy/server_wait_cap_seconds", "", "超出允许范围")
	}
	return canonicaljson.AppendCanonical(nil, v)
}

func timeSeconds(n int64) timeDurationSeconds {
	return timeDurationSeconds(n) * timeDurationSeconds(timeSecond)
}

// 避免 release.go 直接铺开 time 的调用点，秒数比较用 time.Duration。
const timeSecond = 1_000_000_000

type timeDurationSeconds int64

func (n timeDurationSeconds) seconds() int64 { return int64(n) / timeSecond }

func link(doc *ReleaseDocument, bounds Bounds, c *collector) {
- new_string: 	if wOK && (wait < 1 || wait > 3600 || time.Duration(wait)*time.Second > bounds.ServerWaitCap) {
		c.add(constant.CodeLimitExceeded, "/policy/server_wait_cap_seconds", "", "超出允许范围")
	}
	return canonicaljson.AppendCanonical(nil, v)
}

func link(doc *ReleaseDocument, c *collector) {
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- old_string: 	link(doc, bounds, c)
	return doc
}
- new_string: 	link(doc, c)
	return doc
}
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- old_string: 		})
	}
	_ = bounds
}
- new_string: 		})
	}
}

### Turn 82 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go has been updated successfully.

### Turn 83 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go has been updated successfully.

### Turn 84 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go has been updated successfully.

### Turn 85 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go has been updated successfully.

### Turn 86 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go has been updated successfully.

### Turn 87 (Function)
[tool_response]
The string to replace was not found in the file, use the read_file tool to see the correct string. The user may have changed the file since you last read it.

Nearest match: line 83: 	c.items = append(c.items, Issue{Code: code, FieldPath: path, RouteTargetID: target, Message: msg})

### Turn 88 (Assistant)
[tool_request: grep]
- pattern: func link|_ = bounds
- glob: internal/domain/release.go

### Turn 89 (Function)
[tool_response]
<workspace_result workspace_path="/Users/kiteeater/jobwork/ai-coding-test">
Found 2 matching lines
/Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
1111:func link(doc *ReleaseDocument, c *collector) {
1160:	_ = bounds
</workspace_result>

### Turn 90 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- offset: 1145
- limit: 25

### Turn 91 (Function)
[tool_response]
1145→			doc.bindings = append(doc.bindings, TargetBinding{
				RouteTargetID:     id,
				ChannelID:         target.ChannelNum,
				ProviderID:        target.ProviderID,
				ProviderAccountID: target.ProviderAccountID,
1150→				Operation:         target.Operation,
				AdapterType:       target.AdapterType,
				AdapterVersion:    target.AdapterVersion,
				CredentialRef:     target.CredentialRef,
				MappingID:         target.MappingID,
				MappingVersion:    target.MappingVersion,
				Semantic:          append([]byte(nil), target.SemanticCanonical...),
			})
		}
	}
1160→	_ = bounds
}

func validIdent(c *collector, path, value string, maxLen int) bool {
	if err := ValidateASCIIIdent(path, value, maxLen); err != nil {
		c.add("invalid_identifier", path, "", "标识不合法")
		return false
	}
	return true
}

### Turn 92 (Assistant)
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- old_string: 		}
	}
	_ = bounds
}
- new_string: 		}
	}
}
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/plan.go
- new_string: package domain

import (
	"context"
	"slices"
	"unicode/utf8"

	"notifier/internal/canonicaljson"
	"notifier/internal/constant"
)

// BuildPlan 按固定发布计算投递计划。不写库，也不读取当前指针。
// 任一目标映射或数据版本失败时不返回部分计划。
func BuildPlan(ctx context.Context, doc *ReleaseDocument, releaseID uint64, versionNo uint32, env EventEnvelope, bounds Bounds) (DeliveryPlan, error) {
	if err := ctx.Err(); err != nil {
		return DeliveryPlan{}, planTimeout()
	}
	if doc == nil || releaseID == 0 {
		return DeliveryPlan{}, codeErr(constant.CodeConfigurationUnavailable, "发布版本不可用", "/")
	}
	if len(env.DataCanonical) > bounds.MaxEventBytes {
		return DeliveryPlan{}, codeErr(constant.CodeLimitExceeded, "事件数据超过上限", "/")
	}
	data, err := canonicaljson.Parse(env.DataCanonical)
	if err != nil {
		return DeliveryPlan{}, codeErr(constant.CodeInvalidRequest, "事件数据不是合法 JSON", "/")
	}
	if valueDepth(data) > maxShapeDepth || fieldCount(data) > maxEventFieldCount {
		return DeliveryPlan{}, codeErr(constant.CodeLimitExceeded, "事件数据层级或字段数超过上限", "/")
	}
	schema, ok := findSchema(doc, env.EventType, env.SchemaVersion)
	if !ok {
		return DeliveryPlan{}, codeErr(constant.CodeUnsupportedSchema, "不支持的事件类型或版本", "/event_type")
	}
	var shapeIssues []Issue
	applyShape(schema.Shape, data, "", 1, &shapeIssues)
	if len(shapeIssues) > 0 {
		return DeliveryPlan{}, issuesError(constant.CodeUnsupportedSchema, "事件数据不符合已发布的 schema", shapeIssues)
	}
	if err := ctx.Err(); err != nil {
		return DeliveryPlan{}, planTimeout()
	}
	matched := matchRoutes(doc, env, data)
	if len(matched) == 0 {
		return DeliveryPlan{}, codeErr(constant.CodeNoMatchingRoute, "没有匹配的路由", "")
	}
	ids := unionTargets(matched)
	if len(ids) > bounds.MaxFanout {
		return DeliveryPlan{}, codeErr(constant.CodeLimitExceeded, "扇出超过上限", "/targets")
	}
	releaseRef, err := FormatInternalID(releaseID)
	if err != nil {
		return DeliveryPlan{}, codeErr(constant.CodeInternal, "内部错误", "")
	}
	var mapIssues []Issue
	targets := make([]TargetPlan, 0, len(ids))
	for _, id := range ids {
		if err := ctx.Err(); err != nil {
			return DeliveryPlan{}, planTimeout()
		}
		target := doc.targets[id]
		mapping := doc.mappings[target.MappingID]
		payload, issues := applyMapping(data, mapping, id, bounds)
		if len(issues) > 0 {
			mapIssues = append(mapIssues, issues...)
			continue
		}
		fixed := fixedTarget(target)
		targets = append(targets, TargetPlan{
			RouteTargetID:     id,
			ProviderID:        target.ProviderID,
			ProviderAccountID: target.ProviderAccountID,
			Operation:         target.Operation,
			MappingID:         target.MappingID,
			MappingVersion:    target.MappingVersion,
			AdapterType:       target.AdapterType,
			AdapterVersion:    target.AdapterVersion,
			PayloadCanonical:  payload,
			FixedTarget:       fixed,
		})
	}
	if len(mapIssues) > 0 {
		return DeliveryPlan{}, issuesError(constant.CodeMappingInvalid, "发布 "+releaseRef+" 映射失败", mapIssues)
	}
	return DeliveryPlan{
		ReleaseRef:    releaseRef,
		VersionNo:     versionNo,
		FormatVersion: doc.FormatVersion,
		Targets:       targets,
		RoundPolicy:   append([]byte(nil), doc.PolicyCanonical...),
	}, nil
}

func findSchema(doc *ReleaseDocument, eventType, version string) (schemaDef, bool) {
	for _, schema := range doc.schemas {
		if schema.EventType == eventType && schema.SchemaVersion == version {
			return schema, true
		}
	}
	return schemaDef{}, false
}

func matchRoutes(doc *ReleaseDocument, env EventEnvelope, data canonicaljson.Value) []routeDef {
	var out []routeDef
	for _, route := range doc.routes {
		if route.CallerID != env.CallerID || route.SourceBusiness != env.SourceBusiness {
			continue
		}
		if route.EventType != env.EventType || route.SchemaVersion != env.SchemaVersion {
			continue
		}
		if !matchConditions(route.Conditions, data) {
			continue
		}
		out = append(out, route)
	}
	return out
}

func matchConditions(conditions []conditionDef, data canonicaljson.Value) bool {
	for _, cond := range conditions {
		value, exists := lookup(data, cond.Segments)
		switch cond.Op {
		case "exists":
			if !exists {
				return false
			}
		case "eq":
			if !exists || !canonicaljson.Equal(value, cond.Value) {
				return false
			}
		case "in":
			if !exists || !inList(value, cond.In) {
				return false
			}
		default:
			return false
		}
	}
	return true
}

func inList(value canonicaljson.Value, items []canonicaljson.Value) bool {
	for _, item := range items {
		if canonicaljson.Equal(value, item) {
			return true
		}
	}
	return false
}

// lookup 从事件 data 根按对象字段下钻。非对象继续下钻视为缺失。显式 null 视为存在。
func lookup(root canonicaljson.Value, segs []string) (canonicaljson.Value, bool) {
	cur := root
	for _, seg := range segs {
		if cur.Kind() != canonicaljson.KindObject {
			return canonicaljson.Value{}, false
		}
		next, ok := cur.Member(seg)
		if !ok {
			return canonicaljson.Value{}, false
		}
		cur = next
	}
	return cur, true
}

func unionTargets(routes []routeDef) []string {
	seen := map[string]struct{}{}
	var ids []string
	for _, route := range routes {
		for _, id := range route.Targets {
			if _, ok := seen[id]; ok {
				continue
			}
			seen[id] = struct{}{}
			ids = append(ids, id)
		}
	}
	slices.Sort(ids)
	return ids
}

func applyMapping(data canonicaljson.Value, mapping mappingDef, target string, bounds Bounds) ([]byte, []Issue) {
	root := &tree{}
	var issues []Issue
	for _, field := range mapping.Fields {
		value, omit, issue := evalField(data, field)
		if issue != nil {
			issue.RouteTargetID = target
			issues = append(issues, *issue)
			continue
		}
		if omit {
			continue
		}
		if err := root.insert(field.ToSeg, value); err != nil {
			issues = append(issues, Issue{
				Code: "conflict", FieldPath: field.To, RouteTargetID: target, Message: "输出路径冲突",
			})
		}
	}
	if len(issues) > 0 {
		return nil, issues
	}
	payload := canonicaljson.AppendCanonical(nil, root.value())
	if len(payload) > bounds.MaxPayloadBytes {
		return nil, []Issue{{
			Code: constant.CodeLimitExceeded, FieldPath: "/", RouteTargetID: target, Message: "映射载荷超过上限",
		}}
	}
	return payload, nil
}

func evalField(data canonicaljson.Value, field fieldDef) (canonicaljson.Value, bool, *Issue) {
	var value canonicaljson.Value
	present := false
	if field.HasConstant {
		value = field.Constant
		present = true
	} else if field.HasFrom {
		value, present = lookup(data, field.FromSeg)
		if !present && field.HasDefault {
			value = field.Default
			present = true
		}
	}
	if !present {
		if field.Required {
			return canonicaljson.Value{}, false, &Issue{Code: "required", FieldPath: field.To, Message: "缺少必填字段"}
		}
		return canonicaljson.Value{}, true, nil
	}
	if value.Kind() == canonicaljson.KindNull {
		if field.Nullable || field.Type == "null" {
			return value, false, nil
		}
		return canonicaljson.Value{}, false, &Issue{Code: "null_forbidden", FieldPath: field.To, Message: "该字段不允许 null"}
	}
	if field.SourceType != "" && !valueMatchesType(value, field.SourceType) {
		return canonicaljson.Value{}, false, &Issue{Code: "type_mismatch", FieldPath: field.To, Message: "来源类型不匹配"}
	}
	if len(field.Enum) > 0 {
		found := false
		for _, pair := range field.Enum {
			if canonicaljson.Equal(pair.From, value) {
				value = pair.To
				found = true
				break
			}
		}
		if !found {
			return canonicaljson.Value{}, false, &Issue{Code: "enum_miss", FieldPath: field.To, Message: "枚举没有对应值"}
		}
	}
	if field.Type != "" && !valueMatchesType(value, field.Type) {
		return canonicaljson.Value{}, false, &Issue{Code: "type_mismatch", FieldPath: field.To, Message: "输出类型不匹配"}
	}
	return value, false, nil
}

type tree struct {
	child map[string]*tree
	set   bool
	val   canonicaljson.Value
}

func (n *tree) insert(segs []string, val canonicaljson.Value) error {
	cur := n
	for i, seg := range segs {
		if cur.set {
			return errPointer
		}
		if cur.child == nil {
			cur.child = map[string]*tree{}
		}
		next := cur.child[seg]
		if next == nil {
			next = &tree{}
			cur.child[seg] = next
		}
		if i == len(segs)-1 {
			if next.set || len(next.child) > 0 {
				return errPointer
			}
			next.set = true
			next.val = val
			return nil
		}
		if next.set {
			return errPointer
		}
		cur = next
	}
	return errPointer
}

func (n *tree) value() canonicaljson.Value {
	if n == nil || n.set {
		if n == nil {
			return canonicaljson.Object(nil)
		}
		return n.val
	}
	fields := make([]canonicaljson.Field, 0, len(n.child))
	for key, child := range n.child {
		fields = append(fields, canonicaljson.Field{Key: key, Value: child.value()})
	}
	return canonicaljson.Object(fields)
}

func fixedTarget(target targetDef) []byte {
	obj := canonicaljson.Object([]canonicaljson.Field{
		{Key: "adapter_type", Value: canonicaljson.String(target.AdapterType)},
		{Key: "adapter_version", Value: canonicaljson.String(target.AdapterVersion)},
		{Key: "channel_id", Value: canonicaljson.String(target.ChannelID)},
		{Key: "credential_ref", Value: canonicaljson.String(target.CredentialRef)},
		{Key: "mapping_id", Value: canonicaljson.String(target.MappingID)},
		{Key: "mapping_version", Value: canonicaljson.String(target.MappingVersion)},
		{Key: "operation", Value: canonicaljson.String(target.Operation)},
		{Key: "provider_account_id", Value: canonicaljson.String(target.ProviderAccountID)},
		{Key: "provider_id", Value: canonicaljson.String(target.ProviderID)},
		{Key: "route_target_id", Value: canonicaljson.String(target.ID)},
		{Key: "semantic_config", Value: target.Semantic},
	})
	return canonicaljson.AppendCanonical(nil, obj)
}

func applyShape(sh shapeDef, v canonicaljson.Value, path string, depth int, out *[]Issue) {
	if depth > maxShapeDepth {
		*out = append(*out, Issue{Code: constant.CodeLimitExceeded, FieldPath: loc(path), Message: "层级超过上限"})
		return
	}
	if v.Kind() == canonicaljson.KindNull {
		if sh.Nullable || sh.Type == "null" {
			return
		}
		*out = append(*out, Issue{Code: "null_forbidden", FieldPath: loc(path), Message: "不允许 null"})
		return
	}
	switch sh.Type {
	case "object":
		fields, ok := v.Object()
		if !ok {
			*out = append(*out, Issue{Code: "type_mismatch", FieldPath: loc(path), Message: "类型不匹配"})
			return
		}
		present := make(map[string]canonicaljson.Value, len(fields))
		for _, field := range fields {
			present[field.Key] = field.Value
		}
		if !sh.Additional {
			for key := range present {
				if _, ok := sh.Properties[key]; !ok {
					*out = append(*out, Issue{Code: "unknown_field", FieldPath: joinPath(path, key), Message: "存在未声明字段"})
				}
			}
		}
		for _, key := range sh.Required {
			if _, ok := present[key]; !ok {
				*out = append(*out, Issue{Code: "required", FieldPath: joinPath(path, key), Message: "缺少必填字段"})
			}
		}
		for key, child := range sh.Properties {
			val, ok := present[key]
			if !ok {
				continue
			}
			applyShape(child, val, joinPath(path, key), depth+1, out)
		}
	case "array":
		items, ok := v.Array()
		if !ok {
			*out = append(*out, Issue{Code: "type_mismatch", FieldPath: loc(path), Message: "类型不匹配"})
			return
		}
		maxItems := sh.MaxItems
		if maxItems == 0 {
			maxItems = defaultArrayItems
		}
		if len(items) > maxItems {
			*out = append(*out, Issue{Code: constant.CodeLimitExceeded, FieldPath: loc(path), Message: "数组长度超过上限"})
			return
		}
		if sh.Items == nil {
			*out = append(*out, Issue{Code: "missing_field", FieldPath: loc(path), Message: "数组缺少 items"})
			return
		}
		for i, item := range items {
			applyShape(*sh.Items, item, joinPath(path, itoa(i)), depth+1, out)
		}
	case "string":
		text, ok := v.Text()
		if !ok {
			*out = append(*out, Issue{Code: "type_mismatch", FieldPath: loc(path), Message: "类型不匹配"})
			return
		}
		maxLen := sh.MaxLength
		if maxLen == 0 {
			maxLen = defaultStringRunes
		}
		if utf8.RuneCountInString(text) > maxLen {
			*out = append(*out, Issue{Code: constant.CodeLimitExceeded, FieldPath: loc(path), Message: "字符串超过上限"})
			return
		}
		if len(sh.Enum) > 0 && !enumHas(sh.Enum, v) {
			*out = append(*out, Issue{Code: "enum_miss", FieldPath: loc(path), Message: "不在枚举中"})
		}
	case "number", "integer", "boolean":
		if !valueMatchesType(v, sh.Type) {
			*out = append(*out, Issue{Code: "type_mismatch", FieldPath: loc(path), Message: "类型不匹配"})
			return
		}
		if len(sh.Enum) > 0 && !enumHas(sh.Enum, v) {
			*out = append(*out, Issue{Code: "enum_miss", FieldPath: loc(path), Message: "不在枚举中"})
		}
	case "null":
		*out = append(*out, Issue{Code: "type_mismatch", FieldPath: loc(path), Message: "类型不匹配"})
	default:
		*out = append(*out, Issue{Code: "unsupported_keyword", FieldPath: loc(path), Message: "不支持的 schema 类型"})
	}
}

func enumHas(items []canonicaljson.Value, v canonicaljson.Value) bool {
	for _, item := range items {
		if canonicaljson.Equal(item, v) {
			return true
		}
	}
	return false
}

func valueDepth(v canonicaljson.Value) int {
	switch v.Kind() {
	case canonicaljson.KindObject:
		fields, _ := v.Object()
		max := 1
		for _, field := range fields {
			if d := 1 + valueDepth(field.Value); d > max {
				max = d
			}
		}
		return max
	case canonicaljson.KindArray:
		items, _ := v.Array()
		max := 1
		for _, item := range items {
			if d := 1 + valueDepth(item); d > max {
				max = d
			}
		}
		return max
	default:
		return 1
	}
}

func fieldCount(v canonicaljson.Value) int {
	switch v.Kind() {
	case canonicaljson.KindObject:
		fields, _ := v.Object()
		n := len(fields)
		for _, field := range fields {
			n += fieldCount(field.Value)
		}
		return n
	case canonicaljson.KindArray:
		items, _ := v.Array()
		n := 0
		for _, item := range items {
			n += fieldCount(item)
		}
		return n
	default:
		return 0
	}
}

func codeErr(code, message, path string) error {
	err, _ := NewError(code, message, path, nil)
	return err
}

func planTimeout() error {
	return codeErr(constant.CodePlanTimeout, "计划计算超时", "")
}

func issuesError(code, message string, issues []Issue) error {
	slices.SortFunc(issues, func(a, b Issue) int {
		if n := a.RouteTargetID; n != b.RouteTargetID {
			if a.RouteTargetID < b.RouteTargetID {
				return -1
			}
			return 1
		}
		if a.FieldPath < b.FieldPath {
			return -1
		}
		if a.FieldPath > b.FieldPath {
			return 1
		}
		if a.Code < b.Code {
			return -1
		}
		if a.Code > b.Code {
			return 1
		}
		return 0
	})
	if len(issues) > constant.MaxErrorDetails {
		issues = issues[:constant.MaxErrorDetails]
	}
	details := make([]Detail, len(issues))
	for i, item := range issues {
		msg := item.Message
		if item.RouteTargetID != "" {
			msg = item.RouteTargetID + ": " + msg
		}
		details[i] = Detail{FieldPath: item.FieldPath, Code: item.Code, Message: msg}
	}
	path := ""
	if len(details) > 0 {
		path = details[0].FieldPath
	}
	err, fail := NewError(code, message, path, details)
	if fail != nil {
		err, _ = NewError(code, message, path, nil)
	}
	return err
}

- old_string: 

### Turn 93 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/plan.go has been created successfully.

### Turn 94 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go has been updated successfully.

### Turn 95 (Assistant)
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/plan.go
- old_string: 	if valueDepth(data) > maxShapeDepth || fieldCount(data) > maxEventFieldCount {
		return DeliveryPlan{}, codeErr(constant.CodeLimitExceeded, "事件数据层级或字段数超过上限", "/")
	}
- new_string: 	// 大小已在入口检查。字段数先于 schema 解释；层级由 schema 遍历自己封顶。
	if fieldCount(data) > maxEventFieldCount {
		return DeliveryPlan{}, codeErr(constant.CodeLimitExceeded, "事件数据字段数超过上限", "/")
	}
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/plan.go
- old_string: func valueDepth(v canonicaljson.Value) int {
	switch v.Kind() {
	case canonicaljson.KindObject:
		fields, _ := v.Object()
		max := 1
		for _, field := range fields {
			if d := 1 + valueDepth(field.Value); d > max {
				max = d
			}
		}
		return max
	case canonicaljson.KindArray:
		items, _ := v.Array()
		max := 1
		for _, item := range items {
			if d := 1 + valueDepth(item); d > max {
				max = d
			}
		}
		return max
	default:
		return 1
	}
}

func fieldCount(v canonicaljson.Value) int {
- new_string: func fieldCount(v canonicaljson.Value) int {
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- old_string: // Bindings 返回目标归属，顺序按 route_target_id 固定。
func (d *ReleaseDocument) Bindings() []TargetBinding {
- new_string: // Semantic 返回目标上已冻结的 semantic_config 规范化字节。
func (d *ReleaseDocument) Semantic(routeTargetID string) ([]byte, bool) {
	if d == nil {
		return nil, false
	}
	target, ok := d.targets[routeTargetID]
	if !ok {
		return nil, false
	}
	return append([]byte(nil), target.SemanticCanonical...), true
}

// Bindings 返回目标归属，顺序按 route_target_id 固定。
func (d *ReleaseDocument) Bindings() []TargetBinding {

### Turn 96 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/plan.go has been updated successfully.

### Turn 97 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go has been updated successfully.

### Turn 98 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/domain/plan.go has been updated successfully.

### Turn 99 (Assistant)
[tool_request: read_file]
- target_file: /Users/kiteeater/jobwork/ai-coding-test/internal/domain/release.go
- offset: 45
- limit: 40

### Turn 100 (Function)
[tool_response]
45→	FormatVersion   int
	Canonical       []byte
	SHA256          string
	PolicyCanonical []byte
	callers         []string
50→	bindings        []TargetBinding
	schemas         []schemaDef
	routes          []routeDef
	targets         map[string]targetDef
	mappings        map[string]mappingDef
}

// CallerIDs 返回路由中出现的调用方，供发布权限核对。
func (d *ReleaseDocument) CallerIDs() []string {
	if d == nil {
60→		return nil
	}
	return append([]string(nil), d.callers...)
}

// Semantic 返回目标上已冻结的 semantic_config 规范化字节。
func (d *ReleaseDocument) Semantic(routeTargetID string) ([]byte, bool) {
	if d == nil {
		return nil, false
	}
70→	target, ok := d.targets[routeTargetID]
	if !ok {
		return nil, false
	}
	return append([]byte(nil), target.SemanticCanonical...), true
}

// Bindings 返回目标归属，顺序按 route_target_id 固定。
func (d *ReleaseDocument) Bindings() []TargetBinding {
	if d == nil {
80→		return nil
	}
	return append([]TargetBinding(nil), d.bindings...)
}


### Turn 101 (Assistant)
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/data_interface/config.go
- new_string: // Package data_interface 定义 S01 用到的小端口。
// 适配器只暴露注册与本地校验；发送、凭证刷新和限流由 S05 完成。
package data_interface

import (
	"context"
	"errors"
	"slices"
	"time"

	"notifier/internal/canonicaljson"
	"notifier/internal/domain"
)

var (
	// ErrReleaseNotFound 表示该 release_id 没有持久化版本。
	ErrReleaseNotFound = errors.New("data_interface: release not found")
	// ErrNoCurrent 表示还没有当前发布。
	ErrNoCurrent = errors.New("data_interface: no current release")
	// ErrChannelNotFound 表示通道不存在。
	ErrChannelNotFound = errors.New("data_interface: channel not found")
	// ErrCredentialNotFound 表示凭证引用不存在。
	ErrCredentialNotFound = errors.New("data_interface: credential not found")
	// ErrCacheMiss 表示按版本的缓存没有命中，可以回源。
	ErrCacheMiss = errors.New("data_interface: cache miss")
	// ErrCacheCorrupt 表示缓存值无法对上发布 ID 或内容摘要，必须丢弃后回源。
	ErrCacheCorrupt = errors.New("data_interface: cache corrupt")
)

// ReleaseRecord 是一份不可变发布。内容以规范化字节为准。
type ReleaseRecord struct {
	ReleaseID          uint64
	VersionNo          uint32
	Status             string
	ContentCanonical   []byte
	ContentSHA256      string
	FingerprintVersion int
	ReferenceSnapshot  []byte
	CreatedAt          time.Time
	PublishedAt        *time.Time
}

// CreateDraftInput 是创建草稿的参数。引用版本由仓储在事务内读取。
type CreateDraftInput struct {
	ActorID          string
	Reason           string
	IdempotencyKey   string
	Fingerprint      string
	ContentCanonical []byte
	ContentSHA256    string
	Bindings         []domain.TargetBinding
}

// CreateDraftResult 是已提交的创建结果。相同操作键返回同一版本。
type CreateDraftResult struct {
	OperationID   string
	ReleaseID     uint64
	VersionNo     uint32
	Status        string
	ContentSHA256 string
}

// PublishInput 是发布参数。Expected 为 nil 表示首次发布。
type PublishInput struct {
	ActorID        string
	Reason         string
	IdempotencyKey string
	Fingerprint    string
	ReleaseID      uint64
	Expected       *uint64
}

// PublishResult 是已提交的发布结果。重放不得改写当前指针。
type PublishResult struct {
	OperationID string
	ReleaseID   uint64
	VersionNo   uint32
	Previous    *uint64
	PublishedAt time.Time
}

// ReleaseRepository 保存不可变草稿、当前指针和发布操作。
type ReleaseRepository interface {
	CreateDraft(ctx context.Context, in CreateDraftInput) (CreateDraftResult, error)
	Publish(ctx context.Context, in PublishInput) (PublishResult, error)
	Load(ctx context.Context, releaseID uint64) (ReleaseRecord, error)
	LoadCurrentID(ctx context.Context) (uint64, error)
}

// ChannelPin 是发布复核用的通道归属，不含启停和额度。
type ChannelPin struct {
	ChannelID         uint64
	RowVersion        uint32
	ProviderID        string
	ProviderAccountID string
	Operation         string
	AdapterType       string
	AdapterVersion    string
	CredentialRef     string
}

// CredentialPin 是逻辑凭证引用。不含秘密。完整存储由 S05 完成。
type CredentialPin struct {
	Ref               string
	Version           uint32
	ProviderID        string
	ProviderAccountID string
}

// ReferenceSet 是草稿冻结的引用版本。
type ReferenceSet struct {
	Channels    []ChannelPin
	Credentials []CredentialPin
}

// ChannelReader 读取通道归属。
type ChannelReader interface {
	GetChannel(ctx context.Context, id uint64) (ChannelPin, error)
}

// CredentialReader 读取凭证引用是否存在及其版本。
type CredentialReader interface {
	GetCredential(ctx context.Context, ref string) (CredentialPin, error)
}

// TargetSpec 是发布期交给适配器的固定目标。
type TargetSpec struct {
	RouteTargetID     string
	Operation         string
	CredentialRef     string
	SemanticCanonical []byte
}

// Adapter 只做本地校验。完整协议由 S05 完成。
type Adapter interface {
	ValidateTarget(ctx context.Context, spec TargetSpec) error
	ValidatePayload(ctx context.Context, payload, semantic []byte) error
}

// AdapterRegistry 按 adapter_type 与 adapter_version 查找已注册适配器。
type AdapterRegistry interface {
	Lookup(adapterType, adapterVersion string) (Adapter, bool)
}

// ReleaseCache 按发布 ID 缓存不可变内容。当前指针不经过这里。
type ReleaseCache interface {
	Get(ctx context.Context, releaseID uint64) (ReleaseRecord, error)
	Put(ctx context.Context, rec ReleaseRecord) error
	Delete(ctx context.Context, releaseID uint64) error
}

// SameReferences 比较两份引用版本。顺序无关。
func SameReferences(stored, live ReferenceSet) bool {
	if len(stored.Channels) != len(live.Channels) || len(stored.Credentials) != len(live.Credentials) {
		return false
	}
	channels := make(map[uint64]ChannelPin, len(live.Channels))
	for _, item := range live.Channels {
		channels[item.ChannelID] = item
	}
	for _, item := range stored.Channels {
		if channels[item.ChannelID] != item {
			return false
		}
	}
	creds := make(map[string]CredentialPin, len(live.Credentials))
	for _, item := range live.Credentials {
		creds[item.Ref] = item
	}
	for _, item := range stored.Credentials {
		if creds[item.Ref] != item {
			return false
		}
	}
	return true
}

// MarshalReferences 写成规范化 JSON，供发布事务保存。
func MarshalReferences(set ReferenceSet) ([]byte, error) {
	channels := append([]ChannelPin(nil), set.Channels...)
	slices.SortFunc(channels, func(a, b ChannelPin) int {
		if a.ChannelID < b.ChannelID {
			return -1
		}
		if a.ChannelID > b.ChannelID {
			return 1
		}
		return 0
	})
	creds := append([]CredentialPin(nil), set.Credentials...)
	slices.SortFunc(creds, func(a, b CredentialPin) int {
		if a.Ref < b.Ref {
			return -1
		}
		if a.Ref > b.Ref {
			return 1
		}
		return 0
	})
	chVals := make([]canonicaljson.Value, 0, len(channels))
	for _, item := range channels {
		id, err := canonicaljson.Parse([]byte(u64(item.ChannelID)))
		if err != nil {
			return nil, err
		}
		ver, err := canonicaljson.Uint(uint64(item.RowVersion))
		if err != nil {
			return nil, err
		}
		chVals = append(chVals, canonicaljson.Object([]canonicaljson.Field{
			{Key: "adapter_type", Value: canonicaljson.String(item.AdapterType)},
			{Key: "adapter_version", Value: canonicaljson.String(item.AdapterVersion)},
			{Key: "channel_id", Value: id},
			{Key: "credential_ref", Value: canonicaljson.String(item.CredentialRef)},
			{Key: "operation", Value: canonicaljson.String(item.Operation)},
			{Key: "provider_account_id", Value: canonicaljson.String(item.ProviderAccountID)},
			{Key: "provider_id", Value: canonicaljson.String(item.ProviderID)},
			{Key: "row_version", Value: ver},
		}))
	}
	credVals := make([]canonicaljson.Value, 0, len(creds))
	for _, item := range creds {
		ver, err := canonicaljson.Uint(uint64(item.Version))
		if err != nil {
			return nil, err
		}
		credVals = append(credVals, canonicaljson.Object([]canonicaljson.Field{
			{Key: "credential_ref", Value: canonicaljson.String(item.Ref)},
			{Key: "provider_account_id", Value: canonicaljson.String(item.ProviderAccountID)},
			{Key: "provider_id", Value: canonicaljson.String(item.ProviderID)},
			{Key: "version", Value: ver},
		}))
	}
	obj := canonicaljson.Object([]canonicaljson.Field{
		{Key: "channels", Value: canonicaljson.Array(chVals)},
		{Key: "credentials", Value: canonicaljson.Array(credVals)},
	})
	return canonicaljson.AppendCanonical(nil, obj), nil
}

// UnmarshalReferences 解析仓储中的引用快照。
func UnmarshalReferences(raw []byte) (ReferenceSet, error) {
	root, err := canonicaljson.ParseObject(raw)
	if err != nil {
		return ReferenceSet{}, err
	}
	var set ReferenceSet
	ch, ok := root.Member("channels")
	if !ok {
		return ReferenceSet{}, errors.New("data_interface: snapshot channels")
	}
	items, ok := ch.Array()
	if !ok {
		return ReferenceSet{}, errors.New("data_interface: snapshot channels")
	}
	for _, item := range items {
		pin, err := readChannel(item)
		if err != nil {
			return ReferenceSet{}, err
		}
		set.Channels = append(set.Channels, pin)
	}
	cred, ok := root.Member("credentials")
	if !ok {
		return ReferenceSet{}, errors.New("data_interface: snapshot credentials")
	}
	items, ok = cred.Array()
	if !ok {
		return ReferenceSet{}, errors.New("data_interface: snapshot credentials")
	}
	for _, item := range items {
		pin, err := readCredential(item)
		if err != nil {
			return ReferenceSet{}, err
		}
		set.Credentials = append(set.Credentials, pin)
	}
	return set, nil
}

func readChannel(v canonicaljson.Value) (ChannelPin, error) {
	var pin ChannelPin
	id, ok := v.Member("channel_id")
	n, okN := id.Int64()
	if !ok || !okN || n <= 0 {
		return pin, errors.New("data_interface: snapshot channel_id")
	}
	pin.ChannelID = uint64(n)
	ver, ok := v.Member("row_version")
	vn, okN := ver.Int64()
	if !ok || !okN || vn < 0 {
		return pin, errors.New("data_interface: snapshot row_version")
	}
	pin.RowVersion = uint32(vn)
	pin.ProviderID, ok = textMember(v, "provider_id")
	if !ok {
		return pin, errors.New("data_interface: snapshot provider_id")
	}
	pin.ProviderAccountID, ok = textMember(v, "provider_account_id")
	if !ok {
		return pin, errors.New("data_interface: snapshot provider_account_id")
	}
	pin.Operation, ok = textMember(v, "operation")
	if !ok {
		return pin, errors.New("data_interface: snapshot operation")
	}
	pin.AdapterType, ok = textMember(v, "adapter_type")
	if !ok {
		return pin, errors.New("data_interface: snapshot adapter_type")
	}
	pin.AdapterVersion, ok = textMember(v, "adapter_version")
	if !ok {
		return pin, errors.New("data_interface: snapshot adapter_version")
	}
	pin.CredentialRef, ok = textMember(v, "credential_ref")
	if !ok {
		return pin, errors.New("data_interface: snapshot credential_ref")
	}
	return pin, nil
}

func readCredential(v canonicaljson.Value) (CredentialPin, error) {
	var pin CredentialPin
	var ok bool
	pin.Ref, ok = textMember(v, "credential_ref")
	if !ok {
		return pin, errors.New("data_interface: snapshot credential_ref")
	}
	ver, ok := v.Member("version")
	n, okN := ver.Int64()
	if !ok || !okN || n < 0 {
		return pin, errors.New("data_interface: snapshot version")
	}
	pin.Version = uint32(n)
	pin.ProviderID, ok = textMember(v, "provider_id")
	if !ok {
		return pin, errors.New("data_interface: snapshot provider_id")
	}
	pin.ProviderAccountID, ok = textMember(v, "provider_account_id")
	if !ok {
		return pin, errors.New("data_interface: snapshot provider_account_id")
	}
	return pin, nil
}

func textMember(v canonicaljson.Value, key string) (string, bool) {
	field, ok := v.Member(key)
	if !ok {
		return "", false
	}
	return field.Text()
}

func u64(n uint64) string {
	if n == 0 {
		return "0"
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	return string(b[i:])
}

- old_string: 

### Turn 102 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/data_interface/config.go has been created successfully.

### Turn 103 (Assistant)
[tool_request: search_replace]
- file_path: /Users/kiteeater/jobwork/ai-coding-test/internal/data/mysql/release.go
- new_string: package mysql

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"strconv"
	"time"

	"notifier/internal/constant"
	"notifier/internal/data_interface"
	"notifier/internal/domain"
)

// ReleaseStore 实现发布草稿、当前指针 CAS 和按版本读取。
// 发布事务先锁 routing_current 的 singleton 行，再复核引用，最后写指针和操作结果。
type ReleaseStore struct {
	db   *sql.DB
	exec *Executor
}

func NewReleaseStore(db *sql.DB, exec *Executor) *ReleaseStore {
	return &ReleaseStore{db: db, exec: exec}
}

func (s *ReleaseStore) CreateDraft(ctx context.Context, in data_interface.CreateDraftInput) (data_interface.CreateDraftResult, error) {
	var out data_interface.CreateDraftResult
	err := s.exec.RunTx(ctx, func(ctx context.Context, tx *sql.Tx) error {
		if err := lockCurrent(ctx, tx); err != nil {
			return err
		}
		if replay, ok, err := readOperation(ctx, tx, constant.OpConfigCreate, in.IdempotencyKey, in.Fingerprint); err != nil || ok {
			if err != nil {
				return err
			}
			decoded, err := decodeCreate(replay)
			if err != nil {
				return err
			}
			out = decoded
			return nil
		}
		set, err := freezeReferences(ctx, tx, in.Bindings)
		if err != nil {
			return err
		}
		snapshot, err := data_interface.MarshalReferences(set)
		if err != nil {
			return err
		}
		var maxVer sql.NullInt64
		if err := tx.QueryRowContext(ctx, `SELECT COALESCE(MAX(version_no), 0) FROM routing_releases`).Scan(&maxVer); err != nil {
			return err
		}
		next := maxVer.Int64 + 1
		if next <= 0 || next > int64(^uint32(0)) {
			return domainErr(constant.CodeLimitExceeded, "发布序号溢出")
		}
		opID, err := newOperationID()
		if err != nil {
			return err
		}
		res, err := tx.ExecContext(ctx, `
			INSERT INTO routing_releases (
				version_no, content, content_canonical, content_sha256, fingerprint_version,
				reference_snapshot, status, created_at)
			VALUES (?, CAST(? AS JSON), ?, ?, ?, CAST(? AS JSON), 'draft', UTC_TIMESTAMP(6))`,
			next, string(in.ContentCanonical), in.ContentCanonical, in.ContentSHA256, constant.FingerprintVersion, string(snapshot))
		if err != nil {
			return err
		}
		id, err := res.LastInsertId()
		if err != nil || id <= 0 {
			return err
		}
		out = data_interface.CreateDraftResult{
			OperationID:   opID,
			ReleaseID:     uint64(id),
			VersionNo:     uint32(next),
			Status:        "draft",
			ContentSHA256: in.ContentSHA256,
		}
		body, err := json.Marshal(out)
		if err != nil {
			return err
		}
		return insertOperation(ctx, tx, constant.OpConfigCreate, opID, in.IdempotencyKey, in.Fingerprint, in.ActorID, in.Reason, uint64(id), body)
	})
	return out, mapTxErr(err)
}

func (s *ReleaseStore) Publish(ctx context.Context, in data_interface.PublishInput) (data_interface.PublishResult, error) {
	var out data_interface.PublishResult
	err := s.exec.RunTx(ctx, func(ctx context.Context, tx *sql.Tx) error {
		current, err := lockCurrentID(ctx, tx)
		if err != nil {
			return err
		}
		if replay, ok, err := readOperation(ctx, tx, constant.OpConfigPublish, in.IdempotencyKey, in.Fingerprint); err != nil || ok {
			if err != nil {
				return err
			}
			decoded, err := decodePublish(replay)
			if err != nil {
				return err
			}
			out = decoded
			return nil
		}
		var (
			versionNo uint32
			status    string
			canon     []byte
			shaHex    string
			fpVer     sql.NullInt64
			snapshot  []byte
		)
		err = tx.QueryRowContext(ctx, `
			SELECT version_no, status, content_canonical, content_sha256, fingerprint_version, reference_snapshot
			FROM routing_releases WHERE release_id = ? FOR UPDATE`, in.ReleaseID).
			Scan(&versionNo, &status, &canon, &shaHex, &fpVer, &snapshot)
		if errors.Is(err, sql.ErrNoRows) {
			return data_interface.ErrReleaseNotFound
		}
		if err != nil {
			return err
		}
		if status != "draft" {
			return domainErr(constant.CodeStateConflict, "草稿不能再次发布")
		}
		if !fpVer.Valid || int(fpVer.Int64) != constant.FingerprintVersion || len(canon) == 0 || domainSHA(canon) != shaHex {
			return domainErr(constant.CodeConfigurationUnavailable, "发布内容不可用")
		}
		stored, err := data_interface.UnmarshalReferences(snapshot)
		if err != nil {
			return domainErr(constant.CodeConfigurationUnavailable, "发布内容不可用")
		}
		live, err := loadLiveReferences(ctx, tx, stored)
		if err != nil {
			return err
		}
		if !data_interface.SameReferences(stored, live) {
			return domainErr(constant.CodeConfigurationChanged, "引用版本已变化，请重新校验")
		}
		if !samePointer(current, in.Expected) {
			return domainErr(constant.CodeVersionConflict, "当前发布版本已变化")
		}
		if current != nil {
			res, err := tx.ExecContext(ctx, `
				UPDATE routing_releases SET status = 'superseded'
				WHERE release_id = ? AND status = 'published'`, *current)
			if err != nil {
				return err
			}
			if n, _ := res.RowsAffected(); n != 1 {
				return domainErr(constant.CodeInternal, "内部错误")
			}
		}
		res, err := tx.ExecContext(ctx, `
			UPDATE routing_releases
			SET status = 'published', published_at = UTC_TIMESTAMP(6)
			WHERE release_id = ? AND status = 'draft'`, in.ReleaseID)
		if err != nil {
			return err
		}
		if n, _ := res.RowsAffected(); n != 1 {
			return domainErr(constant.CodeStateConflict, "草稿不能再次发布")
		}
		res, err = tx.ExecContext(ctx, `
			UPDATE routing_current SET release_id = ?, updated_at = UTC_TIMESTAMP(6) WHERE singleton = 1`, in.ReleaseID)
		if err != nil {
			return err
		}
		if n, _ := res.RowsAffected(); n != 1 {
			return domainErr(constant.CodeInternal, "内部错误")
		}
		var published time.Time
		if err := tx.QueryRowContext(ctx, `SELECT published_at FROM routing_releases WHERE release_id = ?`, in.ReleaseID).Scan(&published); err != nil {
			return err
		}
		opID, err := newOperationID()
		if err != nil {
			return err
		}
		out = data_interface.PublishResult{
			OperationID: opID,
			ReleaseID:   in.ReleaseID,
			VersionNo:   versionNo,
			Previous:    current,
			PublishedAt: published.UTC(),
		}
		body, err := encodePublish(out)
		if err != nil {
			return err
		}
		return insertOperation(ctx, tx, constant.OpConfigPublish, opID, in.IdempotencyKey, in.Fingerprint, in.ActorID, in.Reason, in.ReleaseID, body)
	})
	return out, mapTxErr(err)
}

func (s *ReleaseStore) Load(ctx context.Context, releaseID uint64) (data_interface.ReleaseRecord, error) {
	row := s.db.QueryRowContext(ctx, `
		SELECT release_id, version_no, status, content_canonical, content_sha256, fingerprint_version,
		       reference_snapshot, created_at, published_at
		FROM routing_releases WHERE release_id = ?`, releaseID)
	return scanRelease(row)
}

func (s *ReleaseStore) LoadCurrentID(ctx context.Context) (uint64, error) {
	var id sql.NullInt64
	err := s.db.QueryRowContext(ctx, `SELECT release_id FROM routing_current WHERE singleton = 1`).Scan(&id)
	if errors.Is(err, sql.ErrNoRows) || (err == nil && !id.Valid) {
		return 0, data_interface.ErrNoCurrent
	}
	if err != nil {
		return 0, domainErr(constant.CodeInternal, "内部错误")
	}
	if id.Int64 <= 0 {
		return 0, data_interface.ErrNoCurrent
	}
	return uint64(id.Int64), nil
}

func (s *ReleaseStore) GetChannel(ctx context.Context, id uint64) (data_interface.ChannelPin, error) {
	pin, err := scanChannel(s.db.QueryRowContext(ctx, channelSelect+` WHERE channel_id = ?`, id), id)
	if errors.Is(err, sql.ErrNoRows) {
		return data_interface.ChannelPin{}, data_interface.ErrChannelNotFound
	}
	if err != nil {
		return data_interface.ChannelPin{}, domainErr(constant.CodeInternal, "内部错误")
	}
	return pin, nil
}

func (s *ReleaseStore) GetCredential(ctx context.Context, ref string) (data_interface.CredentialPin, error) {
	pin, err := scanCredential(s.db.QueryRowContext(ctx, credentialSelect+` WHERE credential_ref = ?`, ref), ref)
	if errors.Is(err, sql.ErrNoRows) {
		return data_interface.CredentialPin{}, data_interface.ErrCredentialNotFound
	}
	if err != nil {
		return data_interface.CredentialPin{}, domainErr(constant.CodeInternal, "内部错误")
	}
	return pin, nil
}

const channelSelect = `
	SELECT provider_id, provider_account_id, operation, adapter_type, adapter_version, credential_ref, row_version
	FROM channels`

const credentialSelect = `
	SELECT provider_id, provider_account_id, version FROM credential_refs`

func lockCurrent(ctx context.Context, tx *sql.Tx) error {
	var id sql.NullInt64
	err := tx.QueryRowContext(ctx, `SELECT release_id FROM routing_current WHERE singleton = 1 FOR UPDATE`).Scan(&id)
	if errors.Is(err, sql.ErrNoRows) {
		return domainErr(constant.CodeConfigurationUnavailable, "当前发布指针不存在")
	}
	return err
}

func lockCurrentID(ctx context.Context, tx *sql.Tx) (*uint64, error) {
	var id sql.NullInt64
	err := tx.QueryRowContext(ctx, `SELECT release_id FROM routing_current WHERE singleton = 1 FOR UPDATE`).Scan(&id)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, domainErr(constant.CodeConfigurationUnavailable, "当前发布指针不存在")
	}
	if err != nil {
		return nil, err
	}
	if !id.Valid {
		return nil, nil
	}
	if id.Int64 <= 0 {
		return nil, domainErr(constant.CodeInternal, "内部错误")
	}
	v := uint64(id.Int64)
	return &v, nil
}

func readOperation(ctx context.Context, tx *sql.Tx, opType, key, fingerprint string) ([]byte, bool, error) {
	var storedFP string
	var result []byte
	err := tx.QueryRowContext(ctx, `
		SELECT request_fingerprint, result FROM management_events
		WHERE caller_scope = ? AND operation_type = ? AND idempotency_key = ?`,
		constant.GlobalCallerScope, opType, key).Scan(&storedFP, &result)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, false, nil
	}
	if err != nil {
		return nil, false, err
	}
	if storedFP != fingerprint {
		return nil, false, domainErr(constant.CodeIdempotencyConflict, "相同操作键的参数不一致")
	}
	return result, true, nil
}

func insertOperation(ctx context.Context, tx *sql.Tx, opType, opID, key, fingerprint, actor, reason string, releaseID uint64, result []byte) error {
	_, err := tx.ExecContext(ctx, `
		INSERT INTO management_events (
			operation_type, operation_id, idempotency_key, caller_scope, request_fingerprint,
			actor, reason, target_type, target_id, result, created_at)
		VALUES (?, ?, ?, ?, ?, ?, ?, 'routing_release', ?, ?, UTC_TIMESTAMP(6))`,
		opType, opID, key, constant.GlobalCallerScope, fingerprint, actor, reason, strconv.FormatUint(releaseID, 10), result)
	return err
}

func freezeReferences(ctx context.Context, tx *sql.Tx, bindings []domain.TargetBinding) (data_interface.ReferenceSet, error) {
	var set data_interface.ReferenceSet
	seenCh := map[uint64]struct{}{}
	seenRef := map[string]struct{}{}
	ids := make([]uint64, 0, len(bindings))
	for _, binding := range bindings {
		if _, ok := seenCh[binding.ChannelID]; ok {
			continue
		}
		seenCh[binding.ChannelID] = struct{}{}
		ids = append(ids, binding.ChannelID)
	}
	sortU64(ids)
	for _, id := range ids {
		pin, err := scanChannel(tx.QueryRowContext(ctx, channelSelect+` WHERE channel_id = ? FOR SHARE`, id), id)
		if errors.Is(err, sql.ErrNoRows) {
			return set, domainErr(constant.CodeConfigurationChanged, "引用版本已变化，请重新校验")
		}
		if err != nil {
			return set, err
		}
		for _, binding := range bindings {
			if binding.ChannelID != id {
				continue
			}
			if pin.ProviderID != binding.ProviderID || pin.ProviderAccountID != binding.ProviderAccountID ||
				pin.Operation != binding.Operation || pin.AdapterType != binding.AdapterType ||
				pin.AdapterVersion != binding.AdapterVersion || pin.CredentialRef != binding.CredentialRef {
				return set, domainErr(constant.CodeConfigurationChanged, "引用版本已变化，请重新校验")
			}
		}
		set.Channels = append(set.Channels, pin)
	}
	refs := make([]string, 0, len(bindings))
	for _, binding := range bindings {
		if _, ok := seenRef[binding.CredentialRef]; ok {
			continue
		}
		seenRef[binding.CredentialRef] = struct{}{}
		refs = append(refs, binding.CredentialRef)
	}
	sortStrings(refs)
	for _, ref := range refs {
		pin, err := scanCredential(tx.QueryRowContext(ctx, credentialSelect+` WHERE credential_ref = ? FOR SHARE`, ref), ref)
		if errors.Is(err, sql.ErrNoRows) {
			return set, domainErr(constant.CodeConfigurationChanged, "引用版本已变化，请重新校验")
		}
		if err != nil {
			return set, err
		}
		for _, binding := range bindings {
			if binding.CredentialRef != ref {
				continue
			}
			if pin.ProviderID != binding.ProviderID || pin.ProviderAccountID != binding.ProviderAccountID {
				return set, domainErr(constant.CodeConfigurationChanged, "引用版本已变化，请重新校验")
			}
		}
		set.Credentials = append(set.Credentials, pin)
	}
	return set, nil
}

func loadLiveReferences(ctx context.Context, tx *sql.Tx, stored data_interface.ReferenceSet) (data_interface.ReferenceSet, error) {
	var live data_interface.ReferenceSet
	ids := make([]uint64, len(stored.Channels))
	for i, item := range stored.Channels {
		ids[i] = item.ChannelID
	}
	sortU64(ids)
	for _, id := range ids {
		pin, err := scanChannel(tx.QueryRowContext(ctx, channelSelect+` WHERE channel_id = ? FOR SHARE`, id), id)
		if errors.Is(err, sql.ErrNoRows) {
			return live, domainErr(constant.CodeConfigurationChanged, "引用版本已变化，请重新校验")
		}
		if err != nil {
			return live, err
		}
		live.Channels = append(live.Channels, pin)
	}
	refs := make([]string, len(stored.Credentials))
	for i, item := range stored.Credentials {
		refs[i] = item.Ref
	}
	sortStrings(refs)
	for _, ref := range refs {
		pin, err := scanCredential(tx.QueryRowContext(ctx, credentialSelect+` WHERE credential_ref = ? FOR SHARE`, ref), ref)
		if errors.Is(err, sql.ErrNoRows) {
			return live, domainErr(constant.CodeConfigurationChanged, "引用版本已变化，请重新校验")
		}
		if err != nil {
			return live, err
		}
		live.Credentials = append(live.Credentials, pin)
	}
	return live, nil
}

type rowScanner interface {
	Scan(dest ...any) error
}

func scanChannel(row rowScanner, id uint64) (data_interface.ChannelPin, error) {
	var pin data_interface.ChannelPin
	pin.ChannelID = id
	err := row.Scan(&pin.ProviderID, &pin.ProviderAccountID, &pin.Operation, &pin.AdapterType, &pin.AdapterVersion, &pin.CredentialRef, &pin.RowVersion)
	return pin, err
}

func scanCredential(row rowScanner, ref string) (data_interface.CredentialPin, error) {
	var pin data_interface.CredentialPin
	pin.Ref = ref
	err := row.Scan(&pin.ProviderID, &pin.ProviderAccountID, &pin.Version)
	return pin, err
}

func scanRelease(row rowScanner) (data_interface.ReleaseRecord, error) {
	var rec data_interface.ReleaseRecord
	var canon, snapshot []byte
	var sha string
	var fp sql.NullInt64
	var published sql.NullTime
	err := row.Scan(&rec.ReleaseID, &rec.VersionNo, &rec.Status, &canon, &sha, &fp, &snapshot, &rec.CreatedAt, &published)
	if errors.Is(err, sql.ErrNoRows) {
		return data_interface.ReleaseRecord{}, data_interface.ErrReleaseNotFound
	}
	if err != nil {
		return data_interface.ReleaseRecord{}, domainErr(constant.CodeInternal, "内部错误")
	}
	if len(canon) == 0 || !fp.Valid || int(fp.Int64) != constant.FingerprintVersion || domainSHA(canon) != sha {
		return data_interface.ReleaseRecord{}, domainErr(constant.CodeConfigurationUnavailable, "发布内容不可用")
	}
	rec.ContentCanonical = canon
	rec.ContentSHA256 = sha
	rec.FingerprintVersion = int(fp.Int64)
	rec.ReferenceSnapshot = snapshot
	rec.CreatedAt = rec.CreatedAt.UTC()
	if published.Valid {
		t := published.Time.UTC()
		rec.PublishedAt = &t
	}
	return rec, nil
}

func domainSHA(canonical []byte) string {
	return domainFingerprint(canonical)
}

func domainFingerprint(canonical []byte) string {
	return fingerprintHex(canonical)
}

func samePointer(current, expected *uint64) bool {
	if current == nil || expected == nil {
		return current == nil && expected == nil
	}
	return *current == *expected
}

func newOperationID() (string, error) {
	var buf [16]byte
	if _, err := rand.Read(buf[:]); err != nil {
		return "", err
	}
	return hex.EncodeToString(buf[:]), nil
}

type storedPublish struct {
	OperationID string  `json:"operation_id"`
	ReleaseID   string  `json:"release_id"`
	VersionNo   uint32  `json:"version_no"`
	Previous    *string `json:"previous_release_id"`
	PublishedAt string  `json:"published_at"`
}

func encodePublish(out data_interface.PublishResult) ([]byte, error) {
	id, err := domain.FormatInternalID(out.ReleaseID)
	if err != nil {
		return nil, err
	}
	body := storedPublish{
		OperationID: out.OperationID,
		ReleaseID:   id,
		VersionNo:   out.VersionNo,
		PublishedAt: domain.FormatUTCMicros(out.PublishedAt),
	}
	if out.Previous != nil {
		prev, err := domain.FormatInternalID(*out.Previous)
		if err != nil {
			return nil, err
		}
		body.Previous = &prev
	}
	return json.Marshal(body)
}

func decodePublish(raw []byte) (data_interface.PublishResult, error) {
	var body storedPublish
	if err := json.Unmarshal(raw, &body); err != nil {
		return data_interface.PublishResult{}, domainErr(constant.CodeInternal, "内部错误")
	}
	id, err := domain.ParseInternalID("release_id", body.ReleaseID)
	if err != nil {
		return data_interface.PublishResult{}, domainErr(constant.CodeInternal, "内部错误")
	}
	at, err := domain.ParseRFC3339("published_at", body.PublishedAt)
	if err != nil {
		return data_interface.PublishResult{}, domainErr(constant.CodeInternal, "内部错误")
	}
	out := data_interface.PublishResult{OperationID: body.OperationID, ReleaseID: id, VersionNo: body.VersionNo, PublishedAt: at}
	if body.Previous != nil {
		prev, err := domain.ParseInternalID("previous_release_id", *body.Previous)
		if err != nil {
			return data_interface.PublishResult{}, domainErr(constant.CodeInternal, "内部错误")
		}
		out.Previous = &prev
	}
	return out, nil
}

func decodeCreate(raw []byte) (data_interface.CreateDraftResult, error) {
	var body data_interface.CreateDraftResult
	if err := json.Unmarshal(raw, &body); err != nil {
		return data_interface.CreateDraftResult{}, domainErr(constant.CodeInternal, "内部错误")
	}
	if body.ReleaseID == 0 || body.OperationID == "" {
		return data_interface.CreateDraftResult{}, domainErr(constant.CodeInternal, "内部错误")
	}
	return body, nil
}

func domainErr(code, message string) error {
	err, _ := domain.NewError(code, message, "", nil)
	return err
}

func mapTxErr(err error) error {
	if err == nil {
		return nil
	}
	var de *domain.Error
	if errors.As(err, &de) {
		return de
	}
	if errors.Is(err, data_interface.ErrReleaseNotFound) || errors.Is(err, data_interface.ErrNoCurrent) {
		return err
	}
	if Classify(err) == FailureCommitUncertain {
		return domainErr(constant.CodeDependencyUnavailable, "提交结果不确定")
	}
	return domainErr(constant.CodeInternal, "内部错误")
}

func sortU64(ids []uint64) {
	for i := 1; i < len(ids); i++ {
		j := i
		for j > 0 && ids[j] < ids[j-1] {
			ids[j], ids[j-1] = ids[j-1], ids[j]
			j--
		}
	}
}

func sortStrings(items []string) {
	for i := 1; i < len(items); i++ {
		j := i
		for j > 0 && items[j] < items[j-1] {
			items[j], items[j-1] = items[j-1], items[j]
			j--
		}
	}
}

- old_string: 

### Turn 104 (Function)
[tool_response]
The file /Users/kiteeater/jobwork/ai-coding-test/internal/data/mysql/release.go has been created successfully.
